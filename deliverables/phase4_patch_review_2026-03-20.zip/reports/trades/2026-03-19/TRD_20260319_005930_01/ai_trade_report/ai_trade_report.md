# Trade Report (TRD_20260319_005930_01)

- action: **SELL 005930**
- lifecycle_status: **closed**
- story_type: **simulation**
- execution_mode: **simulation (mock broker)**
- report_generation: status=`ok` mode=`ai` model=`stepfun/step-3.5-flash:free`

## Evidence Provenance

- market_context_at_entry: source=canonical confidence=high path=reports\dev\analysis\live_execution_bundles\agent_pipeline_trace\agent_pipeline_trace_03c3ca3b8b284e7c8414.json
- why_this_symbol_was_chosen: source=canonical confidence=high path=reports\dev\analysis\live_execution_bundles\agent_pipeline_trace\agent_pipeline_trace_03c3ca3b8b284e7c8414.json
- holding_monitoring_story: source=canonical confidence=high path=reports\dev\analysis\live_execution_bundles\agent_pipeline_trace\agent_pipeline_trace_03c3ca3b8b284e7c8414.json
- execution_quality: source=canonical confidence=high path=reports\dev\analysis\live_execution_bundles\agent_pipeline_trace\agent_pipeline_trace_03c3ca3b8b284e7c8414.json
- reporter_evaluation: source=direct_artifact confidence=medium path=reports\dev\analysis\reporter_analysis\reporter_analysis_2026-03-19.json

## Monitor Snapshot

- posture: **SELL**
- trigger_type: **peak_drawdown**
- effective_stop: **1.00%**
- effective_stop_reason: hard_stop
- take_profit: 0.52%
- current_price: 200250.00
- average_price: 200500.00
- peak_price: 201000.00
- current_drawdown: -0.37%
- peak_drawdown: -0.37%
- active_exit_axis: Peak Drawdown
- watch_axis: Hard stop
- watch_axis: Adaptive stop
- watch_axis: Take profit
- watch_axis: Trailing stop
- watch_axis: Peak drawdown
- watch_axis: VWAP breakdown
- price_source: position.current_price
- feature_source: selected.features
- price_source_policy: market.quote > position.current_price > selected > market_snapshot > position.avg_plus_unrealized
- exit_triggered: yes

## Executive Summary

TRD_20260319_005930_01 거래가 종료되었습니다. 보유 기간은 41.2분이며, 진입 시 스캐너가 거래 가치, 테마 및 섹터 정렬을 기준으로 5개 후보 중 1위로 005930을 선택했습니다. 청산은 피크 드로다운(peak_drawdown)으로 인해 SELL이 트리거되었습니다.

## Market Context at Entry

시장 체제는 중립, 시장 심리는 약세, 플레이북은 방어적이었습니다. 글로벌 감성 점수는 -0.23, VIX는 25.09였으며, elevated_vix, dollar_strength, yield_rise 스트레스 플래그가 활성화되었습니다. 75개의 헤드라인이 10개 대상(시장 10개 / 후보 5개)에 대해 고려되었습니다.

- 시장 체제: 중립
- 시장 심리: 약세
- 플레이북: 방어적
- 글로벌 감성 점수: -0.23
- VIX / 공포 지수 수준: 25.09
- 달러 인덱스 변동: 0.59%
- 헤드라인 수: 75
- 뉴스 쿼리 수: 10
- Market regime: neutral
- Global sentiment score: -0.23
- News input: 75 headlines were considered across 10 targets (10 market / 5 candidate signals).
- News query targets: 코스피, 미국 증시, 국제유가, 환율, 중동, 하락 종목 수, 약세 업종, 달러

## Why This Symbol Was Chosen

스캐너는 거래 가치, 테마 및 섹터 정렬을 기준으로 5개 후보 중 005930을 1위(점수 1.171)로 선정했습니다. 신뢰도 0.84, 위험 점수 0.64, 소스 믹스(top_value, sector_theme) 및 방어적 플레이북 정렬을 고려했습니다.

- 스캔된 유니버스: 5개
- 선정 순위: 1위
- 순위 기준: 거래 가치, 테마 및 섹터 정렬
- 선정 이유: 최종 스캐너 점수 1.171
- 선정 소스: top_value, sector_theme
- 차트/피처 커버리지: 6/12
- 신뢰도: 0.84 (중간)
- 위험 점수: 0.64
- Top candidates: #1 005930 score 1.171; #2 032820 score 1.165; #3 047040 score 1.162
- Why not others: 032820 was weaker because score gap 0.007; higher risk (0.700 vs 0.638); lower confidence (0.748 vs 0.836); 047040 was weaker because score gap 0.010; higher risk (0.868 vs 0.638); lower confidence (0.811 vs 0.836)
- Selection decision: highest total score (1.171); confidence 0.84 and risk 0.64; source mix: top_value, sector_theme; playbook alignment: defensive
- Final decision basis: Scanner selected the highest-ranked candidate after strategist-guided weighting, source scoring, and risk penalties.

## Entry Decision

스캐너의 1위 선정 결과와 방어적 플레이북 정렬, 높은 신뢰도 및 낮은 위험 점수를 바탕으로 BUY 주문이 실행되었습니다.

- 진입 액션: BUY
- 선정 근거: 최종 스캐너 점수(1.171)最高
- 신뢰도 대비 위험: 신뢰도 0.84, 위험 0.64
- 소스 믹스: top_value, sector_theme
- 플레이북 일치: 방어적 자산 및 광범위 시장 리더 테마
- 차트 피처: 6/12 캡처 (부분적)
- Selection decision: highest total score (1.171)
- Final decision basis: Scanner selected the highest-ranked candidate after strategist-guided weighting, source scoring, and risk penalties.

## Holding / Monitoring Story

포지션 보유 기간 동안 모니터링은 지속적으로 HOLD 상태를 유지했으며, 손절매(5.50%)와 이익실현(0.52%) 임계값이 설정되었습니다. 활성 감시 축에는 하드 스톱, 적응형 스톱, 이익실현, 트레일링 스톱, 피크 드로다운이 포함되었습니다.

- 모니터 자세: HOLD
- 포지션 나이: 0초 (진입 시)
- 손절매 비율: 5.50%
- 이익실현 비율: 0.52%
- 활성 감시 축: 하드 스톱, 적응형 스톱, 이익실현, 트레일링 스톱, 피크 드로다운
- 확인 필요: 3회
- 확인 횟수: 0회 (보유 중)
- Monitor runs: 37
- Posture: SELL
- Trigger type: peak_drawdown
- Position age: 2436 seconds
- Effective stop: 1.00% (hard_stop)

## Exit Decision

피크 드로다운(peak_drawdown)이 -0.37%에 도달하여 SELL이 트리거되었습니다. 유효 손절매는 하드 스톱으로 1.00%로 조정되었으며, 확인 체인(confirmed_exit_signal, peak_drawdown)을 통과했습니다.

- 청산 액션: SELL
- 트리거 유형: 피크 드로다운
- 모니터 이유: confirmed_exit_signal
- 포지션 나이: 2436초 (약 40.6분)
- 설정 손절매: 8.00%
- 유효 손절매: 1.00% (하드 스톱)
- 피크 가격: 201,000원
- 현재 가격: 200,250원
- Trigger type: peak_drawdown
- Active exit axis: Peak Drawdown
- Exit confirmation: 0/3
- Decision chain: confirmed_exit_signal -> peak_drawdown -> peak_drawdown

## Scanner Logic and Filters

스캐너 및 가드 검사 8개 게이트 중 4개 통과. 차트 완전성은 6/12로 부분적이었습니다.

- 유동성 필터: PASS - top value 또는 거래량 입력이 선택 지원
- 거래량 필터: FAIL - top volume 또는 거래량 입력이 선택 지원
- 섹터/테마 정렬: PASS - 테마 부스트 또는 섹터 소스가 전략가 프레임과 일치
- 차트 완전성 필터: PARTIAL - 6/12 캡처된 차트 피처
- 감성 게이트: PASS - 뉴스/글로벌 감성 기여도 0.000
- 위험 게이트: PASS - 위험 점수 0.638, Supervisor allow=True
- liquidity filter: PASS - top value or trading-value input supported the selection
- turnover filter: FAIL - top volume or turnover input supported the selection
- sector/theme alignment: PASS - theme boost or sector source matched the strategist frame
- chart completeness filter: PARTIAL - 6/12 captured chart features
- sentiment gate: PASS - news/global sentiment contribution was 0.000
- risk gate: PASS - risk score was 0.638 and supervisor allow=True

## Guard / Approval Result

Supervisor가 'Allowed' 이유로 주문을 승인했습니다. 승인 모드는 실행 추적에 캡처되지 않았습니다.

- Supervisor verdict: approve
- Supervisor allow: yes
- Guard reason: Allowed
- 검토된 액션: SELL
- 검토된 심볼: 005930
- 승인 모드: not_captured
- Action reviewed: SELL
- Symbol reviewed: 005930
- Approval mode: not captured in the execution trace

## Execution Quality

진입 및 청산 주문 모두 시뮬레이션 모드에서 승인되어 성공적으로 기록되었습니다. 실행 환경은 mock broker로 설정되었습니다.

- 진입 실행: BUY 주문 승인 및 기록 완료 (시뮬레이션)
- 청산 실행: SELL 주문 승인 및 기록 완료 (시뮬레이션)
- 실행 모드: simulation (mock broker)
- 수량: 1주
- 주문 상태: not_captured
- 주문 번호: not_captured
- 브로커 환경: not_captured
- Execution outcome: recorded
- Quantity: 1
- Execution mode: simulation (mock broker)
- Broker environment: not_captured
- Order status: not_captured

## Reporter Evaluation

동일 날짜 리포터 파일은 존재하지만, 이 실행에 대한 실행별 평가는 아직 연결되지 않았습니다. 성적은 C이며, 리포터 분석을 수명 주기에 연결해야 완전한 품질 검토가 가능합니다.

- 리포터 상태: pending
- 성적: C
- 중요: 동일 날짜 리포터 분석을 이 수명 주기에 연결하여 완전한 품질 검토 수행 필요
- Link same-day reporter analysis to this lifecycle for a complete quality review.

## Errors / Weaknesses / Improvement Points

주요 개선점은 동일 날짜 리포터 분석을 수명 주기에 연결하여 종합적인 품질 검토를 완성하는 것입니다.

- 개선점: 동일 날짜 리포터 분석을 이 수명 주기에 연결하여 완전한 품질 검토 수행
- Link same-day reporter analysis to this lifecycle for a complete quality review.

## Full Timeline

- entry: 실행 ID 03c3ca3b8b284e7c8414617e89749083에 의해 BUY 주문이 실행되었습니다.
- holding: 모니터 자세=HOLD, 이유=hold, 청산=hold
- holding: 모니터 자세=HOLD, 이유=hold, 청산=hold
- holding: 모니터 자세=HOLD, 이유=hold, 청산=hold
- holding: 모니터 자세=HOLD, 이유=hold, 청산=hold
- holding: 모니터 자세=HOLD, 이유=hold, 청산=hold
- holding: 모니터 자세=HOLD, 이유=hold, 청산=hold
- holding: 모니터 자세=HOLD, 이유=hold, 청산=hold
- holding: 모니터 자세=HOLD, 이유=hold, 청산=hold
- holding: 모니터 자세=HOLD, 이유=hold, 청산=hold
- holding: 모니터 자세=HOLD, 이유=hold, 청산=hold
- exit: 실행 ID 036b58754a1f47c49765f7ccbcb9f5d5에 의해 SELL 주문이 실행되었습니다.

## Final Operator Conclusion

현재 수명 주기 상태는 closed이며, 진입과 청산이 하나의 수명 주기 스토리로 연결되었습니다.

- current_action: **SELL**
- watch_next: Lifecycle status: closed
- watch_next: Monitor trigger changes
- watch_next: Macro/news shifts
- thesis_invalidation: stop-loss breach
- thesis_invalidation: monitor and scanner divergence
- thesis_invalidation: negative macro regime shift
