# AI 거래 리포트 (TRD_20260320_005930_01)

- 대상 거래는 매도 005930 기준으로 정리했습니다.
- 라이프사이클 상태는 종결입니다.
- 리포트 유형은 simulation입니다.
- 실행 모드는 시뮬레이션 (모의 브로커)입니다.
- 리포트 생성 상태는 ok이며, 생성 모드는 ai, 사용 모델은 minimax/minimax-m2.5입니다.

## 근거 출처

- market_context_at_entry 섹션은 source=canonical, confidence=high, path=C:\Trading_Agent_System\reports\dev\analysis\live_execution_bundles\agent_pipeline_trace\agent_pipeline_trace_b5f7339c70804fc8bc06.json 기준으로 구성했습니다.
- why_this_symbol_was_chosen 섹션은 source=canonical, confidence=high, path=C:\Trading_Agent_System\reports\dev\analysis\live_execution_bundles\agent_pipeline_trace\agent_pipeline_trace_b5f7339c70804fc8bc06.json 기준으로 구성했습니다.
- holding_monitoring_story 섹션은 source=canonical, confidence=high, path=C:\Trading_Agent_System\reports\dev\analysis\live_execution_bundles\agent_pipeline_trace\agent_pipeline_trace_b5f7339c70804fc8bc06.json 기준으로 구성했습니다.
- execution_quality 섹션은 source=canonical, confidence=high, path=C:\Trading_Agent_System\reports\dev\analysis\live_execution_bundles\agent_pipeline_trace\agent_pipeline_trace_b5f7339c70804fc8bc06.json 기준으로 구성했습니다.
- reporter_evaluation 섹션은 source=direct_artifact, confidence=medium, path=C:\Trading_Agent_System\reports\dev\analysis\reporter_analysis\reporter_analysis_2026-03-20.json 기준으로 구성했습니다.

## 모니터 스냅샷

- 현재 포지션 판단은 매도입니다.
- 감지된 신호 유형은 고점 대비 하락폭 확대입니다.
- 유효 손절 기준은 3.00% 수준입니다.
- 손절 기준 축은 고정 손절 기준입니다.
- 목표 수익 실현 기준은 4.76% 수준입니다.
- 현재가는 199700.00입니다.
- 평균 단가는 201000.00입니다.
- 장중 고점은 201750.00입니다.
- 현재 손익 변동은 -1.02%입니다.
- 고점 대비 하락폭은 -1.02%입니다.
- 현재 우선 감시 중인 청산 축은 고점 대비 하락폭 확대입니다.
- 주요 감시 축은 고정 손절 기준입니다.
- 주요 감시 축은 상황 대응형 손절 기준입니다.
- 주요 감시 축은 목표 수익 실현 기준입니다.
- 주요 감시 축은 Trailing stop입니다.
- 주요 감시 축은 고점 대비 하락폭 확대입니다.
- 주요 감시 축은 VWAP 이탈입니다.
- 가격 기준 소스는 position.current_price입니다.
- 피처 기준 소스는 selected.features입니다.
- 가격 소스 정책은 market.quote > position.current_price > selected > market_snapshot > position.avg_plus_unrealized입니다.
- 청산 신호 발생 여부는 예입니다.

## 최종 판단 요약

005930 매수 후 4.4시간 보유 중 피크 드로다운 기준 매도 트리거. 스캐너 랭킹 1위(점수 1.173) 종목으로 진입했으나 시장 약세 구간에서 하락세를 감지하지 못하고 정지 손절에 도달. 글로벌 감성 점수 -0.07, VIX 24.06으로 불안정한 시장 환경에서 브레이크아웃 플레이 실패.

## 시장 환경 요약

중립 regime, 약세 시장 감성, 브레이크아웃 플레이 적용. 글로벌 감성 점수 -0.0719, VIX 24.06으로 변동성 높은 환경. 60개 헤드라인 분석 완료, 7개 타겟(시장 5개/후보 5개)에 대한 신호 탐지.

- 시장 상태는 neutral이며, 시장 심리는 bearish이고, 플레이북은 breakout입니다.
- 주요 테마는 broad_market_leaders, defensive_large_cap, energy_sector_strength입니다.
- 글로벌 감성 점수는 -0.0719 (부정적)입니다.
- VIX 수준은 24.06 (높은 변동성 구간)입니다.
- 분석된 헤드라인: 60개, 타겟 수: 7개
- 시장 상태는 neutral입니다.
- 글로벌 감성 점수는 -0.07입니다.
- 뉴스 입력 요약은 60 headlines were considered across 7 targets (7 market / 5 candidate signals).입니다.
- 뉴스 조회 대상은 코스피, 코스닥, 미국 증시, 증시 전망, 거시경제, 하락 종목 수, 약세 업종입니다.
- 전략가 핵심 입력은 global_sentiment score=-0.072 status=ok source=yfinance; us_indices sp500=-0.27% nasdaq=-0.28% dow=-0.44%; fear_index vix=24.06 change=-4.11% pressure=0.203입니다.
- 주요 시장 뉴스는 코스피: [속보] 에너지주'강세'…<b>코스피</b> 5800선 회복; 코스피: 亞 장초반..유가 하락 속 <b>코스피</b>·코스닥 '상승', 호주증시 '하락'; 코스닥: [개장시황] 코스피 50.13포인트 오른 5813.35 출발입니다.

## 선택된 종목 상세 분석

005930는 5개 후보 중 스캐너 점수 1.173으로 1위 선정. 거래 가치, 테마/섹터 정렬, 센티먼트 지원에서 모두 최고위를 기록했으며 confidence 0.82, risk 0.60로 균형 잡힌 프로파일.

- 5개 후보 중 종합 점수 1.173으로 1위 (2위 000660: 1.130, 3위 047040: 1.127)
- top_value, sector_theme 소스 조합으로 선정
- 차트 피처 커버리지 10/12로 높은 분석 완결성
- 브레이크아웃 플레이 정렬 및 confidence 0.82, risk 0.60 균형
- 상위 후보는 #1 005930 score 1.173; #2 000660 score 1.130; #3 047040 score 1.127입니다.
- 다른 후보가 밀린 이유는 000660 was weaker because score gap 0.043; lower confidence (0.785 vs 0.818); 047040 was weaker because score gap 0.046; higher risk (0.883 vs 0.600); lower confidence (0.757 vs 0.818)입니다.
- 최종 선정 판단은 highest total score (1.173); confidence 0.82 and risk 0.60; source mix: top_value, sector_theme; playbook alignment: breakout입니다.
- 최종 결정 기준은 Scanner selected the highest-ranked candidate after strategist-guided weighting, source scoring, and risk penalties.입니다.
- 동점 해소 기준은 score_total desc -> confidence desc -> risk_score asc입니다.
- 차순위 후보가 밀린 이유는 000660: lower total score (1.130 vs 1.173); lower confidence (0.78 vs 0.82); 047040: lower total score (1.127 vs 1.173); lower confidence (0.76 vs 0.82); higher risk (0.88 vs 0.60)입니다.
- 선정에 반영된 핵심 소스는 top_value, sector_theme입니다.
- 순위 산정 기준은 trading value, theme and sector alignment, sentiment support입니다.

## 진입 상세 근거

스캐너 랭킹 1위 근거로 BUY 진입 결정. 전략가 가이드에 따른 가중치 및 소스 스코어링, 리스크 페널티 적용 후 최고위 후보 선정.

- Scanner selected 005930 as rank #1 out of 5 candidates with score 1.173
- ranking_basis: trading value, theme and sector alignment, sentiment support
- tie_break_rule: score_total desc -> confidence desc -> risk_score asc
- 차트 분석 완결성 10/12 피처 캡처로 신뢰도 확보
- 최종 선정 판단은 highest total score (1.173)입니다.
- 최종 결정 기준은 Scanner selected the highest-ranked candidate after strategist-guided weighting, source scoring, and risk penalties.입니다.
- 진입 판단이 기록된 run은 b5f7339c70804fc8bc06f37ca5e71c1b입니다.
- 진입 시각은 2026-03-20T00:18:15+00:00입니다.
- 진입 액션은 매수입니다.
- 진입 판단 근거는 Scanner selected 005930 as rank #1 out of 5 candidates with score 1.173 because it led on trading value, theme and sector alignment, sentiment support.입니다.

## 보유 경과

진입 후 4.4시간(15,675초) 보유. 모니터는 250회 실행, 20회 이벤트 발생. 전체 구간 HOLD posture 유지했으나 피크 드로다운 -1.02% 도달 시 SELL 트리거.

- 보유 기간은 4.4시간 (15,675초)입니다.
- 모니터 실행 기록은 250회, 이벤트: 20회입니다.
- 모니터 판단 흐름은 HOLD -> HOLD -> HOLD -> HOLD (지속적 유지)입니다.
- 고정 손절 기준 8%, 상황 대응형 손절 기준, 목표 수익 실현 기준 4.76%, 추적 손절 기준 감시
- 피크 드로다운 -1.02% 도달 시 SELL 트리거
- 모니터는 총 250회 실행되었습니다.
- 현재 포지션 판단은 매도입니다.
- 감지된 핵심 신호는 고점 대비 하락폭입니다.
- 포지션 보유 시간은 약 15675초입니다.
- 유효 손절 기준은 3.00% 수준입니다, 기준 축은 고정 손절 기준입니다.
- 목표 수익 실현 기준은 4.76% 수준입니다.
- 현재 우선 감시 중인 청산 축은 고점 대비 하락폭입니다.

## 청산 판단 근거

피크 드로다운 트리거로 매도 결정. 현재가 199,700원, 평균 매입가 201,000원, 피크가 201,750원에서 -1.02% 드로다운 발생.

- 액션: SELL, 트리거 유형: peak_drawdown
- 현재가: 199,700원 (평균매입가 대비 -0.65%)
- 피크가: 201,750원에서 -1.02% 드로다운
- effective_stop_loss 3%보다恶化된 -1.02% 도달로 청산
- active_exit_axis: Peak Drawdown
- 감지된 핵심 신호는 고점 대비 하락폭입니다.
- 현재 우선 감시 중인 청산 축은 고점 대비 하락폭입니다.
- 청산 확인 조건은 0/2 단계로 기록되었습니다.
- 판단 흐름은 confirmed_exit_signal -> peak_drawdown -> peak_drawdown 순서로 이어졌습니다.
- 현재가, 평균가, 고점 기준 값은 199700.00 / 201000.00 / 201750.00입니다.
- 현재 손익 변동과 고점 대비 하락폭은 -1.02% / -1.02%입니다.

## 스캐너 후보 비교

스캐너 및 가드 체크 8개 게이트 중 4개 통과. 차트 완결성 10/12로 양호했으나 회전율 필터는 실패.

- 유동성 점검은 통과였습니다. 근거: top value 또는 trading-value 입력 지원
- 회전율 점검은 미통과였습니다. 근거: top volume 또는 turnover 입력 미지원
- 섹터·테마 정렬 점검은 통과였습니다. 근거: 테마 부스트 또는 섹터 소스와 전략가 프레임 일치
- 차트 지표 충실도 점검은 통과였습니다. 근거: 10/12 캡처된 차트 피처
- 유동성 점검은 통과였습니다. 근거: top value or trading-value input supported the selection
- 회전율 점검은 미통과였습니다. 근거: top volume or turnover input supported the selection
- 섹터·테마 정렬 점검은 통과였습니다. 근거: theme boost or sector source matched the strategist frame
- 차트 지표 충실도 점검은 통과였습니다. 근거: 10/12 captured chart features
- 시장 심리 점검은 통과였습니다. 근거: news/global sentiment contribution was 0.035
- 리스크 점검은 통과였습니다. 근거: risk score was 0.600 and supervisor allow=True
- 가격 이상치 점검은 확인 불가였습니다. 근거: price anomaly check was not captured in this run
- 호가 스프레드·슬리피지 점검은 확인 불가였습니다. 근거: spread or slippage diagnostics were not captured in this run

## 승인 및 가드 판단

슈퍼바이저가 Allowed 근거로 주문 승인. SELL 액션 검토 완료.

- 감독 승인 판단은 승인입니다.
- 주문 허용 여부는 허용입니다.
- 가드 판단 사유는 Allowed입니다.
- 검토한 액션은 매도입니다.
- 검토한 종목은 005930입니다.
- 승인 모드는 실행 추적에는 별도로 남아 있지 않습니다.

## 실행 결과

SELL 주문이 시뮬레이션 모드에서 성공적으로 기록됨. 수량 1개, 브로커 환경 미확인.

- 주문 실행 결과는 recorded입니다.
- 수량은 1입니다.
- 실행 모드는 simulation (mock broker)입니다.
- 브로커 환경 정보는 별도로 기록되지 않았습니다.
- Order status: not_captured
- Order number: not_captured

## 결과 평가

동일 날짜 리포터 파일은 존재하나 이 런에 연결된 런별 평가가 아직 없음. 중간 요약: 2026-03-20 런은 1개 트레이드(000660)만으로 제한된 활동, 전략가/스캐너 증거 부족.

- 같은 날 생성된 reporter 분석을 이 lifecycle에 연결해 전체 품질 평가를 완성해 주세요.
- Status: pending, Grade: C
- 전략가/스캐너 증거 부족 (테마 없음, 후보 공백)
- 1개 트레이드(000660), 4회 런 시도

## 보완 포인트

모니터와 스캐너 간 판단 괴리, 스톱로스 브리치, 부정적 매크로 regime 전환이 논리적 타당성 검증 필요.

- 동일 날짜 리포터 분석을 이 라이프사이클에 연결하여 완전한 품질 검토 필요
- 모니터와 스캐너 diverge: 스캐너는 bullish 신호였으나 모니터는 bearish 움직임 감지 실패
- stop-loss 브리치: effective_stop 3%보다恶化된 -1.02%에서 청산
- 부정적 매크로 regime 전환: 글로벌 감성 -0.07, VIX 24.06에서 브레이크아웃 실패
- 같은 날 생성된 reporter 분석을 이 lifecycle에 연결해 전체 품질 평가를 완성해 주세요.

## 전체 타임라인

- 진입: Entry BUY was executed by run b5f7339c70804fc8bc06f37ca5e71c1b.
- 보유 관리: Monitor posture=HOLD reason=hold exit=hold
- 보유 관리: Monitor posture=HOLD reason=hold exit=hold
- 보유 관리: Monitor posture=HOLD reason=hold exit=hold
- 보유 관리: Monitor posture=HOLD reason=hold exit=hold
- 보유 관리: Monitor posture=HOLD reason=hold exit=hold

## 최종 운영 판단

현재 라이프사이클 상태는 closed. 진입과 청산이 하나의 라이프사이클 스토리로 연결됨. 스캐너 1위 선정이었으나 시장 환경 불확실성 감지 실패로 손절.

- 현재 판단 액션은 매도입니다.
- 다음 확인 항목은 Lifecycle status: closed입니다.
- 다음 확인 항목은 Monitor trigger changes입니다.
- 다음 확인 항목은 Macro/news shifts입니다.
- 기존 판단이 무효화되는 조건은 stop-loss 브리치입니다.
- 기존 판단이 무효화되는 조건은 모니터와 스캐너 diverge입니다.
- 기존 판단이 무효화되는 조건은 부정적 매크로 regime 전환입니다.
