# Decision Story Report (2026-03-13)

- story_total: **356**
- rendered_story_total: **120**
- note: output truncated to first 120 runs

## Run 1bac177f42e84156ae4a216ac2196c91

- run_id: `1bac177f42e84156ae4a216ac2196c91`
- symbol: **032820**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 82f0a7f9f5b1476eb33dc8d594e6d60c

- run_id: `82f0a7f9f5b1476eb33dc8d594e6d60c`
- symbol: **357880**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: take_profit
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 51dbcc5ff2154312a7390e7573264e8f

- run_id: `51dbcc5ff2154312a7390e7573264e8f`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 87859b03a878484fb467824f0e48f67c

- run_id: `87859b03a878484fb467824f0e48f67c`
- symbol: **032820**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 5bf8f6f86efe4577a3e274dfbb3c8d3a

- run_id: `5bf8f6f86efe4577a3e274dfbb3c8d3a`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run trace-r2

- run_id: `trace-r2`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 888647b6b46a4781be5bcb41eb334edd

- run_id: `888647b6b46a4781be5bcb41eb334edd`
- symbol: **N/A**
- final_action: **BUY**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 691dc0cda2a34ada821af1ad4315a311

- run_id: `691dc0cda2a34ada821af1ad4315a311`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked by supervisor test rule
- operator_intervention: none
- final_outcome: blocked:denied_by_test

## Run 97123db769c14d64b76e2ce536e3d253

- run_id: `97123db769c14d64b76e2ce536e3d253`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 47bc201927764ceea124cf051933f986

- run_id: `47bc201927764ceea124cf051933f986`
- symbol: **005930**
- final_action: **SELL 20**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 2b4ab112663b455e9be69e44c91610a3

- run_id: `2b4ab112663b455e9be69e44c91610a3`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked duplicate buy (position already open)
- operator_intervention: none
- final_outcome: blocked:duplicate_buy_position_exists

## Run b586221dc4a54cbd9304eaa084530e47

- run_id: `b586221dc4a54cbd9304eaa084530e47`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Insufficient mock cash
- operator_intervention: none
- final_outcome: blocked:insufficient_mock_cash

## Run a555848d5c594be696fa6f085434e57d

- run_id: `a555848d5c594be696fa6f085434e57d`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run a9ed116eb93543028257b2c50abd0512

- run_id: `a9ed116eb93543028257b2c50abd0512`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run d634a41fc7db425580a2c09dbcd36be9

- run_id: `d634a41fc7db425580a2c09dbcd36be9`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 69eae09b171f489fae211b14c83af4ef

- run_id: `69eae09b171f489fae211b14c83af4ef`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run 58b3e587a026431f8b7d2e17b3091e7b

- run_id: `58b3e587a026431f8b7d2e17b3091e7b`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 6d061f3995dd4cba905db87101183255

- run_id: `6d061f3995dd4cba905db87101183255`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run b0e9c055b2c242b8a4506ce633d1d00d

- run_id: `b0e9c055b2c242b8a4506ce633d1d00d`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: rule:cash_and_price_ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 03e3d25c15274a929103435eb2c70e2c

- run_id: `03e3d25c15274a929103435eb2c70e2c`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash_and_price_ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 3fc8f1e31550456ea2d73605eed42dd0

- run_id: `3fc8f1e31550456ea2d73605eed42dd0`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash_and_price_ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 09f5848f3dc54f8881e6fdc953e05e49

- run_id: `09f5848f3dc54f8881e6fdc953e05e49`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: llm-buy
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 2b387d95d2244cb6a612133468714443

- run_id: `2b387d95d2244cb6a612133468714443`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash_and_price_ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 13125a0e83174cabb228cee635d5f2a8

- run_id: `13125a0e83174cabb228cee635d5f2a8`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: exit_policy_take_profit
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run a3e91a75cbb748e18f6ba59219cfb110

- run_id: `a3e91a75cbb748e18f6ba59219cfb110`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: exit_policy_max_hold
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 21ffafd28f34470086baaf6f2ecb4025

- run_id: `21ffafd28f34470086baaf6f2ecb4025`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Score override applied (buy composite=0.1130 regime=high_volatility)
- technical_evidence: rsi14=55.0, ma20_gap=0.015, atr14=650.0, volume_spike20=1.3, volatility20=0.05, regime=high_volatility
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_using_legacy_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run bd1f572307c54e61bf59a87bba6e5d65

- run_id: `bd1f572307c54e61bf59a87bba6e5d65`
- symbol: **005930**
- final_action: **SELL 16**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: EOD force liquidation (15:25)
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run af523bddce3546b79d2c44d594b85714

- run_id: `af523bddce3546b79d2c44d594b85714`
- symbol: **005930**
- final_action: **SELL 3**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: exit_policy_news_shock
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=-0.5, global_sentiment_score=-0.1, symbol_sentiment_status=ok, symbol_sentiment_source=test, symbol_sentiment_reason=fixture, global_sentiment_status=ok
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run f0aa1e9a28b64c4fba64273151793a13

- run_id: `f0aa1e9a28b64c4fba64273151793a13`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: recovered
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 7b6ceae5699241a99ae9beb44e5fe4a7

- run_id: `7b6ceae5699241a99ae9beb44e5fe4a7`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: entry_candidate_selected
- technical_evidence: playbook=pullback, candidate_pool_size=1, score_total=0.9426742310855611, risk_score=0.1147044928998788, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 58c7843214454541a01a9757054fd766

- run_id: `58c7843214454541a01a9757054fd766`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: entry_candidate_selected
- technical_evidence: playbook=pullback, candidate_pool_size=1, score_total=0.9426742310855611, risk_score=0.1147044928998788, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 33de7753c6ef44f6831918e4de22c1bc

- run_id: `33de7753c6ef44f6831918e4de22c1bc`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 12867f00ac1f41f8a669e74d8655f154

- run_id: `12867f00ac1f41f8a669e74d8655f154`
- symbol: **032820**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 5ab553e30f61452da24cb509f218bbfd

- run_id: `5ab553e30f61452da24cb509f218bbfd`
- symbol: **005860**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run d2d1393d3f87427194002564c36e2225

- run_id: `d2d1393d3f87427194002564c36e2225`
- symbol: **005860**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 8a3ea770238e45f0a8e5bfc8a8f5ccce

- run_id: `8a3ea770238e45f0a8e5bfc8a8f5ccce`
- symbol: **233740**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 86277ec152f64f0ca232584e7441fe36

- run_id: `86277ec152f64f0ca232584e7441fe36`
- symbol: **233740**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 64406162cdca40e984c03df056154fe0

- run_id: `64406162cdca40e984c03df056154fe0`
- symbol: **233740**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 081bfddefd4f4d22a57d91ec904de89c

- run_id: `081bfddefd4f4d22a57d91ec904de89c`
- symbol: **233740**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run d0a47ceeed53421689adff6d96b8a57a

- run_id: `d0a47ceeed53421689adff6d96b8a57a`
- symbol: **005860**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 79d04336b65640939d273a2b91fbe834

- run_id: `79d04336b65640939d273a2b91fbe834`
- symbol: **005860**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 0a05658a92514653a037a7782db7b067

- run_id: `0a05658a92514653a037a7782db7b067`
- symbol: **005860**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 049976e6bd9a4e4e9345427f0b7f97df

- run_id: `049976e6bd9a4e4e9345427f0b7f97df`
- symbol: **005860**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run f1b6bac7b1c344538625d468931cf05c

- run_id: `f1b6bac7b1c344538625d468931cf05c`
- symbol: **005860**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run ea15fbca7137450ea9420f8c711fe01a

- run_id: `ea15fbca7137450ea9420f8c711fe01a`
- symbol: **005860**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 8e861c7f21874143a6af25bb97e2d08c

- run_id: `8e861c7f21874143a6af25bb97e2d08c`
- symbol: **233740**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 37269a69769d4e3b9b2dbade9f7eda99

- run_id: `37269a69769d4e3b9b2dbade9f7eda99`
- symbol: **233740**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 4577bcc3fd8948e7b80d34e218a6755a

- run_id: `4577bcc3fd8948e7b80d34e218a6755a`
- symbol: **233740**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run fc86931f3ece400ba5d986e6eeeb8832

- run_id: `fc86931f3ece400ba5d986e6eeeb8832`
- symbol: **233740**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 3c8a2663f48b49baacd9ff6f40f7ad20

- run_id: `3c8a2663f48b49baacd9ff6f40f7ad20`
- symbol: **233740**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run cdd30fa5dde44101915221892a637fe4

- run_id: `cdd30fa5dde44101915221892a637fe4`
- symbol: **233740**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run b7bbd6833f144ac692982200ca0fb29d

- run_id: `b7bbd6833f144ac692982200ca0fb29d`
- symbol: **233740**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 86eb6f27ab1c42b3a4f9b65289da9a0d

- run_id: `86eb6f27ab1c42b3a4f9b65289da9a0d`
- symbol: **233740**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 0d992cdbde6b44c2b9a9f71cbfd0f002

- run_id: `0d992cdbde6b44c2b9a9f71cbfd0f002`
- symbol: **005860**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run c46f815522d04e02ad018892ec44107d

- run_id: `c46f815522d04e02ad018892ec44107d`
- symbol: **005860**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 8a75fce88fea4007b6fb48dfb974e68d

- run_id: `8a75fce88fea4007b6fb48dfb974e68d`
- symbol: **N/A**
- final_action: **BUY**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 8a17d664da69482982d297f39c81ecec

- run_id: `8a17d664da69482982d297f39c81ecec`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked by supervisor test rule
- operator_intervention: none
- final_outcome: blocked:denied_by_test

## Run 9be0a44e0b3e4a9f966f0ceb15f55b71

- run_id: `9be0a44e0b3e4a9f966f0ceb15f55b71`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 5ad490b3f27c4ebd8ebab8e62ea4c3ae

- run_id: `5ad490b3f27c4ebd8ebab8e62ea4c3ae`
- symbol: **005930**
- final_action: **SELL 20**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run a8838cd1c76f4612afea805ce8e2c953

- run_id: `a8838cd1c76f4612afea805ce8e2c953`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked duplicate buy (position already open)
- operator_intervention: none
- final_outcome: blocked:duplicate_buy_position_exists

## Run 4b09f8acbb96464e8cb2be10539f2213

- run_id: `4b09f8acbb96464e8cb2be10539f2213`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Insufficient mock cash
- operator_intervention: none
- final_outcome: blocked:insufficient_mock_cash

## Run fa8ed8a702ba4d45a273c210ddc31dfc

- run_id: `fa8ed8a702ba4d45a273c210ddc31dfc`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 0b08ddcab9054773a7ff0712254036d5

- run_id: `0b08ddcab9054773a7ff0712254036d5`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 053205b32a7d4f8298b0e62b70281d43

- run_id: `053205b32a7d4f8298b0e62b70281d43`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 2f13f33589c746db95aad2c088ca04fc

- run_id: `2f13f33589c746db95aad2c088ca04fc`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run 7193ea777bc443799609a8dd3aa24548

- run_id: `7193ea777bc443799609a8dd3aa24548`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run ba14ce25f92a4042a29c400ff42bef71

- run_id: `ba14ce25f92a4042a29c400ff42bef71`
- symbol: **N/A**
- final_action: **BUY**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 2109cfa116244328bc4697e78628e121

- run_id: `2109cfa116244328bc4697e78628e121`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked by supervisor test rule
- operator_intervention: none
- final_outcome: blocked:denied_by_test

## Run 6368d33cc17b41a0900f1e8cd65ca944

- run_id: `6368d33cc17b41a0900f1e8cd65ca944`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 8e0cef0a8d4d43dfbaa971d2ff297381

- run_id: `8e0cef0a8d4d43dfbaa971d2ff297381`
- symbol: **005930**
- final_action: **SELL 20**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run f186030725e24ce988b5bbd37362f6ca

- run_id: `f186030725e24ce988b5bbd37362f6ca`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked duplicate buy (position already open)
- operator_intervention: none
- final_outcome: blocked:duplicate_buy_position_exists

## Run 757dc4d695824eba8bd3d0d850610019

- run_id: `757dc4d695824eba8bd3d0d850610019`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Insufficient mock cash
- operator_intervention: none
- final_outcome: blocked:insufficient_mock_cash

## Run 95bd651e5f5c477c8eb669b497817b1e

- run_id: `95bd651e5f5c477c8eb669b497817b1e`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 4570ae06d3d54eae84a90a3b261f97bb

- run_id: `4570ae06d3d54eae84a90a3b261f97bb`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run d8c1fa9240bc4f05a7e1fc945523d33c

- run_id: `d8c1fa9240bc4f05a7e1fc945523d33c`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run b06a3daf69e04967b2d997210c003693

- run_id: `b06a3daf69e04967b2d997210c003693`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run 292abdd6339342e780d8a3f3e71faa43

- run_id: `292abdd6339342e780d8a3f3e71faa43`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 90d7564866e74dde8883279e85b4a345

- run_id: `90d7564866e74dde8883279e85b4a345`
- symbol: **005860**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run a0fda3129c174d3b90de0948a52c81ff

- run_id: `a0fda3129c174d3b90de0948a52c81ff`
- symbol: **N/A**
- final_action: **BUY**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run cdd5ff71ca3b4d65948318ed6045c341

- run_id: `cdd5ff71ca3b4d65948318ed6045c341`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked by supervisor test rule
- operator_intervention: none
- final_outcome: blocked:denied_by_test

## Run e846927697684acea2bc14c5445c26e1

- run_id: `e846927697684acea2bc14c5445c26e1`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run df1c388e00084f84bec3e5ae56e38c9d

- run_id: `df1c388e00084f84bec3e5ae56e38c9d`
- symbol: **005930**
- final_action: **SELL 20**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run c2f246545b7942dd95b6990d9e9764f2

- run_id: `c2f246545b7942dd95b6990d9e9764f2`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked duplicate buy (position already open)
- operator_intervention: none
- final_outcome: blocked:duplicate_buy_position_exists

## Run aa4c9f3a67474d219a0c380a0a0666ac

- run_id: `aa4c9f3a67474d219a0c380a0a0666ac`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Insufficient mock cash
- operator_intervention: none
- final_outcome: blocked:insufficient_mock_cash

## Run 2c93efdd7c734a87942929ceeb4322f6

- run_id: `2c93efdd7c734a87942929ceeb4322f6`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 0fb469a5961c45d8bcc12435ed3c43f6

- run_id: `0fb469a5961c45d8bcc12435ed3c43f6`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 9901f1d3c2c740e7867e541327352a5d

- run_id: `9901f1d3c2c740e7867e541327352a5d`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 2ef1680db1b24884bcfd11f305a4e57c

- run_id: `2ef1680db1b24884bcfd11f305a4e57c`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run b6b6eb811c8b424c932b35009a0847ae

- run_id: `b6b6eb811c8b424c932b35009a0847ae`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run b322b4bad4694d83a30d996807849864

- run_id: `b322b4bad4694d83a30d996807849864`
- symbol: **N/A**
- final_action: **BUY**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 22f1c7637afb41e884720589b7d7f67d

- run_id: `22f1c7637afb41e884720589b7d7f67d`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked by supervisor test rule
- operator_intervention: none
- final_outcome: blocked:denied_by_test

## Run 75beb04279994821a5e9990b9e3ba829

- run_id: `75beb04279994821a5e9990b9e3ba829`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 0af4da673cf640bf92b46fd1be84b965

- run_id: `0af4da673cf640bf92b46fd1be84b965`
- symbol: **005930**
- final_action: **SELL 20**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run e3a82cd574604d9ab746ca5b3cee140a

- run_id: `e3a82cd574604d9ab746ca5b3cee140a`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked duplicate buy (position already open)
- operator_intervention: none
- final_outcome: blocked:duplicate_buy_position_exists

## Run 9c6dbb737d8e424999d812db8be8b6ad

- run_id: `9c6dbb737d8e424999d812db8be8b6ad`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Insufficient mock cash
- operator_intervention: none
- final_outcome: blocked:insufficient_mock_cash

## Run 6b9bca04cede42f89e50a9ea1d64fd23

- run_id: `6b9bca04cede42f89e50a9ea1d64fd23`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 6d95b3b69d2e4ea18912aebbf5aa74e9

- run_id: `6d95b3b69d2e4ea18912aebbf5aa74e9`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 7eae96dbed734b91ba608e5b54994948

- run_id: `7eae96dbed734b91ba608e5b54994948`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run b280d7b0b26348d5bd2f4600d3621eb9

- run_id: `b280d7b0b26348d5bd2f4600d3621eb9`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run 643e460592464c3a972c99bf845d820b

- run_id: `643e460592464c3a972c99bf845d820b`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 6448c0fc963746e1845655f48159ae87

- run_id: `6448c0fc963746e1845655f48159ae87`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 70c2b019fb4e42ca84cb17fdc72ff7ff

- run_id: `70c2b019fb4e42ca84cb17fdc72ff7ff`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: rule:cash_and_price_ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 84a871ce49b5479cbfadf44805e8cd7d

- run_id: `84a871ce49b5479cbfadf44805e8cd7d`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash_and_price_ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 84c7499d07624d3c95996df780132c84

- run_id: `84c7499d07624d3c95996df780132c84`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash_and_price_ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 1dc211e72252487d85f4e12e0f799641

- run_id: `1dc211e72252487d85f4e12e0f799641`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: llm-buy
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 089b7af7e6a74797a49f6fa42c3ccf37

- run_id: `089b7af7e6a74797a49f6fa42c3ccf37`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash_and_price_ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 4a476a2a215e405ba5dd9a565f3b4b10

- run_id: `4a476a2a215e405ba5dd9a565f3b4b10`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: exit_policy_take_profit
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 77c38d9bda974beb9cef19d44a9a5831

- run_id: `77c38d9bda974beb9cef19d44a9a5831`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: exit_policy_max_hold
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 6af03563c1a5428e8a1876bb169bb335

- run_id: `6af03563c1a5428e8a1876bb169bb335`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Score override applied (buy composite=0.1130 regime=high_volatility)
- technical_evidence: rsi14=55.0, ma20_gap=0.015, atr14=650.0, volume_spike20=1.3, volatility20=0.05, regime=high_volatility
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_using_legacy_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run b9f5d49691ff48038feedd7c9d9a5de1

- run_id: `b9f5d49691ff48038feedd7c9d9a5de1`
- symbol: **005930**
- final_action: **SELL 16**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: EOD force liquidation (15:25)
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run c1152f55c8344275bdf61499ddfcf6e7

- run_id: `c1152f55c8344275bdf61499ddfcf6e7`
- symbol: **005930**
- final_action: **SELL 3**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: exit_policy_news_shock
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=-0.5, global_sentiment_score=-0.1, symbol_sentiment_status=ok, symbol_sentiment_source=test, symbol_sentiment_reason=fixture, global_sentiment_status=ok
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 06a15ffa392c4180b812d23b88c4fc9b

- run_id: `06a15ffa392c4180b812d23b88c4fc9b`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: recovered
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 1255b836814e47cc889d2ba099d5a050

- run_id: `1255b836814e47cc889d2ba099d5a050`
- symbol: **005860**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: stop_loss_pct=0.01, take_profit_pct=0.01, max_hold_sec=60, time_stop_sec=60, trailing_stop_pct=0.0, vol_expansion_ratio=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 7bbddad2a31b44879f089faa2924e830

- run_id: `7bbddad2a31b44879f089faa2924e830`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: entry_candidate_selected
- technical_evidence: playbook=pullback, candidate_pool_size=1, score_total=0.9426890372063378, risk_score=0.11467517384883594, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run b0c5ecc55fbb4ec1ab480695e3467d08

- run_id: `b0c5ecc55fbb4ec1ab480695e3467d08`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: entry_candidate_selected
- technical_evidence: playbook=pullback, candidate_pool_size=1, score_total=0.9426890372063378, risk_score=0.11467517384883594, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run b9134fcb29eb4de68c311f1df6f4be82

- run_id: `b9134fcb29eb4de68c311f1df6f4be82`
- symbol: **N/A**
- final_action: **BUY**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 2cd8e8d61db84fd68dce3591fcadece7

- run_id: `2cd8e8d61db84fd68dce3591fcadece7`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked by supervisor test rule
- operator_intervention: none
- final_outcome: blocked:denied_by_test

## Run f6f2d37790154bc49547d008842862f7

- run_id: `f6f2d37790154bc49547d008842862f7`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run b470744409434759b40b577e8a6d495c

- run_id: `b470744409434759b40b577e8a6d495c`
- symbol: **005930**
- final_action: **SELL 20**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 88c033288402490393f66c22f211626a

- run_id: `88c033288402490393f66c22f211626a`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked duplicate buy (position already open)
- operator_intervention: none
- final_outcome: blocked:duplicate_buy_position_exists
