# Decision Story Report (2026-03-11)

- story_total: **96**
- rendered_story_total: **96**

## Run 844e3637393746229455f6e76e94de62

- run_id: `844e3637393746229455f6e76e94de62`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 17a945cea025441db4c011818a8b65a5

- run_id: `17a945cea025441db4c011818a8b65a5`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 3ce0c024c3f8427087cb6c00180d6b57

- run_id: `3ce0c024c3f8427087cb6c00180d6b57`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run ff798fd7113e47bca202200cb552f7eb

- run_id: `ff798fd7113e47bca202200cb552f7eb`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run b8021461bd5c404093a65c7904de247f

- run_id: `b8021461bd5c404093a65c7904de247f`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 2512a634535e4d1bbc2872eb1975f28a

- run_id: `2512a634535e4d1bbc2872eb1975f28a`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 6aa2ecbb573041c6a0e797749a41c6db

- run_id: `6aa2ecbb573041c6a0e797749a41c6db`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 2ba710f938eb430f8435426488d08180

- run_id: `2ba710f938eb430f8435426488d08180`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 87199de38efd44c4a854e2f42327433c

- run_id: `87199de38efd44c4a854e2f42327433c`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 32957d80fadf45cb8dec0d273a5071a8

- run_id: `32957d80fadf45cb8dec0d273a5071a8`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 90a0f49c55664af98c465e24a8607ac0

- run_id: `90a0f49c55664af98c465e24a8607ac0`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 40e68a5d63144846ac992e7e337e7958

- run_id: `40e68a5d63144846ac992e7e337e7958`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run f0d83b49f2cf4aa48d8e05da83279d40

- run_id: `f0d83b49f2cf4aa48d8e05da83279d40`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 102bd0aae31d4cf4a81a3aa4739ca6fc

- run_id: `102bd0aae31d4cf4a81a3aa4739ca6fc`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run fc6df2ffb2f14c0ca1f084b3393f560c

- run_id: `fc6df2ffb2f14c0ca1f084b3393f560c`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 568ed2cb12df4a5d9dd38953de8acad1

- run_id: `568ed2cb12df4a5d9dd38953de8acad1`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 3a1ad6eb69634acb9ad1701c280ccb4e

- run_id: `3a1ad6eb69634acb9ad1701c280ccb4e`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run c7de7c5bee3e4f0caf5bf99d229ce575

- run_id: `c7de7c5bee3e4f0caf5bf99d229ce575`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run b61726e7248d40448d315790eff7e630

- run_id: `b61726e7248d40448d315790eff7e630`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 63804470e37e4ed39b6d108438806160

- run_id: `63804470e37e4ed39b6d108438806160`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 91e85400fe8146ac9d4ff0da84565c75

- run_id: `91e85400fe8146ac9d4ff0da84565c75`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 97fc23a8fa5742bf8c3d91f03bbba548

- run_id: `97fc23a8fa5742bf8c3d91f03bbba548`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 63230c85e6ba492cb960b0aef2654cf5

- run_id: `63230c85e6ba492cb960b0aef2654cf5`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 957c21753b354db7aed64c806338b7c2

- run_id: `957c21753b354db7aed64c806338b7c2`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 17b37b03e49e425a94a31e76bd868e3a

- run_id: `17b37b03e49e425a94a31e76bd868e3a`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run e387bbd95e4e4f4797284f8b1f3ec3ce

- run_id: `e387bbd95e4e4f4797284f8b1f3ec3ce`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 572dde3b35b446be99f5ed9ec3dd9dcc

- run_id: `572dde3b35b446be99f5ed9ec3dd9dcc`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 55c1fa2877024f03b6a31cecaba68109

- run_id: `55c1fa2877024f03b6a31cecaba68109`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 1621e53a24f747c7b0eb1e03335072c5

- run_id: `1621e53a24f747c7b0eb1e03335072c5`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run b8267771111e416b8dc32928c9629367

- run_id: `b8267771111e416b8dc32928c9629367`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 3e52678ef53d4619a781481e3afc9379

- run_id: `3e52678ef53d4619a781481e3afc9379`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run f2ae134edec94d71b07acd53c1ce92ea

- run_id: `f2ae134edec94d71b07acd53c1ce92ea`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run d2afb6d18443426f9e5f3f748288539a

- run_id: `d2afb6d18443426f9e5f3f748288539a`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 6f86731c4e664410ab361bf2ab6552aa

- run_id: `6f86731c4e664410ab361bf2ab6552aa`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run ffd80731cfdf40dc8bf01b674af813c4

- run_id: `ffd80731cfdf40dc8bf01b674af813c4`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 1bbe09f5884d45ecb9bf8813d67234ce

- run_id: `1bbe09f5884d45ecb9bf8813d67234ce`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 2439f7ba767f46b29d415adf40267b6c

- run_id: `2439f7ba767f46b29d415adf40267b6c`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 94db63299cbc4109a2c490bc882ca047

- run_id: `94db63299cbc4109a2c490bc882ca047`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run e764272e162b4887b41f001ecd299964

- run_id: `e764272e162b4887b41f001ecd299964`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 180371a67ed64bbeb8b4ac50240450df

- run_id: `180371a67ed64bbeb8b4ac50240450df`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run a6261dcdb31a475c979873e4ed9b4a1c

- run_id: `a6261dcdb31a475c979873e4ed9b4a1c`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run a15c33c787234d4695b9dd7b17e4fb69

- run_id: `a15c33c787234d4695b9dd7b17e4fb69`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 52782800c008414e9d958c2b036b26c7

- run_id: `52782800c008414e9d958c2b036b26c7`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 77dc20700b224b8da08e36e9ef06d436

- run_id: `77dc20700b224b8da08e36e9ef06d436`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 7dbb43ffc3ea442d8368583c1e515090

- run_id: `7dbb43ffc3ea442d8368583c1e515090`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 265ade3140804735a85a46b8ffca296c

- run_id: `265ade3140804735a85a46b8ffca296c`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 2ec1464283054b549f8a897a6fb1debf

- run_id: `2ec1464283054b549f8a897a6fb1debf`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 539264ebd0fe4816acbd4834ccde92ae

- run_id: `539264ebd0fe4816acbd4834ccde92ae`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run e28baef53aef4b838069bdad25828ef0

- run_id: `e28baef53aef4b838069bdad25828ef0`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 07e864fe5fbb47f8bd77da6d2ba67075

- run_id: `07e864fe5fbb47f8bd77da6d2ba67075`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run a6cb4622721c4102bf9542ae15d618fe

- run_id: `a6cb4622721c4102bf9542ae15d618fe`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 7fa6a4a6f4ef4b79932d33559ac42724

- run_id: `7fa6a4a6f4ef4b79932d33559ac42724`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run bda78e9880f84f10b45fc23c1ccacb6a

- run_id: `bda78e9880f84f10b45fc23c1ccacb6a`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 76de9e6416e643e3be6a4cd86faf0a61

- run_id: `76de9e6416e643e3be6a4cd86faf0a61`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run f985e2ebea1342829226631c5cd622c9

- run_id: `f985e2ebea1342829226631c5cd622c9`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 1daa277da04a4c239bd7780a8611f85a

- run_id: `1daa277da04a4c239bd7780a8611f85a`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 7bbfee51732b4c8291942954cd28fe6f

- run_id: `7bbfee51732b4c8291942954cd28fe6f`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 0a8d66f69b524acbafa774231c36ea1a

- run_id: `0a8d66f69b524acbafa774231c36ea1a`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run fc201c57095946db8a86d267876cd480

- run_id: `fc201c57095946db8a86d267876cd480`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 34f54000802447a4bfb9ec01ce8a833c

- run_id: `34f54000802447a4bfb9ec01ce8a833c`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 9b4b4e45479b40bf8d37776d837d38bf

- run_id: `9b4b4e45479b40bf8d37776d837d38bf`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run bdeb87eb076b47babc5825d6f19a41d3

- run_id: `bdeb87eb076b47babc5825d6f19a41d3`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 32602144118b4ff8a8e901e7c31013a2

- run_id: `32602144118b4ff8a8e901e7c31013a2`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 4a95713d80ed40a78b34fabf33f1a177

- run_id: `4a95713d80ed40a78b34fabf33f1a177`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run a86c4f29928a4e8696012cbb950a9617

- run_id: `a86c4f29928a4e8696012cbb950a9617`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run e5a784be7f104176a10dd2c6a015d31a

- run_id: `e5a784be7f104176a10dd2c6a015d31a`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run e2c0df366d5b4cf5a901ee384b7034cc

- run_id: `e2c0df366d5b4cf5a901ee384b7034cc`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 5b367cb45fe641f2bce2dfd5f608ca21

- run_id: `5b367cb45fe641f2bce2dfd5f608ca21`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 54c27695bb9e4872b8b26d458f3ec2f1

- run_id: `54c27695bb9e4872b8b26d458f3ec2f1`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 84e8a17115984b7c9c188f4181f94fd2

- run_id: `84e8a17115984b7c9c188f4181f94fd2`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 01092168749d4b51b4cff9434cde241c

- run_id: `01092168749d4b51b4cff9434cde241c`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 28d5a5f448f244c89fcbe2a12624c22b

- run_id: `28d5a5f448f244c89fcbe2a12624c22b`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 125a4620034e428e894ed9803b727f29

- run_id: `125a4620034e428e894ed9803b727f29`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run f2aaa6595a3a432e8cc9a0957a67b916

- run_id: `f2aaa6595a3a432e8cc9a0957a67b916`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 58a4cafabe3c4ffea6f942e7fab00930

- run_id: `58a4cafabe3c4ffea6f942e7fab00930`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 1ac04f2d19d644029db3f78802ac6b8e

- run_id: `1ac04f2d19d644029db3f78802ac6b8e`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 30755cea31b04df0bf74f744de089c14

- run_id: `30755cea31b04df0bf74f744de089c14`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 17833caf2cd040efb520c257d4291cf5

- run_id: `17833caf2cd040efb520c257d4291cf5`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 5fe2b1e071e64929ba20d07f60580f11

- run_id: `5fe2b1e071e64929ba20d07f60580f11`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 4feb13a6af1044c086c1d4a1ffd2f75d

- run_id: `4feb13a6af1044c086c1d4a1ffd2f75d`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 4bb53485c00e437a91d0c849cf611feb

- run_id: `4bb53485c00e437a91d0c849cf611feb`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 2a5f1afeab87461eb68b1f8bf2d43029

- run_id: `2a5f1afeab87461eb68b1f8bf2d43029`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run b4fdf2fa32ef4f8f9077756e632c4fae

- run_id: `b4fdf2fa32ef4f8f9077756e632c4fae`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 62325c0389c04d69b2cd8255cacf34af

- run_id: `62325c0389c04d69b2cd8255cacf34af`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 04152e8c519b4a859fb3898bfbe44ec4

- run_id: `04152e8c519b4a859fb3898bfbe44ec4`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 21b57f9f28ca43f19e4c058fcff3b034

- run_id: `21b57f9f28ca43f19e4c058fcff3b034`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run a8a6b34ee01e471cbaf363ab8531b04d

- run_id: `a8a6b34ee01e471cbaf363ab8531b04d`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run b2cc5e9835394f008b069a7ef8abb45f

- run_id: `b2cc5e9835394f008b069a7ef8abb45f`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 33b57231159b4cc6b0b98a2514ef94e2

- run_id: `33b57231159b4cc6b0b98a2514ef94e2`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 8866ff8f568c497fbfcd057a3396fc10

- run_id: `8866ff8f568c497fbfcd057a3396fc10`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run c7efc9ea25fc4e4192f9500f8a91950a

- run_id: `c7efc9ea25fc4e4192f9500f8a91950a`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 8d5cf8ca96ce4202b97023758b455dbf

- run_id: `8d5cf8ca96ce4202b97023758b455dbf`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run b2797a0719dc4d4e9165f79a5ef2837c

- run_id: `b2797a0719dc4d4e9165f79a5ef2837c`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run fd1576d36db846e590df85a1fca7c070

- run_id: `fd1576d36db846e590df85a1fca7c070`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 4a4865c500ce4c5ba23ba01f0f232b83

- run_id: `4a4865c500ce4c5ba23ba01f0f232b83`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 1d800a57684f4419a7d09bf8663b8c0d

- run_id: `1d800a57684f4419a7d09bf8663b8c0d`
- symbol: **051910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted
