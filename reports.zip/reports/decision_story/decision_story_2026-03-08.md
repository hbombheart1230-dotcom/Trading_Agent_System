# Decision Story Report (2026-03-08)

- story_total: **33**
- rendered_story_total: **33**

## Run 6c8d4fe46c164de38062ce4dcb378027

- run_id: `6c8d4fe46c164de38062ce4dcb378027`
- symbol: **N/A**
- final_action: **BUY**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 0aaa6b7b583b49289bf2ec20fce640ec

- run_id: `0aaa6b7b583b49289bf2ec20fce640ec`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked by supervisor test rule
- operator_intervention: none
- final_outcome: blocked:denied_by_test

## Run b67c98d426b24045a1550bca81e3271c

- run_id: `b67c98d426b24045a1550bca81e3271c`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 544a709bc69d459d9f7bd5c3618cdc37

- run_id: `544a709bc69d459d9f7bd5c3618cdc37`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked duplicate buy (position already open)
- operator_intervention: none
- final_outcome: blocked:duplicate_buy_position_exists

## Run b6f71daf33a04bcfa792c46e929e46da

- run_id: `b6f71daf33a04bcfa792c46e929e46da`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Insufficient mock cash
- operator_intervention: none
- final_outcome: blocked:insufficient_mock_cash

## Run cd9965ecb95147c7a834ef3f8278074f

- run_id: `cd9965ecb95147c7a834ef3f8278074f`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 43989a989eae4535bcb3c54f2cf8aaf0

- run_id: `43989a989eae4535bcb3c54f2cf8aaf0`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 5e1f7793a3884addbbd0fec887975881

- run_id: `5e1f7793a3884addbbd0fec887975881`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 65c5674c5f0e4ab5bb8559a61143fe6a

- run_id: `65c5674c5f0e4ab5bb8559a61143fe6a`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run 300684c9dc1c46fc8961c09114d13486

- run_id: `300684c9dc1c46fc8961c09114d13486`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 7942684f11c44a558751007524b4ca9b

- run_id: `7942684f11c44a558751007524b4ca9b`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run d4ea1c0fc3f44243a9e9d78d53c04391

- run_id: `d4ea1c0fc3f44243a9e9d78d53c04391`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 05cb9dce8333494b9557091d4369fc45

- run_id: `05cb9dce8333494b9557091d4369fc45`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash_and_price_ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 2952fddd66ba47669611ffba0b209503

- run_id: `2952fddd66ba47669611ffba0b209503`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash_and_price_ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run c971acf96b994aabb3b8284da2902c5c

- run_id: `c971acf96b994aabb3b8284da2902c5c`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: llm-buy
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 9f88e1097cc04056a287ff9ea0368ac5

- run_id: `9f88e1097cc04056a287ff9ea0368ac5`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Score override applied (buy composite=0.4330 regime=trend)
- technical_evidence: rsi14=61.2, ma20_gap=0.015, atr14=650.0, volume_spike20=1.3, volatility20=0.02, regime=trend
- sentiment_evidence: symbol_sentiment_score=0.2, global_sentiment_score=0.1, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_using_legacy_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run f4183c45b89e4cdd8d7b49d541d3b250

- run_id: `f4183c45b89e4cdd8d7b49d541d3b250`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Score override applied (buy composite=0.1100 regime=trend)
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=trend
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=unavailable, symbol_sentiment_source=scorer:openrouter, symbol_sentiment_reason=scorer_error:TimeoutError, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run d88b47a7aee74f57991c0c1b422dd8f6

- run_id: `d88b47a7aee74f57991c0c1b422dd8f6`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash_and_price_ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run fabf2b61e6774476b798f56fe677f29c

- run_id: `fabf2b61e6774476b798f56fe677f29c`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Exit policy triggered (take profit)
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run d3e69e5ab32941ef91ce27228d08555e

- run_id: `d3e69e5ab32941ef91ce27228d08555e`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 437546526b5c4935b8be8d77725511f4

- run_id: `437546526b5c4935b8be8d77725511f4`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Score override applied (buy composite=0.1130 regime=high_volatility)
- technical_evidence: rsi14=55.0, ma20_gap=0.015, atr14=650.0, volume_spike20=1.3, volatility20=0.05, regime=high_volatility
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_using_legacy_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 2ab32bc918f4445aac0e1c06778a8aab

- run_id: `2ab32bc918f4445aac0e1c06778a8aab`
- symbol: **005930**
- final_action: **SELL 16**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: EOD force liquidation (15:25)
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run a5a6e36aae694eb1b0dee39ec81bf7a0

- run_id: `a5a6e36aae694eb1b0dee39ec81bf7a0`
- symbol: **005930**
- final_action: **SELL 3**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Exit policy triggered (news shock)
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=-0.5, global_sentiment_score=-0.1, symbol_sentiment_status=ok, symbol_sentiment_source=test, symbol_sentiment_reason=fixture, global_sentiment_status=ok
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run a1692223f4094ffc84553e3ac5f15192

- run_id: `a1692223f4094ffc84553e3ac5f15192`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: recovered
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 4be7e7a471f9438e812232f3bcfe4d21

- run_id: `4be7e7a471f9438e812232f3bcfe4d21`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run f0a2310762374d50a0cbeae24d772cfe

- run_id: `f0a2310762374d50a0cbeae24d772cfe`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 3a15f6d7cd2e40779c673a1ff16fa2a1

- run_id: `3a15f6d7cd2e40779c673a1ff16fa2a1`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash_and_price_ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run c059fdce43fb47dbb457fdebf3f5a0a1

- run_id: `c059fdce43fb47dbb457fdebf3f5a0a1`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash_and_price_ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 20f6c045bcd7445180baa891cd52d403

- run_id: `20f6c045bcd7445180baa891cd52d403`
- symbol: **005930**
- final_action: **BUY 3**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: news_momentum_v1_entry: symbol_news=0.720 signal=0.320
- technical_evidence: signal_score=0.32, volatility20=0.05, composite_score=0.536
- sentiment_evidence: symbol_sentiment_score=0.72, global_sentiment_score=0.2, symbol_sentiment_status=ok, global_sentiment_status=ok
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 8267a9e68ab542cb9e47f918b6e26a44

- run_id: `8267a9e68ab542cb9e47f918b6e26a44`
- symbol: **005930**
- final_action: **BUY 3**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: strategy_v1_entry: composite=0.4240 regime=trend
- technical_evidence: signal_score=0.7, ma20_gap=0.02, volatility20=0.03, rsi14=58.0, composite_score=0.424
- sentiment_evidence: symbol_sentiment_score=0.3, global_sentiment_score=0.1
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 46bda94ac8044623ab844dcb26afc0b2

- run_id: `46bda94ac8044623ab844dcb26afc0b2`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash_and_price_ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run bedbbbacb5db45fabe73d63f8f9ef1e0

- run_id: `bedbbbacb5db45fabe73d63f8f9ef1e0`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash_and_price_ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 5601f10a77fb46e7a5e9181bf1a0c8d0

- run_id: `5601f10a77fb46e7a5e9181bf1a0c8d0`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash_and_price_ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0, symbol_sentiment_status=fallback, symbol_sentiment_source=legacy_news_sentiment, symbol_sentiment_reason=signal_missing_no_score, global_sentiment_status=fallback
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only
