# Decision Story Report (2026-03-10)

- story_total: **935**
- rendered_story_total: **120**
- note: output truncated to first 120 runs

## Run 678cf33aa7b848a9b95aa7f4058fa22b

- run_id: `678cf33aa7b848a9b95aa7f4058fa22b`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.05780770588395012, volatility20=0.055739863793839474, rsi14=47.92176039119804, composite_score=-0.27709963141548216
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04461909761307881
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 3d81f378160c4fed9bc692915c0ba378

- run_id: `3d81f378160c4fed9bc692915c0ba378`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2370 regime=high_volatility
- technical_evidence: signal_score=0.5, ma20_gap=0.012528627239660528, volatility20=0.05651006816162046, rsi14=52.4907063197026, composite_score=0.23696763520923997
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04461909761307881
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 18c2b1bc5a1d4ac9b88ca6805c4abd11

- run_id: `18c2b1bc5a1d4ac9b88ca6805c4abd11`
- symbol: **005930**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.012528627239660528, volatility20=0.05651006816162046, rsi14=52.4907063197026, composite_score=0.23696763520923997
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04461909761307881
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 3d65eca9f72840eea4a987212c22185d

- run_id: `3d65eca9f72840eea4a987212c22185d`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.012528627239660528, volatility20=0.05651006816162046, rsi14=52.4907063197026, composite_score=0.23696763520923997
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04461909761307881
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run d908d0ed017f4c2caa7f6d8cd80adf58

- run_id: `d908d0ed017f4c2caa7f6d8cd80adf58`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.010099941832795722, volatility20=0.05577834448252664, rsi14=47.653721682847895, composite_score=-0.26755807860525127
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04461909761307881
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 1aa5e086ea394bdc98a82b086b833906

- run_id: `1aa5e086ea394bdc98a82b086b833906`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.01615194402062403, volatility20=0.055800010915698535, rsi14=44.43493150684932, composite_score=-0.2687750325554723
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04455356248652503
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 3374fca407d0411da73214c8d3bf1196

- run_id: `3374fca407d0411da73214c8d3bf1196`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.01882037955744542, volatility20=0.05423553686079508, rsi14=42.68077601410934, composite_score=-0.2693087196628366
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04455356248652503
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run dbddd7b468b744868c8af345d0766376

- run_id: `dbddd7b468b744868c8af345d0766376`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.02377644375704513, volatility20=0.054200113389855725, rsi14=34.036144578313255, composite_score=-0.2702999325027565
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04455356248652503
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 87d6bfebab32487eb88af4c560234130

- run_id: `87d6bfebab32487eb88af4c560234130`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.02729658792650924, volatility20=0.05318817226564403, rsi14=34.24242424242425, composite_score=-0.27100396133664933
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04455356248652503
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 6267e8b67ff6475d8e2a51e06098d0d4

- run_id: `6267e8b67ff6475d8e2a51e06098d0d4`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.02481966653089651, volatility20=0.053188742469936406, rsi14=43.86640976236352, composite_score=-0.2705085770575268
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04455356248652503
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run cb741481016f43bd9b441e4f9b548027

- run_id: `cb741481016f43bd9b441e4f9b548027`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.0, ma20_gap=-0.02065316115784066, volatility20=0.0530808128082038, rsi14=62.454873646209386, composite_score=-0.01967376451796593
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04456867713602206
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run c80a3f86eeb4419db7e9d8826ebd58f5

- run_id: `c80a3f86eeb4419db7e9d8826ebd58f5`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.011002073620118069, volatility20=0.052444295800461276, rsi14=44.08602150537634, composite_score=-0.2677435470104214
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04456867713602206
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run ef5be62905374c9e958831b8c3ee639c

- run_id: `ef5be62905374c9e958831b8c3ee639c`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.011264578274887582, volatility20=0.05225648057593515, rsi14=47.262247838616716, composite_score=-0.26779604794137535
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04456867713602206
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 459ba5e2bb804a5e8c2f654e206e699a

- run_id: `459ba5e2bb804a5e8c2f654e206e699a`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=-0.00033447053314605846, volatility20=0.049444335337661134, rsi14=82.4390243902439, composite_score=-0.11561002639302702
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04456867713602206
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 18943a405e964e14a03c38e2a847f2b4

- run_id: `18943a405e964e14a03c38e2a847f2b4`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.006648954104683913, volatility20=0.04945804727226098, rsi14=81.64251207729468, composite_score=-0.11421334146546101
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04456867713602206
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 06e25ba2eca74fc49395dbe8dc09e4ff

- run_id: `06e25ba2eca74fc49395dbe8dc09e4ff`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.0, ma20_gap=0.01101574643508818, volatility20=0.04466057891738064, rsi14=43.28358208955223, composite_score=-0.013350567142838754
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04446283570143613
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run f9e2fc3d7bc54d82854f4d3de966f6a8

- run_id: `f9e2fc3d7bc54d82854f4d3de966f6a8`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2364 regime=high_volatility
- technical_evidence: signal_score=0.5, ma20_gap=0.009543551708820708, volatility20=0.03582498165915517, rsi14=53.125, composite_score=0.23635499391190776
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04446283570143613
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 65219cd36eec46b7a3d254a0010b0a23

- run_id: `65219cd36eec46b7a3d254a0010b0a23`
- symbol: **005930**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.009543551708820708, volatility20=0.03582498165915517, rsi14=53.125, composite_score=0.23635499391190776
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04446283570143613
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 96f9dcd3ea6943eab051fc595f9d3d27

- run_id: `96f9dcd3ea6943eab051fc595f9d3d27`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.009543551708820708, volatility20=0.03582498165915517, rsi14=53.125, composite_score=0.23635499391190776
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04446283570143613
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 08cda0a38432400d8f31d1591dc92e65

- run_id: `08cda0a38432400d8f31d1591dc92e65`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2361 regime=trend
- technical_evidence: signal_score=0.5, ma20_gap=0.00841689823204872, volatility20=0.01830326573673543, rsi14=56.060606060606055, composite_score=0.23612966321655335
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04446283570143613
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 73579a1591ec4a8fbd61fa9ec9fda28c

- run_id: `73579a1591ec4a8fbd61fa9ec9fda28c`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.00841689823204872, volatility20=0.01830326573673543, rsi14=56.060606060606055, composite_score=0.23612966321655335
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04446283570143613
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 530fabc982f6498f95aeb0581dbb030f

- run_id: `530fabc982f6498f95aeb0581dbb030f`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.00841689823204872, volatility20=0.01830326573673543, rsi14=56.060606060606055, composite_score=0.23612966321655335
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04446283570143613
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run d348d0b458fa4112b68dc09e0eae6430

- run_id: `d348d0b458fa4112b68dc09e0eae6430`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.0, ma20_gap=0.003944641305074548, volatility20=0.0025988101533457263, rsi14=73.07692307692308, composite_score=-0.014760253743402271
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04450817995582823
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 6acb22e0f6c544df8004c343fb7f1efe

- run_id: `6acb22e0f6c544df8004c343fb7f1efe`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2349 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.002286432496757529, volatility20=0.0026250242175061703, rsi14=67.61904761904762, composite_score=0.23490810449493432
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04450817995582823
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run b22102e64d24487b8f06764941080a27

- run_id: `b22102e64d24487b8f06764941080a27`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.002286432496757529, volatility20=0.0026250242175061703, rsi14=67.61904761904762, composite_score=0.23490810449493432
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04450817995582823
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 9bdb425bbc0d4f938f1afac587684368

- run_id: `9bdb425bbc0d4f938f1afac587684368`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.002286432496757529, volatility20=0.0026250242175061703, rsi14=67.61904761904762, composite_score=0.23490810449493432
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04450817995582823
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run c06fffc968114634ad415c6767938ccb

- run_id: `c06fffc968114634ad415c6767938ccb`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.0, ma20_gap=0.0038083784325515513, volatility20=0.0026814064290122445, rsi14=71.42857142857143, composite_score=-0.014782968064837192
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04455356248652503
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 05985d2ab4974d47abe34b52c7318223

- run_id: `05985d2ab4974d47abe34b52c7318223`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2351 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.0033793260047818574, volatility20=0.002522337114353752, rsi14=66.66666666666666, composite_score=0.23513122144960885
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04455356248652503
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 7301c6f2c97849648135164c3f1e22dc

- run_id: `7301c6f2c97849648135164c3f1e22dc`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.0033793260047818574, volatility20=0.002522337114353752, rsi14=66.66666666666666, composite_score=0.23513122144960885
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04455356248652503
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 97d6f17c0b8346968d34afd397ec7bad

- run_id: `97d6f17c0b8346968d34afd397ec7bad`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.0033793260047818574, volatility20=0.002522337114353752, rsi14=66.66666666666666, composite_score=0.23513122144960885
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=0.04455356248652503
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 3cf08da38c5543b78ef096e7d3522d06

- run_id: `3cf08da38c5543b78ef096e7d3522d06`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2553 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.003972168164005252, volatility20=0.0022352140019710103, rsi14=65.38461538461539, composite_score=0.25528154944529313
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.04487115812492072
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 271ed4656dbb4702ad394d3390d80881

- run_id: `271ed4656dbb4702ad394d3390d80881`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.003972168164005252, volatility20=0.0022352140019710103, rsi14=65.38461538461539, composite_score=0.25528154944529313
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.04487115812492072
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 547895e956794d9d9b5802fe2ac0fced

- run_id: `547895e956794d9d9b5802fe2ac0fced`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.003972168164005252, volatility20=0.0022352140019710103, rsi14=65.38461538461539, composite_score=0.25528154944529313
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.04487115812492072
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 814d734dbbb24c42a21bd9902966ec77

- run_id: `814d734dbbb24c42a21bd9902966ec77`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2550 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.0023167256943519288, volatility20=0.0013503559975870307, rsi14=57.692307692307686, composite_score=0.2549504609513624
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.04487115812492072
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 8907d620bb8d4c76867309d10505ac8a

- run_id: `8907d620bb8d4c76867309d10505ac8a`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.0023167256943519288, volatility20=0.0013503559975870307, rsi14=57.692307692307686, composite_score=0.2549504609513624
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.04487115812492072
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run b7f2dde2175f418689cc270167003045

- run_id: `b7f2dde2175f418689cc270167003045`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.0023167256943519288, volatility20=0.0013503559975870307, rsi14=57.692307692307686, composite_score=0.2549504609513624
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.04487115812492072
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 4b057edfb35d4ea1819e9f3a76694058

- run_id: `4b057edfb35d4ea1819e9f3a76694058`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2548 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.0016765574686643525, volatility20=0.0016342202486154763, rsi14=56.41025641025641, composite_score=0.2548320034562206
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0449669196248767
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 60ca4494e57945f1bcd0dd392618a914

- run_id: `60ca4494e57945f1bcd0dd392618a914`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.0016765574686643525, volatility20=0.0016342202486154763, rsi14=56.41025641025641, composite_score=0.2548320034562206
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0449669196248767
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 7f428c8cc4ba456487c25224eff0ade0

- run_id: `7f428c8cc4ba456487c25224eff0ade0`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.0016765574686643525, volatility20=0.0016342202486154763, rsi14=56.41025641025641, composite_score=0.2548320034562206
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0449669196248767
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run b467a05999934db88ee3649e7ec28b2b

- run_id: `b467a05999934db88ee3649e7ec28b2b`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2549 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.00223428024257899, volatility20=0.001641135916569475, rsi14=60.6060606060606, composite_score=0.2549435480110035
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0449669196248767
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 4a4cd8d8af0c411d80428fd3c92289b1

- run_id: `4a4cd8d8af0c411d80428fd3c92289b1`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.00223428024257899, volatility20=0.001641135916569475, rsi14=60.6060606060606, composite_score=0.2549435480110035
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0449669196248767
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run a52fe8e83fc74adc9bf84d56693d775e

- run_id: `a52fe8e83fc74adc9bf84d56693d775e`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.00223428024257899, volatility20=0.001641135916569475, rsi14=60.6060606060606, composite_score=0.2549435480110035
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0449669196248767
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 193706541c9446588275d9dde8b1588c

- run_id: `193706541c9446588275d9dde8b1588c`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.0, ma20_gap=0.00778282466066349, volatility20=0.0018488242303732094, rsi14=70.45454545454545, composite_score=0.006051745483662938
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.044951805515302395
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run c8fd92cef3374f17b67882e870ce44f7

- run_id: `c8fd92cef3374f17b67882e870ce44f7`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2561 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.00792376199514222, volatility20=0.0017833592374899938, rsi14=67.90123456790123, composite_score=0.2560799329505587
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.044951805515302395
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 34825c12fb71494ea2e47e972cb3a017

- run_id: `34825c12fb71494ea2e47e972cb3a017`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.00792376199514222, volatility20=0.0017833592374899938, rsi14=67.90123456790123, composite_score=0.2560799329505587
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.044951805515302395
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run f5715cba3f504461b553ddb0c3bbbfce

- run_id: `f5715cba3f504461b553ddb0c3bbbfce`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.00792376199514222, volatility20=0.0017833592374899938, rsi14=67.90123456790123, composite_score=0.2560799329505587
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.044951805515302395
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run a89c1a2088944f6fae41664a98a9a352

- run_id: `a89c1a2088944f6fae41664a98a9a352`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.010398039605271858, volatility20=0.0017218334410327664, rsi14=80.0, composite_score=-0.09340152145536777
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.04518870623577859
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run c7d6c254abde4342855445ab4b5b65fa

- run_id: `c7d6c254abde4342855445ab4b5b65fa`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.0, ma20_gap=0.007108534212302953, volatility20=0.001868850924858803, rsi14=70.83333333333334, composite_score=0.005940577466038451
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.04518870623577859
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run ddca849c59bc42eb861ae4f408616c73

- run_id: `ddca849c59bc42eb861ae4f408616c73`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.006495654129569095, volatility20=0.0018739345430145522, rsi14=85.0, composite_score=-0.09418199855050832
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.04518870623577859
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 5df73871d82542bd9ef54637f983d62b

- run_id: `5df73871d82542bd9ef54637f983d62b`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0055141954167383656, volatility20=0.001827701526344053, rsi14=80.55555555555556, composite_score=-0.09437829029307447
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.04518870623577859
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 24e6aff628d644cdbea6252e8cf29ba5

- run_id: `24e6aff628d644cdbea6252e8cf29ba5`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.007044021832502967, volatility20=0.0018470540708995721, rsi14=81.08108108108108, composite_score=-0.09407484397887073
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.045163516546286864
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run d46c1e37eb9240df8e0df36d9f7e2123

- run_id: `d46c1e37eb9240df8e0df36d9f7e2123`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0064587708523200504, volatility20=0.0018470540708995721, rsi14=79.41176470588235, composite_score=-0.09419189417490731
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.045163516546286864
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run a1f2471cf3c24a3f9b4eeb877e5b2f28

- run_id: `a1f2471cf3c24a3f9b4eeb877e5b2f28`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.0, ma20_gap=0.003788628833181429, volatility20=0.0018798966555577967, rsi14=72.97297297297297, composite_score=0.005274077421264972
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.045163516546286864
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run f9e8b070ea6442228a11518da24bde08

- run_id: `f9e8b070ea6442228a11518da24bde08`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.0, ma20_gap=0.0027840451780600795, volatility20=0.0018903837050875422, rsi14=71.05263157894737, composite_score=0.0050731606902407024
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.045163516546286864
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 5f61f56353064052813f25893e39449f

- run_id: `5f61f56353064052813f25893e39449f`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2546 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.0005933935517901112, volatility20=0.00162764281232115, rsi14=61.11111111111111, composite_score=0.2546350303649867
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.045163516546286864
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run f49bb89735cf46299097c7ee8a8a313e

- run_id: `f49bb89735cf46299097c7ee8a8a313e`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.0005933935517901112, volatility20=0.00162764281232115, rsi14=61.11111111111111, composite_score=0.2546350303649867
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.045163516546286864
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 1f8d87066be14cf2bd64887105df25b6

- run_id: `1f8d87066be14cf2bd64887105df25b6`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.0005933935517901112, volatility20=0.00162764281232115, rsi14=61.11111111111111, composite_score=0.2546350303649867
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.045163516546286864
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run a099ca20796443b4afdf54a8487fc5b7

- run_id: `a099ca20796443b4afdf54a8487fc5b7`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.0021206253869153757, volatility20=0.0015837059503179232, rsi14=42.857142857142854, composite_score=-0.24590827721723352
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.04515847860149574
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run c6834bf0a2fa494cbdd6d8bd4da52ff6

- run_id: `c6834bf0a2fa494cbdd6d8bd4da52ff6`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.0018829911907615182, volatility20=0.001574752574279722, rsi14=41.935483870967744, composite_score=-0.2458607503780027
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.04515847860149574
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 0cad39f77f1248d49f37b0c9e9988558

- run_id: `0cad39f77f1248d49f37b0c9e9988558`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.00017111342187359213, volatility20=0.0016216570284146156, rsi14=43.75, composite_score=-0.24551837482422512
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.04515847860149574
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 2f5eec06ffa3474a94295e1bbc8ba92e

- run_id: `2f5eec06ffa3474a94295e1bbc8ba92e`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.000434250523074442, volatility20=0.0015380500149995721, rsi14=35.71428571428571, composite_score=-0.22558814293071966
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.044987071738952326
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 5b3680b7bf7d4f33ba6a8b2cab642e96

- run_id: `5b3680b7bf7d4f33ba6a8b2cab642e96`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.003013594072826309, volatility20=0.0014468194064171224, rsi14=35.71428571428571, composite_score=-0.22610401164067
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.044987071738952326
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 795e52925ebb4070b3b2e302c49a0e5b

- run_id: `795e52925ebb4070b3b2e302c49a0e5b`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.0049358341559723184, volatility20=0.0015070910872679105, rsi14=31.25, composite_score=-0.22648845965729925
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.044987071738952326
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 46d3f296d1e9479c9ccdb85133f1e11a

- run_id: `46d3f296d1e9479c9ccdb85133f1e11a`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.005213544683764337, volatility20=0.0014917976314716996, rsi14=31.25, composite_score=-0.2265440017628576
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.044987071738952326
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run ff2899f8dc85427da5a2a1fdd1a0537a

- run_id: `ff2899f8dc85427da5a2a1fdd1a0537a`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.0, ma20_gap=-0.003924253996681504, volatility20=0.001502272885694383, rsi14=26.66666666666667, composite_score=0.023713856374558934
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.044987071738952326
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run ef126441ea2b48d8a018b1177b60126d

- run_id: `ef126441ea2b48d8a018b1177b60126d`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.0, ma20_gap=-0.004110022130888402, volatility20=0.001444039589239196, rsi14=25.80645161290323, composite_score=0.02367771035204844
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04499714778226117
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 240a6177c29e4e8f8411391bf90110b6

- run_id: `240a6177c29e4e8f8411391bf90110b6`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.0, ma20_gap=-0.00516659637283845, volatility20=0.0013528687115172964, rsi14=26.66666666666667, composite_score=0.023466395503658432
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04499714778226117
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 7c2867942c344aa68b9c8db0b382b88e

- run_id: `7c2867942c344aa68b9c8db0b382b88e`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.0037707987237296514, volatility20=0.0013048020347458333, rsi14=32.25806451612904, composite_score=-0.22625444496651978
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04499714778226117
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 5c3bcb07b28647a4b892f97e9cad3b8b

- run_id: `5c3bcb07b28647a4b892f97e9cad3b8b`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.0024266722937328344, volatility20=0.0013386430527382869, rsi14=39.99999999999999, composite_score=-0.22598561968052042
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04499714778226117
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 63fef734ed184a018246ad01ce78a52f

- run_id: `63fef734ed184a018246ad01ce78a52f`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.0, ma20_gap=0.00034294457488059926, volatility20=0.001481289801635889, rsi14=47.05882352941176, composite_score=0.024568303693202242
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04499714778226117
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 74239b6113144caab3e863262560e90f

- run_id: `74239b6113144caab3e863262560e90f`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2748 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.0015831134564643357, volatility20=0.0014184595449676634, rsi14=51.42857142857142, composite_score=0.27482037172348744
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04503749032194598
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 980eec326e664b5696fba7d3d4833b65

- run_id: `980eec326e664b5696fba7d3d4833b65`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.0015831134564643357, volatility20=0.0014184595449676634, rsi14=51.42857142857142, composite_score=0.27482037172348744
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04503749032194598
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 4a5239e7c83f4c39a637e9b2f874e03f

- run_id: `4a5239e7c83f4c39a637e9b2f874e03f`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.0015831134564643357, volatility20=0.0014184595449676634, rsi14=51.42857142857142, composite_score=0.27482037172348744
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04503749032194598
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 66069473e2384ccba24182d5242b8aa5

- run_id: `66069473e2384ccba24182d5242b8aa5`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.0004752098843655572, volatility20=0.001379373257870898, rsi14=40.625, composite_score=-0.22559129294467847
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04503749032194598
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 0cde88c63d2747b88f8a9ee383ca8ead

- run_id: `0cde88c63d2747b88f8a9ee383ca8ead`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.0, ma20_gap=0.00013201320132005812, volatility20=0.0013489083361443782, rsi14=42.42424242424243, composite_score=0.024530151672458613
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04503749032194598
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 75d7227b1a5341f3b7337eff0d6ababa

- run_id: `75d7227b1a5341f3b7337eff0d6ababa`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2746 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.0004884939862428439, volatility20=0.0013442144286388887, rsi14=50.87719298245614, composite_score=0.2745964059711438
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.044987071738952326
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run ca7341fe10ca4581ad81f4d0b29e3e97

- run_id: `ca7341fe10ca4581ad81f4d0b29e3e97`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.0004884939862428439, volatility20=0.0013442144286388887, rsi14=50.87719298245614, composite_score=0.2745964059711438
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.044987071738952326
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 2db3cd5bc8a7451aac4656f31974b2c2

- run_id: `2db3cd5bc8a7451aac4656f31974b2c2`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.0004884939862428439, volatility20=0.0013442144286388887, rsi14=50.87719298245614, composite_score=0.2745964059711438
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.044987071738952326
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 24ecf022f4974ca7bfd5d287e1526c1d

- run_id: `24ecf022f4974ca7bfd5d287e1526c1d`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2747 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.0012145535195648982, volatility20=0.0013739524855266349, rsi14=58.92857142857143, composite_score=0.2747416178778082
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.044987071738952326
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run cdba216e794c4049aaa8c14292c8548c

- run_id: `cdba216e794c4049aaa8c14292c8548c`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.0012145535195648982, volatility20=0.0013739524855266349, rsi14=58.92857142857143, composite_score=0.2747416178778082
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.044987071738952326
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run d36da2427b4843fe8c71fcf6c8bdee86

- run_id: `d36da2427b4843fe8c71fcf6c8bdee86`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.0012145535195648982, volatility20=0.0013739524855266349, rsi14=58.92857142857143, composite_score=0.2747416178778082
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.044987071738952326
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 13c7c240229d4b92aebbd22fe283349e

- run_id: `13c7c240229d4b92aebbd22fe283349e`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2750 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.002719328352298156, volatility20=0.0012400499649148381, rsi14=67.24137931034483, composite_score=0.27504307664663474
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04499210976175107
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 5104b9fbacd4437aa6188ca82141a583

- run_id: `5104b9fbacd4437aa6188ca82141a583`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.002719328352298156, volatility20=0.0012400499649148381, rsi14=67.24137931034483, composite_score=0.27504307664663474
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04499210976175107
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 5b3bcabe59c343918124f9350e132c5b

- run_id: `5b3bcabe59c343918124f9350e132c5b`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.002719328352298156, volatility20=0.0012400499649148381, rsi14=67.24137931034483, composite_score=0.27504307664663474
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04499210976175107
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 3ac4accc9a014e2a98088a2d5c0a5b8f

- run_id: `3ac4accc9a014e2a98088a2d5c0a5b8f`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.0, ma20_gap=0.00022426553038790153, volatility20=0.001202294256247803, rsi14=45.09803921568627, composite_score=0.02454406408225269
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04499210976175107
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 0df64f7027a3495e9d1a21d9b4196401

- run_id: `0df64f7027a3495e9d1a21d9b4196401`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.001174003086704789, volatility20=0.0012354724881542963, rsi14=44.23076923076923, composite_score=-0.22573810865485325
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.0449669196248767
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run f959954e58154d5d8661202779a9f895

- run_id: `f959954e58154d5d8661202779a9f895`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2746 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.000422007701640581, volatility20=0.0012305724023143811, rsi14=52.63157894736841, composite_score=0.2745810935028158
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.0449669196248767
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run dcaada65326e4d00a6179201779dcbc5

- run_id: `dcaada65326e4d00a6179201779dcbc5`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.000422007701640581, volatility20=0.0012305724023143811, rsi14=52.63157894736841, composite_score=0.2745810935028158
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.0449669196248767
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run cb0eefe4f11f4533b4c5e0afa3ea0c91

- run_id: `cb0eefe4f11f4533b4c5e0afa3ea0c91`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.000422007701640581, volatility20=0.0012305724023143811, rsi14=52.63157894736841, composite_score=0.2745810935028158
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.0449669196248767
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 79979b70bd4b4daabc2c2ca7d5fe4086

- run_id: `79979b70bd4b4daabc2c2ca7d5fe4086`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2747 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.0008173165651612635, volatility20=0.0011268165945574368, rsi14=55.932203389830505, composite_score=0.2746601552755199
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.0449669196248767
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run a3c2f7faf13a4aae87cc35ff64a76c80

- run_id: `a3c2f7faf13a4aae87cc35ff64a76c80`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.0008173165651612635, volatility20=0.0011268165945574368, rsi14=55.932203389830505, composite_score=0.2746601552755199
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.0449669196248767
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run c6afea5906eb466fb228be0fba449409

- run_id: `c6afea5906eb466fb228be0fba449409`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.0008173165651612635, volatility20=0.0011268165945574368, rsi14=55.932203389830505, composite_score=0.2746601552755199
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.0449669196248767
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run eee4479dfd53430195788cd26dc5c4f0

- run_id: `eee4479dfd53430195788cd26dc5c4f0`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2747 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.0013442631592819332, volatility20=0.0010919122333519708, rsi14=56.86274509803922, composite_score=0.2747458845538952
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04477031922038777
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 3e1585dd1e104efe9c1f090ce330178f

- run_id: `3e1585dd1e104efe9c1f090ce330178f`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.0013442631592819332, volatility20=0.0010919122333519708, rsi14=56.86274509803922, composite_score=0.2747458845538952
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04477031922038777
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 571802c2c17a401fbc0c0c69914801f6

- run_id: `571802c2c17a401fbc0c0c69914801f6`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.0013442631592819332, volatility20=0.0010919122333519708, rsi14=56.86274509803922, composite_score=0.2747458845538952
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04477031922038777
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 426c1db12c9341fc89e667de49891809

- run_id: `426c1db12c9341fc89e667de49891809`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2746 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.0008430370409400201, volatility20=0.0010693585203663371, rsi14=51.21951219512195, composite_score=0.274633036261857
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04464428853668908
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run a9232aa5ade2466eb61c60892525517f

- run_id: `a9232aa5ade2466eb61c60892525517f`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.0008430370409400201, volatility20=0.0010693585203663371, rsi14=51.21951219512195, composite_score=0.274633036261857
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04464428853668908
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 4421e3b339c743f996f6a7c4ba98973a

- run_id: `4421e3b339c743f996f6a7c4ba98973a`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.0008430370409400201, volatility20=0.0010693585203663371, rsi14=51.21951219512195, composite_score=0.274633036261857
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04464428853668908
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 956d30790f794369ae7ab6d3cb9207b2

- run_id: `956d30790f794369ae7ab6d3cb9207b2`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2746 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.0008559952591031816, volatility20=0.001005206452101756, rsi14=62.16216216216216, composite_score=0.27463562790548957
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04464428853668908
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 68286db051604148b37de0494a593bf3

- run_id: `68286db051604148b37de0494a593bf3`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.0008559952591031816, volatility20=0.001005206452101756, rsi14=62.16216216216216, composite_score=0.27463562790548957
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04464428853668908
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 306a904a19f345818554a003df639f53

- run_id: `306a904a19f345818554a003df639f53`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.0008559952591031816, volatility20=0.001005206452101756, rsi14=62.16216216216216, composite_score=0.27463562790548957
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04464428853668908
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run a5e788e27b8a440f9aa00a1887d4b8ec

- run_id: `a5e788e27b8a440f9aa00a1887d4b8ec`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2746 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.0007505629221915555, volatility20=0.0009013519080805097, rsi14=69.23076923076923, composite_score=0.27461706437072037
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04466951786282055
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 2de3c5001bad47fda40c2b60d777492a

- run_id: `2de3c5001bad47fda40c2b60d777492a`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.0007505629221915555, volatility20=0.0009013519080805097, rsi14=69.23076923076923, composite_score=0.27461706437072037
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04466951786282055
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 6e431dc791f54859952ad56d63fdc5c4

- run_id: `6e431dc791f54859952ad56d63fdc5c4`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.0007505629221915555, volatility20=0.0009013519080805097, rsi14=69.23076923076923, composite_score=0.27461706437072037
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04466951786282055
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run c4445f3691a0494faa71010e3f2169f4

- run_id: `c4445f3691a0494faa71010e3f2169f4`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2749 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.0023954302561268737, volatility20=0.0008871072772548621, rsi14=66.66666666666666, composite_score=0.27494603783750743
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04466951786282055
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 0673267227224f078584eeeb1ee11d2d

- run_id: `0673267227224f078584eeeb1ee11d2d`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.0023954302561268737, volatility20=0.0008871072772548621, rsi14=66.66666666666666, composite_score=0.27494603783750743
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04466951786282055
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 66ab4fd377ca49a7a6e0b6662bf5186b

- run_id: `66ab4fd377ca49a7a6e0b6662bf5186b`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.0023954302561268737, volatility20=0.0008871072772548621, rsi14=66.66666666666666, composite_score=0.27494603783750743
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04466951786282055
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 6a5db10fc4ca405e9520e2d5544b8340

- run_id: `6a5db10fc4ca405e9520e2d5544b8340`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.005561618259989132, volatility20=0.0008880295455749251, rsi14=81.08108108108108, composite_score=-0.07442475894906879
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04462917398933378
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 2736e97daa47403d90c86f95a8e3ada3

- run_id: `2736e97daa47403d90c86f95a8e3ada3`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.006689358794075506, volatility20=0.0008871340226521612, rsi14=83.72093023255815, composite_score=-0.07419921084225152
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04462917398933378
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 8abfdf13e9d1447e8eedb79c08b13ffd

- run_id: `8abfdf13e9d1447e8eedb79c08b13ffd`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.006239737274220003, volatility20=0.0008871340226521612, rsi14=87.8048780487805, composite_score=-0.07428913514622262
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04462917398933378
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 27df2f9b345e4424a517301bed1344b6

- run_id: `27df2f9b345e4424a517301bed1344b6`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0033488738590845557, volatility20=0.0010965128042631277, rsi14=75.0, composite_score=-0.07487033074484961
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04459894483333483
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run d5642538216140f8835155e269840aef

- run_id: `d5642538216140f8835155e269840aef`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2749 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.002074525353850998, volatility20=0.0011281802192000146, rsi14=66.66666666666666, composite_score=0.2748747995541037
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04459894483333483
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 9f4bc92f08f14ebbb65cdcd98a8d226a

- run_id: `9f4bc92f08f14ebbb65cdcd98a8d226a`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.002074525353850998, volatility20=0.0011281802192000146, rsi14=66.66666666666666, composite_score=0.2748747995541037
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04459894483333483
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 6af5c8660acd4d93a35ec7e3fe1b8aab

- run_id: `6af5c8660acd4d93a35ec7e3fe1b8aab`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.002074525353850998, volatility20=0.0011281802192000146, rsi14=66.66666666666666, composite_score=0.2748747995541037
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04459894483333483
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 7097871385694c0bbf114a76a1ebea02

- run_id: `7097871385694c0bbf114a76a1ebea02`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2748 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=0.00160109189217561, volatility20=0.0012676222744356766, rsi14=63.333333333333336, composite_score=0.2747801128617686
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04459894483333483
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 8a948c5f4c1e402eb6c39bccdf14b355

- run_id: `8a948c5f4c1e402eb6c39bccdf14b355`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=0.00160109189217561, volatility20=0.0012676222744356766, rsi14=63.333333333333336, composite_score=0.2747801128617686
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04459894483333483
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 0be3da5fac7043ebbe596a1681eb90bd

- run_id: `0be3da5fac7043ebbe596a1681eb90bd`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=0.00160109189217561, volatility20=0.0012676222744356766, rsi14=63.333333333333336, composite_score=0.2747801128617686
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.04459894483333483
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run d9fa1807412b4dcfbf4b9f6622028718

- run_id: `d9fa1807412b4dcfbf4b9f6622028718`
- symbol: **005930**
- final_action: **BUY 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: strategy_v1_entry: composite=0.2745 regime=range
- technical_evidence: signal_score=0.5, ma20_gap=3.935097131324561e-05, volatility20=0.0013087960881788669, rsi14=53.125, composite_score=0.27447129141166826
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.044634212174056095
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 1866ccfd781b411cb8bcbbc0a3fd1768

- run_id: `1866ccfd781b411cb8bcbbc0a3fd1768`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: signal_score=0.5, ma20_gap=3.935097131324561e-05, volatility20=0.0013087960881788669, rsi14=53.125, composite_score=0.27447129141166826
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.044634212174056095
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 639cc52ec50f4789bec8c559d86d8a25

- run_id: `639cc52ec50f4789bec8c559d86d8a25`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.5, ma20_gap=3.935097131324561e-05, volatility20=0.0013087960881788669, rsi14=53.125, composite_score=0.27447129141166826
- sentiment_evidence: symbol_sentiment_score=0.1, global_sentiment_score=0.044634212174056095
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped
