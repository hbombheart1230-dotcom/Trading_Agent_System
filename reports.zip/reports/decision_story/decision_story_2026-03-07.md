# Decision Story Report (2026-03-07)

- story_total: **735**
- rendered_story_total: **120**
- note: output truncated to first 120 runs

## Run 2da42f17d18d41fd90d581cc83194e44

- run_id: `2da42f17d18d41fd90d581cc83194e44`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run 1572aaec30694c0c807ae5d2b5749d79

- run_id: `1572aaec30694c0c807ae5d2b5749d79`
- symbol: **-**
- final_action: **BUY**
- execution_status: **EXECUTED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 40511508c0af47fa85c4718b1bd4f5b2

- run_id: `40511508c0af47fa85c4718b1bd4f5b2`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked by supervisor test rule
- operator_intervention: none
- final_outcome: blocked:denied_by_test

## Run 31dffd4a1b9b4b249e30cb6f0f2cd4f1

- run_id: `31dffd4a1b9b4b249e30cb6f0f2cd4f1`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 6054f6e915f0468bace560368c8d7d59

- run_id: `6054f6e915f0468bace560368c8d7d59`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked duplicate buy (position already open)
- operator_intervention: none
- final_outcome: blocked:duplicate_buy_position_exists

## Run f6bac522c30c4feeb657b967a63ab719

- run_id: `f6bac522c30c4feeb657b967a63ab719`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Insufficient mock cash
- operator_intervention: none
- final_outcome: blocked:insufficient_mock_cash

## Run 2dcbe389957048e1b52c612122bd3737

- run_id: `2dcbe389957048e1b52c612122bd3737`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 15c0edfeac454227a53bc0d6d48db2cc

- run_id: `15c0edfeac454227a53bc0d6d48db2cc`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 4be4b31b9e7d435b9cf3c2c70cd70279

- run_id: `4be4b31b9e7d435b9cf3c2c70cd70279`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run bdc89a41728a426fb8ee605258a2a4f8

- run_id: `bdc89a41728a426fb8ee605258a2a4f8`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run d4d7010ebcce4ea586986eecdaa890e6

- run_id: `d4d7010ebcce4ea586986eecdaa890e6`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run a7fee00bd164487e9d08291864e9485b

- run_id: `a7fee00bd164487e9d08291864e9485b`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run 5e93336a092a4fc5bb12966d5785d0d9

- run_id: `5e93336a092a4fc5bb12966d5785d0d9`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: llm-buy
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run e268a173889e424c8532e4b8192988bd

- run_id: `e268a173889e424c8532e4b8192988bd`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Score override applied (buy composite=0.4330 regime=trend)
- technical_evidence: rsi14=61.2, ma20_gap=0.015, atr14=650.0, volume_spike20=1.3, volatility20=0.02, regime=trend
- sentiment_evidence: symbol_sentiment_score=0.2, global_sentiment_score=0.1
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run b27a0acc04014159972a9806bde223cd

- run_id: `b27a0acc04014159972a9806bde223cd`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **NOOP**
- decision_reason_summary: Model returned no trade signal
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: no trade

## Run 57d68cef4db74ffa9aa2e1d9836c3466

- run_id: `57d68cef4db74ffa9aa2e1d9836c3466`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **NOOP**
- decision_reason_summary: Trade rationale missing
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: no trade

## Run a005857ed71d4e3892f3b6311f61adb0

- run_id: `a005857ed71d4e3892f3b6311f61adb0`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **NOOP**
- decision_reason_summary: Strategist runtime error
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: no trade

## Run 059b016aa2284d619414e7c9f49bfd98

- run_id: `059b016aa2284d619414e7c9f49bfd98`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash and price ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 479491e7a3b44c019f741fccc7442771

- run_id: `479491e7a3b44c019f741fccc7442771`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **NOOP**
- decision_reason_summary: Position already open
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: no trade

## Run 1f37beba04624a64b65202b659d1e5b8

- run_id: `1f37beba04624a64b65202b659d1e5b8`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Exit policy triggered (take profit)
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run d5b3b8afe50344d0a03b779e725173b6

- run_id: `d5b3b8afe50344d0a03b779e725173b6`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **NOOP**
- decision_reason_summary: Post-exit cooldown active
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: no trade

## Run 3a66af7a0987433697371466435f3687

- run_id: `3a66af7a0987433697371466435f3687`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 0fc31a79815d46e699d6ccce1c5f05cc

- run_id: `0fc31a79815d46e699d6ccce1c5f05cc`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Score override applied (buy composite=0.1130 regime=high_volatility)
- technical_evidence: rsi14=55.0, ma20_gap=0.015, atr14=650.0, volume_spike20=1.3, volatility20=0.05, regime=high_volatility
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run aa703fc0c00a44e78fe466a524c2443d

- run_id: `aa703fc0c00a44e78fe466a524c2443d`
- symbol: **005930**
- final_action: **SELL 16**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: EOD force liquidation (15:25)
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run a8017fd4618643b7ab54dd2283e16a8b

- run_id: `a8017fd4618643b7ab54dd2283e16a8b`
- symbol: **-**
- final_action: **BUY**
- execution_status: **EXECUTED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 0ceb9bc40c8746629f31bc3741b02a95

- run_id: `0ceb9bc40c8746629f31bc3741b02a95`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked by supervisor test rule
- operator_intervention: none
- final_outcome: blocked:denied_by_test

## Run 0b51ca9aff254cce89ef266d87bc416c

- run_id: `0b51ca9aff254cce89ef266d87bc416c`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 33828903870a497b91bb53e4b7d6fb2f

- run_id: `33828903870a497b91bb53e4b7d6fb2f`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked duplicate buy (position already open)
- operator_intervention: none
- final_outcome: blocked:duplicate_buy_position_exists

## Run c2f4b080405f48139267e72ca2ff905d

- run_id: `c2f4b080405f48139267e72ca2ff905d`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Insufficient mock cash
- operator_intervention: none
- final_outcome: blocked:insufficient_mock_cash

## Run c2e4aa4f5e274be4a28d815f972b51ae

- run_id: `c2e4aa4f5e274be4a28d815f972b51ae`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run b852418334f34a979bb9bc04b98fc210

- run_id: `b852418334f34a979bb9bc04b98fc210`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 866aa09159b04c7dadc6f9681feda72f

- run_id: `866aa09159b04c7dadc6f9681feda72f`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run ac771f63960b467e8852f906316b5bc5

- run_id: `ac771f63960b467e8852f906316b5bc5`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run 35d858afc9fc4c6b911f4da0e08ad3c7

- run_id: `35d858afc9fc4c6b911f4da0e08ad3c7`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 294251aa3b1c4605a59260df56674fe1

- run_id: `294251aa3b1c4605a59260df56674fe1`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run 05083e07cf1a480382af228ab486b91a

- run_id: `05083e07cf1a480382af228ab486b91a`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run a37b959776ac4f4dadee47708ca1fbac

- run_id: `a37b959776ac4f4dadee47708ca1fbac`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: Model returned no trade signal
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 59549d88279548728208a850393106f8

- run_id: `59549d88279548728208a850393106f8`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash and price ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 526e442f427f45f48db8421f86a8cbb2

- run_id: `526e442f427f45f48db8421f86a8cbb2`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **NOOP**
- decision_reason_summary: Model returned no trade signal
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: no trade

## Run 277f3c0917ce46259f58c23623f33400

- run_id: `277f3c0917ce46259f58c23623f33400`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash and price ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run dc070b4963604c8d99d4ab6132c02bc8

- run_id: `dc070b4963604c8d99d4ab6132c02bc8`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run monitor-node

- run_id: `monitor-node`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run d0ff1396a63c4771922cc33ddbea893c

- run_id: `d0ff1396a63c4771922cc33ddbea893c`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: llm-buy
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 3b62b05243d641e7bd016ae5f93d7a8f

- run_id: `3b62b05243d641e7bd016ae5f93d7a8f`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Score override applied (buy composite=0.4330 regime=trend)
- technical_evidence: rsi14=61.2, ma20_gap=0.015, atr14=650.0, volume_spike20=1.3, volatility20=0.02, regime=trend
- sentiment_evidence: symbol_sentiment_score=0.2, global_sentiment_score=0.1
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run e76804dd20d24ace8b288a7257f697f1

- run_id: `e76804dd20d24ace8b288a7257f697f1`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **NOOP**
- decision_reason_summary: Model returned no trade signal
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: no trade

## Run 12e7a19ba9c04233b451a30f89b45272

- run_id: `12e7a19ba9c04233b451a30f89b45272`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **NOOP**
- decision_reason_summary: Trade rationale missing
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: no trade

## Run d82c4fc83fd44b259d7ba1ca886f022e

- run_id: `d82c4fc83fd44b259d7ba1ca886f022e`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **NOOP**
- decision_reason_summary: Strategist runtime error
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: no trade

## Run 150e93986bc842d18d84306499f18445

- run_id: `150e93986bc842d18d84306499f18445`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash and price ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 3a377794af9c49db96a4ae87bbed642e

- run_id: `3a377794af9c49db96a4ae87bbed642e`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **NOOP**
- decision_reason_summary: Position already open
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: no trade

## Run 3ef06f7740694c2dbe5e076a2f603976

- run_id: `3ef06f7740694c2dbe5e076a2f603976`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Exit policy triggered (take profit)
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 0a1d788b4fa94152a2305ba7ee2a98db

- run_id: `0a1d788b4fa94152a2305ba7ee2a98db`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **NOOP**
- decision_reason_summary: Post-exit cooldown active
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: no trade

## Run 1c0829bf27144f3cb75ed86be8b82ac1

- run_id: `1c0829bf27144f3cb75ed86be8b82ac1`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 3fe3239eb67e4084943ae46c002c5226

- run_id: `3fe3239eb67e4084943ae46c002c5226`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Score override applied (buy composite=0.1130 regime=high_volatility)
- technical_evidence: rsi14=55.0, ma20_gap=0.015, atr14=650.0, volume_spike20=1.3, volatility20=0.05, regime=high_volatility
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 70ab75ad22b246e1874b221ade000481

- run_id: `70ab75ad22b246e1874b221ade000481`
- symbol: **005930**
- final_action: **SELL 16**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: EOD force liquidation (15:25)
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 93132747bc8d4f56993992866c04b18f

- run_id: `93132747bc8d4f56993992866c04b18f`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run 84594d20a4584060879f60b6ff6fd535

- run_id: `84594d20a4584060879f60b6ff6fd535`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run f78b2eaceab74eff9ac0cc29f4956496

- run_id: `f78b2eaceab74eff9ac0cc29f4956496`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run b132bcfe2e894e3fbaa1002101ecfadf

- run_id: `b132bcfe2e894e3fbaa1002101ecfadf`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run 64dee92423fc42df927b5fa7e3ef442d

- run_id: `64dee92423fc42df927b5fa7e3ef442d`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run cd1d15bc92cb48edad1dce1afe9895c5

- run_id: `cd1d15bc92cb48edad1dce1afe9895c5`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run 19ce0d96420f430aa6ea684d058683be

- run_id: `19ce0d96420f430aa6ea684d058683be`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run 539480d3ab514feeb659b9798fc6b6b5

- run_id: `539480d3ab514feeb659b9798fc6b6b5`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run m21-runtime-once

- run_id: `m21-runtime-once`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: operator_resume
- final_outcome: unknown

## Run m22-graph-hydration-demo

- run_id: `m22-graph-hydration-demo`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run r-m22-5-ok

- run_id: `r-m22-5-ok`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run r-m22-5-fail

- run_id: `r-m22-5-fail`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run m22-hydration-demo

- run_id: `m22-hydration-demo`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run r-m22-8-factory

- run_id: `r-m22-8-factory`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run r-m22-8-auto

- run_id: `r-m22-8-auto`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run r-m22-8-auto-fail

- run_id: `r-m22-8-auto-fail`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run 80e3e290bb3042ca88ab4e6f9746a37a

- run_id: `80e3e290bb3042ca88ab4e6f9746a37a`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run 080c4da6ff5145c2a350d3ebbe46e0a0

- run_id: `080c4da6ff5145c2a350d3ebbe46e0a0`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **NOOP**
- decision_reason_summary: circuit open
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: no trade

## Run 9b9ac9e6c2a242ef9da1e801e8c905cb

- run_id: `9b9ac9e6c2a242ef9da1e801e8c905cb`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: recovered
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run b86fab60fe9b4e6bbff545cb442e20aa

- run_id: `b86fab60fe9b4e6bbff545cb442e20aa`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run m28-startup-preflight

- run_id: `m28-startup-preflight`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run m28-5-scheduler

- run_id: `m28-5-scheduler`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run m28-5-worker

- run_id: `m28-5-worker`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run m28-6-scheduler

- run_id: `m28-6-scheduler`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run m28-6-worker

- run_id: `m28-6-worker`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run faf7a9ca3abf4954b4afd0b96f4fb5e0

- run_id: `faf7a9ca3abf4954b4afd0b96f4fb5e0`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 441ccd2c1c294f5d95eba820da12d5d0

- run_id: `441ccd2c1c294f5d95eba820da12d5d0`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 55640e62c93a4631be69f623923fcd12

- run_id: `55640e62c93a4631be69f623923fcd12`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash and price ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 42159b9a2f48411f82913c5a5353bfe5

- run_id: `42159b9a2f48411f82913c5a5353bfe5`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash and price ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 39f4ffdcb2244988ad778011e9502c30

- run_id: `39f4ffdcb2244988ad778011e9502c30`
- symbol: **-**
- final_action: **BUY**
- execution_status: **EXECUTED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run ca9f5c73a8ec4254840ca2a9e7238126

- run_id: `ca9f5c73a8ec4254840ca2a9e7238126`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked by supervisor test rule
- operator_intervention: none
- final_outcome: blocked:denied_by_test

## Run 8a2d7e44ccad4235b89484bd7c45fb53

- run_id: `8a2d7e44ccad4235b89484bd7c45fb53`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run a1496362d9174e44aa449ad6cc0e5bcd

- run_id: `a1496362d9174e44aa449ad6cc0e5bcd`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked duplicate buy (position already open)
- operator_intervention: none
- final_outcome: blocked:duplicate_buy_position_exists

## Run a82279022e304554855bba0c915aaad3

- run_id: `a82279022e304554855bba0c915aaad3`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Insufficient mock cash
- operator_intervention: none
- final_outcome: blocked:insufficient_mock_cash

## Run 6f1e7d1f82064b88bcb1c4221f385c44

- run_id: `6f1e7d1f82064b88bcb1c4221f385c44`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 43bdd52393de4ac5a47302bf937deccc

- run_id: `43bdd52393de4ac5a47302bf937deccc`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run ad4ce5751c8b4f1abfdb57ad7c83473c

- run_id: `ad4ce5751c8b4f1abfdb57ad7c83473c`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 13091d54e55e49139540ce8de76d2797

- run_id: `13091d54e55e49139540ce8de76d2797`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run cbf8e5cad15e4b2c80a50a5060bf4d72

- run_id: `cbf8e5cad15e4b2c80a50a5060bf4d72`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 65b5baec5f944d41bf4e93b7379a6004

- run_id: `65b5baec5f944d41bf4e93b7379a6004`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run 21345129aad4470bbda2481785fe9e0d

- run_id: `21345129aad4470bbda2481785fe9e0d`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 4d7812a883a44793b4984b312afb6ae6

- run_id: `4d7812a883a44793b4984b312afb6ae6`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: Model returned no trade signal
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 0ad33d678a014476a9c5aa9265119c89

- run_id: `0ad33d678a014476a9c5aa9265119c89`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash and price ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run e2aaf6404a664baca07cfc578c70daf1

- run_id: `e2aaf6404a664baca07cfc578c70daf1`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **NOOP**
- decision_reason_summary: Model returned no trade signal
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: no trade

## Run 74281e5227484e1fa88ab26ac65456ea

- run_id: `74281e5227484e1fa88ab26ac65456ea`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash and price ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run f7e99cfee0654569bedf4653e331cc11

- run_id: `f7e99cfee0654569bedf4653e331cc11`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run 3280ce2d7c0a47b29a317bba30bbcced

- run_id: `3280ce2d7c0a47b29a317bba30bbcced`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: llm-buy
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run ac0a7f2117ee42e596699c20feaad361

- run_id: `ac0a7f2117ee42e596699c20feaad361`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Score override applied (buy composite=0.4330 regime=trend)
- technical_evidence: rsi14=61.2, ma20_gap=0.015, atr14=650.0, volume_spike20=1.3, volatility20=0.02, regime=trend
- sentiment_evidence: symbol_sentiment_score=0.2, global_sentiment_score=0.1
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run eaa51c35eae843a6956f9eb2aad42099

- run_id: `eaa51c35eae843a6956f9eb2aad42099`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **NOOP**
- decision_reason_summary: Model returned no trade signal
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: no trade

## Run a2a3835bc40e4732b141648da6ac43dc

- run_id: `a2a3835bc40e4732b141648da6ac43dc`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **NOOP**
- decision_reason_summary: Trade rationale missing
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: no trade

## Run bd8c03b09fab47d68d81507ea3499e63

- run_id: `bd8c03b09fab47d68d81507ea3499e63`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **NOOP**
- decision_reason_summary: Strategist runtime error
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: no trade

## Run d3537a48c2994ccf8a36da2f81552432

- run_id: `d3537a48c2994ccf8a36da2f81552432`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: rule:cash and price ok
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run bf28319e96054f95af8146fb5dcafc2b

- run_id: `bf28319e96054f95af8146fb5dcafc2b`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **NOOP**
- decision_reason_summary: Position already open
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: no trade

## Run 8b03b8a836c9443e9df0bc7a82dbb643

- run_id: `8b03b8a836c9443e9df0bc7a82dbb643`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Exit policy triggered (take profit)
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 1a5352838cbc49d9b3ed889eb0e8467a

- run_id: `1a5352838cbc49d9b3ed889eb0e8467a`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **NOOP**
- decision_reason_summary: Post-exit cooldown active
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: no trade

## Run 4b0383885d2a44098a0ffba252dff84b

- run_id: `4b0383885d2a44098a0ffba252dff84b`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Exit policy triggered (max hold)
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 9a699453ebbf4be590cdecc2f445745f

- run_id: `9a699453ebbf4be590cdecc2f445745f`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: Score override applied (buy composite=0.1130 regime=high_volatility)
- technical_evidence: rsi14=55.0, ma20_gap=0.015, atr14=650.0, volume_spike20=1.3, volatility20=0.05, regime=high_volatility
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run 82879feeb1e744c4bfe253a6413ecc6c

- run_id: `82879feeb1e744c4bfe253a6413ecc6c`
- symbol: **005930**
- final_action: **SELL 16**
- execution_status: **INTENT_ONLY**
- decision_reason_summary: EOD force liquidation (15:25)
- technical_evidence: rsi14=50.0, ma20_gap=0.0, atr14=0.0, volume_spike20=1.0, volatility20=0.0, regime=unknown
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=0.0
- guard_intervention: none
- operator_intervention: none
- final_outcome: intent_only

## Run fae27066df9a4ad6916598a840d9f83f

- run_id: `fae27066df9a4ad6916598a840d9f83f`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run fee31cf907d241d7bf3a75e67c234920

- run_id: `fee31cf907d241d7bf3a75e67c234920`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run faf8335c4c624a82888f22cb36f611da

- run_id: `faf8335c4c624a82888f22cb36f611da`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run a3f48abde5574241ba28fa661dbddc84

- run_id: `a3f48abde5574241ba28fa661dbddc84`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run 24f5064be1db4d69b6c326f5a0596e9d

- run_id: `24f5064be1db4d69b6c326f5a0596e9d`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run 79951d7ead6746e7965a57dbbf26b90a

- run_id: `79951d7ead6746e7965a57dbbf26b90a`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run eef460e152bd4d4da56e1019e945d6e7

- run_id: `eef460e152bd4d4da56e1019e945d6e7`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown

## Run ed9f91da98fd438db1789ce4f8f96b15

- run_id: `ed9f91da98fd438db1789ce4f8f96b15`
- symbol: **-**
- final_action: **UNKNOWN**
- execution_status: **UNKNOWN**
- decision_reason_summary: unspecified
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: unknown
