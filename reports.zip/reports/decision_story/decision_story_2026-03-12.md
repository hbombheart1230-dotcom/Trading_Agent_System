# Decision Story Report (2026-03-12)

- story_total: **592**
- rendered_story_total: **120**
- note: output truncated to first 120 runs

## Run 75c3739b0d1a4f7cb5cc97910e99209c

- run_id: `75c3739b0d1a4f7cb5cc97910e99209c`
- symbol: **024060**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.20196000000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 4ecc4f6b97254c69a58207d23fe430ab

- run_id: `4ecc4f6b97254c69a58207d23fe430ab`
- symbol: **024060**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22476960000000007, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run cfedf8f1a65d49d4809249695154bc18

- run_id: `cfedf8f1a65d49d4809249695154bc18`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24829200000000007, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 40f6e2e3aab04942913632725de79ee8

- run_id: `40f6e2e3aab04942913632725de79ee8`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.25351920000000006, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 4b0e90a60eff42f88e2c6ca53e0ea264

- run_id: `4b0e90a60eff42f88e2c6ca53e0ea264`
- symbol: **006910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.20196000000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run d00cca0f269643eb8c1a97f6ecb30b1e

- run_id: `d00cca0f269643eb8c1a97f6ecb30b1e`
- symbol: **006910**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.20196000000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run b15496873e274707955dccf2c02f7bdc

- run_id: `b15496873e274707955dccf2c02f7bdc`
- symbol: **380540**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run daf656d3405c4cf0a59e230a8e1f4f25

- run_id: `daf656d3405c4cf0a59e230a8e1f4f25`
- symbol: **380540**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run a9cb0ebaacd64e8d92b9312b68dd23e3

- run_id: `a9cb0ebaacd64e8d92b9312b68dd23e3`
- symbol: **307870**
- final_action: **BUY 1**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run 685be82701b9464196eb0aa6f6a68efa

- run_id: `685be82701b9464196eb0aa6f6a68efa`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.25351920000000006, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 4302ce0ee7a84193b8c6e73e533c50fd

- run_id: `4302ce0ee7a84193b8c6e73e533c50fd`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.23047200000000004, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 1c60c02fe381441f90d4dd709d7575c6

- run_id: `1c60c02fe381441f90d4dd709d7575c6`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.25351920000000006, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 897f80af557747929398653b10dc5fe8

- run_id: `897f80af557747929398653b10dc5fe8`
- symbol: **380540**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 347c3d096f504b73ae6c01b5b61899dd

- run_id: `347c3d096f504b73ae6c01b5b61899dd`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.25351920000000006, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 1d1bd8b216f4497aaa8d364001d9c2e8

- run_id: `1d1bd8b216f4497aaa8d364001d9c2e8`
- symbol: **357880**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 4bdcaca2a1ac4f68a8a36dd80d54cf1f

- run_id: `4bdcaca2a1ac4f68a8a36dd80d54cf1f`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.23047200000000004, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 2161cccd31b641a5a7cebcc05e2c3fa3

- run_id: `2161cccd31b641a5a7cebcc05e2c3fa3`
- symbol: **357880**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run ef7f0ed7944a4fe4856528001f3a52ae

- run_id: `ef7f0ed7944a4fe4856528001f3a52ae`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.25351920000000006, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run a900404075904b60bbae67065a43391e

- run_id: `a900404075904b60bbae67065a43391e`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.25351920000000006, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 179c2a35c9a0476daa7146608f4dce3e

- run_id: `179c2a35c9a0476daa7146608f4dce3e`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.25351920000000006, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 0a8df67abc7047d1a21f30a9aac2c0de

- run_id: `0a8df67abc7047d1a21f30a9aac2c0de`
- symbol: **357880**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run efafedb80583409aad50ef0a9e16f030

- run_id: `efafedb80583409aad50ef0a9e16f030`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.23047200000000004, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 5835be0f79ff42eeb9c70619fbda859b

- run_id: `5835be0f79ff42eeb9c70619fbda859b`
- symbol: **357880**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 0b5dd9bf60d542d38d13f5910d60721a

- run_id: `0b5dd9bf60d542d38d13f5910d60721a`
- symbol: **357880**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run e59e65f284f648b8a808e679e285938c

- run_id: `e59e65f284f648b8a808e679e285938c`
- symbol: **357880**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run c7884a8183ed4c1b9c68d3ca538b0540

- run_id: `c7884a8183ed4c1b9c68d3ca538b0540`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22809600000000002, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 919425ddd88543269e3c07b569ccb766

- run_id: `919425ddd88543269e3c07b569ccb766`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22572000000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 78757acd8615460dbb7ff80577598a52

- run_id: `78757acd8615460dbb7ff80577598a52`
- symbol: **357880**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run e6c7aa046df64470bbdf0546d016eb98

- run_id: `e6c7aa046df64470bbdf0546d016eb98`
- symbol: **357880**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run bb8919bfb5f7413d96cefd6fae8815b0

- run_id: `bb8919bfb5f7413d96cefd6fae8815b0`
- symbol: **357880**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 5bd64f2da6c64d92919f96a46193ffc3

- run_id: `5bd64f2da6c64d92919f96a46193ffc3`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24829200000000007, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 4260abb217fe473e85cf44e501f710e9

- run_id: `4260abb217fe473e85cf44e501f710e9`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22572000000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 7ccad0276ed74780a7cbd898f157d050

- run_id: `7ccad0276ed74780a7cbd898f157d050`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22572000000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 21df7331c9e849698d36a55f902ae19a

- run_id: `21df7331c9e849698d36a55f902ae19a`
- symbol: **357880**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 8671e83363934e9fa08e51b0365bf3e4

- run_id: `8671e83363934e9fa08e51b0365bf3e4`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22572000000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 2466a84aeed4495b947bfd098f87781b

- run_id: `2466a84aeed4495b947bfd098f87781b`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22572000000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run df4ffff797c54b23ba77380191514c3d

- run_id: `df4ffff797c54b23ba77380191514c3d`
- symbol: **357880**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run abc3832426ce483d9f44032a88bb5e53

- run_id: `abc3832426ce483d9f44032a88bb5e53`
- symbol: **357880**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run ec51133a2f2e4b4ba0ea28e1de9defa7

- run_id: `ec51133a2f2e4b4ba0ea28e1de9defa7`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22572000000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 3dc6ca3a89b04eeb8c88beb4a7154d86

- run_id: `3dc6ca3a89b04eeb8c88beb4a7154d86`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22572000000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run c2130d2c28fd45a9b2131383e653306d

- run_id: `c2130d2c28fd45a9b2131383e653306d`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22572000000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run f56c1bb4b4014190a313b83e01515569

- run_id: `f56c1bb4b4014190a313b83e01515569`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22572000000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 14add721326445718ee16c114157eaa7

- run_id: `14add721326445718ee16c114157eaa7`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22572000000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 59c04c994a204ca1bccd50505bd9ce9b

- run_id: `59c04c994a204ca1bccd50505bd9ce9b`
- symbol: **357880**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 5f835d8a95f14a35898483f40f8e14e9

- run_id: `5f835d8a95f14a35898483f40f8e14e9`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22572000000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run aefb662e1b7d483f9b2dd07a005668e3

- run_id: `aefb662e1b7d483f9b2dd07a005668e3`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22572000000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run c4c50c6bcbd0433684765ab651706a36

- run_id: `c4c50c6bcbd0433684765ab651706a36`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22572000000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 0f0814fa93f9491582139ba6cff62a3a

- run_id: `0f0814fa93f9491582139ba6cff62a3a`
- symbol: **357880**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run e497ee5b9beb48918fc344e84d935e5d

- run_id: `e497ee5b9beb48918fc344e84d935e5d`
- symbol: **357880**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run cb58a10975e348b9a2f2c17eb8040cec

- run_id: `cb58a10975e348b9a2f2c17eb8040cec`
- symbol: **357880**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 36a7fa4689d34cb3affff349a0deaadc

- run_id: `36a7fa4689d34cb3affff349a0deaadc`
- symbol: **357880**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 37c6b121f94c47ca9c2cbbeb479309fc

- run_id: `37c6b121f94c47ca9c2cbbeb479309fc`
- symbol: **357880**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 2f61610322e64e3bad85caa13f32a26a

- run_id: `2f61610322e64e3bad85caa13f32a26a`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24306480000000008, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 5d702174220f4a6aab888385761238cf

- run_id: `5d702174220f4a6aab888385761238cf`
- symbol: **357880**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 62ff8406e6884cef99909e0de76afa6c

- run_id: `62ff8406e6884cef99909e0de76afa6c`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22334400000000001, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 152192af364c47b2b212dda15c700f11

- run_id: `152192af364c47b2b212dda15c700f11`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24567840000000007, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 60e74545f2954e9b94a5fd1b6c482432

- run_id: `60e74545f2954e9b94a5fd1b6c482432`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: max_hold
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22334400000000001, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run 7a6662a216ef4253b5e76f593a1f67bd

- run_id: `7a6662a216ef4253b5e76f593a1f67bd`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22096800000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 96d05655a3e7459c8d94a2613e143ca1

- run_id: `96d05655a3e7459c8d94a2613e143ca1`
- symbol: **005930**
- final_action: **SELL 2**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: max_hold
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22096800000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run 8abcd31b7b454b73bac4770e501e0610

- run_id: `8abcd31b7b454b73bac4770e501e0610`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24306480000000008, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 101ed9626605437dab52cb7aebfd308b

- run_id: `101ed9626605437dab52cb7aebfd308b`
- symbol: **357880**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 5ad18a189a26433db0a7e0e3e4baa8f1

- run_id: `5ad18a189a26433db0a7e0e3e4baa8f1`
- symbol: **357880**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 5539bfbc6deb4d038a7b5c031ce421d8

- run_id: `5539bfbc6deb4d038a7b5c031ce421d8`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22096800000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 4ad813f9222b44188b6c98b6c631f59c

- run_id: `4ad813f9222b44188b6c98b6c631f59c`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22096800000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run ad7e045089714a0dbe10388fea4f4625

- run_id: `ad7e045089714a0dbe10388fea4f4625`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24306480000000008, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run b88801d0ad864969958998832cf75965

- run_id: `b88801d0ad864969958998832cf75965`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24306480000000008, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run ce9027e1716349c5bb4615c5ecbe5a61

- run_id: `ce9027e1716349c5bb4615c5ecbe5a61`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24306480000000008, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 966e416b56054976a3022a1d6d7926c2

- run_id: `966e416b56054976a3022a1d6d7926c2`
- symbol: **032820**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22096800000000003, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run f33d1e79c3464d3e99b3f2b68387395d

- run_id: `f33d1e79c3464d3e99b3f2b68387395d`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24306480000000008, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run fd9d71d98eba4703b949ac773a520e4c

- run_id: `fd9d71d98eba4703b949ac773a520e4c`
- symbol: **032820**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24306480000000008, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 11e2fb08ff3340f08b4904a1120aec21

- run_id: `11e2fb08ff3340f08b4904a1120aec21`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24306480000000008, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 0795f8c1bd2f4f9b80720f699771f640

- run_id: `0795f8c1bd2f4f9b80720f699771f640`
- symbol: **032820**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24306480000000008, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run c294a18b87df41b9ab6856ec051ab683

- run_id: `c294a18b87df41b9ab6856ec051ab683`
- symbol: **357880**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: Daily loss limit exceeded
- operator_intervention: none
- final_outcome: blocked:Daily loss limit exceeded

## Run f564f6cadaa24bf7bda87a706acce3c7

- run_id: `f564f6cadaa24bf7bda87a706acce3c7`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22334400000000001, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 8d051f38997c4b39bf8817874b8f3825

- run_id: `8d051f38997c4b39bf8817874b8f3825`
- symbol: **N/A**
- final_action: **BUY**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run e4d001ddcbe440feb073cef453896012

- run_id: `e4d001ddcbe440feb073cef453896012`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked by supervisor test rule
- operator_intervention: none
- final_outcome: blocked:denied_by_test

## Run 8607754e06874136abfa20d4fc48bf2b

- run_id: `8607754e06874136abfa20d4fc48bf2b`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run b36cc6d1f351441baadb6f0dfe16ed84

- run_id: `b36cc6d1f351441baadb6f0dfe16ed84`
- symbol: **005930**
- final_action: **SELL 20**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 9f09a63f6c3e49f39c25a8025d924f09

- run_id: `9f09a63f6c3e49f39c25a8025d924f09`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked duplicate buy (position already open)
- operator_intervention: none
- final_outcome: blocked:duplicate_buy_position_exists

## Run 602dacaba4b14d7fa4f76f6084daa485

- run_id: `602dacaba4b14d7fa4f76f6084daa485`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Insufficient mock cash
- operator_intervention: none
- final_outcome: blocked:insufficient_mock_cash

## Run 276a767311874448a24ffb2c42b41471

- run_id: `276a767311874448a24ffb2c42b41471`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 161e3f0b11094df2b0ea415e4d115633

- run_id: `161e3f0b11094df2b0ea415e4d115633`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 55d4380b861b42b488041a76599e5f48

- run_id: `55d4380b861b42b488041a76599e5f48`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 7bfd87bf38c5406d80db13fb86900105

- run_id: `7bfd87bf38c5406d80db13fb86900105`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run 9bacfc9629d94496a79c5fb5c8da9a8b

- run_id: `9bacfc9629d94496a79c5fb5c8da9a8b`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 1846e0d5d9b84b75a47baf4b49515598

- run_id: `1846e0d5d9b84b75a47baf4b49515598`
- symbol: **032820**
- final_action: **SELL 16**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: stop_loss
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24567840000000007, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run c3767e3bd8c24cdc8e7f9ff2bd4b6663

- run_id: `c3767e3bd8c24cdc8e7f9ff2bd4b6663`
- symbol: **006910**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: stop_loss
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22334400000000001, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run bca1f45a15cf49d69542a75235b5b556

- run_id: `bca1f45a15cf49d69542a75235b5b556`
- symbol: **024060**
- final_action: **SELL 2**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: stop_loss
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24567840000000007, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 995f0ebc11fb4e0a9650377d75baeab6

- run_id: `995f0ebc11fb4e0a9650377d75baeab6`
- symbol: **051910**
- final_action: **SELL 324**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: stop_loss
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22334400000000001, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run f1ca5678c36343c38167d4fdc9b7981f

- run_id: `f1ca5678c36343c38167d4fdc9b7981f`
- symbol: **357880**
- final_action: **SELL 9**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: stop_loss
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run af94ca714b034a28b4b7aa10cd04dcd0

- run_id: `af94ca714b034a28b4b7aa10cd04dcd0`
- symbol: **005930**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: stop_loss
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 22893065dad943de968f174665286fdd

- run_id: `22893065dad943de968f174665286fdd`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24567840000000007, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run d7de512cc2d04e189638801e0da1dfb5

- run_id: `d7de512cc2d04e189638801e0da1dfb5`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22334400000000001, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 5ce388e8e9de4e07b827ed21b0fb184e

- run_id: `5ce388e8e9de4e07b827ed21b0fb184e`
- symbol: **380540**
- final_action: **SELL 3**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: take_profit
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22334400000000001, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 084bfad5f260424c9334eb6cc355475e

- run_id: `084bfad5f260424c9334eb6cc355475e`
- symbol: **380540**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 43cb751563644832b064af98dda81c6a

- run_id: `43cb751563644832b064af98dda81c6a`
- symbol: **380540**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22334400000000001, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run a62d4ef310de4f8c9955c6db7ee48fa5

- run_id: `a62d4ef310de4f8c9955c6db7ee48fa5`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24567840000000007, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 6a923132c4854676bf9748bad8d41729

- run_id: `6a923132c4854676bf9748bad8d41729`
- symbol: **032820**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 7b656329d62c46d4955b8f4307c86515

- run_id: `7b656329d62c46d4955b8f4307c86515`
- symbol: **046120**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run cba0dafe11324a4486ba5eda62854cdd

- run_id: `cba0dafe11324a4486ba5eda62854cdd`
- symbol: **046120**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.0, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 4e492828e1cf45b68349ca6b1f480729

- run_id: `4e492828e1cf45b68349ca6b1f480729`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24567840000000007, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 39e5db0373f04e4fb2da4a509c70c666

- run_id: `39e5db0373f04e4fb2da4a509c70c666`
- symbol: **032820**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22334400000000001, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 684e5ac951164f1cbef78cb20c35d421

- run_id: `684e5ac951164f1cbef78cb20c35d421`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24567840000000007, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 40e75e7f897d4da29f7d8006421eddb9

- run_id: `40e75e7f897d4da29f7d8006421eddb9`
- symbol: **032820**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24567840000000007, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run fe92900464ef4438a6ae0171853271ce

- run_id: `fe92900464ef4438a6ae0171853271ce`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22334400000000001, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 55b9325640fe42cfa4ca808a05e67d7b

- run_id: `55b9325640fe42cfa4ca808a05e67d7b`
- symbol: **032820**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.22334400000000001, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run bcd8fffc6a674b008704f3eab0d67bd5

- run_id: `bcd8fffc6a674b008704f3eab0d67bd5`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24306480000000008, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run c88427e9935e4bc19c5088bdbe835ba8

- run_id: `c88427e9935e4bc19c5088bdbe835ba8`
- symbol: **032820**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: max_hold
- technical_evidence: playbook=defensive, candidate_pool_size=10, score_total=None, risk_score=None, score_breakdown=trading_value=0.24306480000000008, momentum=0.0, trend=0.0, volume_surge=0.0, intraday_strength=0.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run trace-r2

- run_id: `trace-r2`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 694063e8e229429989f29461392bdb31

- run_id: `694063e8e229429989f29461392bdb31`
- symbol: **N/A**
- final_action: **BUY**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 99859cd1cc2b4154ba484ee59fda25cf

- run_id: `99859cd1cc2b4154ba484ee59fda25cf`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked by supervisor test rule
- operator_intervention: none
- final_outcome: blocked:denied_by_test

## Run d09884b89e894f47b1989554beaa37b9

- run_id: `d09884b89e894f47b1989554beaa37b9`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run eaaecd4e0ffd4f0591f27a6e3d75c9a6

- run_id: `eaaecd4e0ffd4f0591f27a6e3d75c9a6`
- symbol: **005930**
- final_action: **SELL 20**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 87bb3a0bcc854740a0c09e7cc3fbd2d1

- run_id: `87bb3a0bcc854740a0c09e7cc3fbd2d1`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Blocked duplicate buy (position already open)
- operator_intervention: none
- final_outcome: blocked:duplicate_buy_position_exists

## Run 9d3eb96a39154d2daa3314194cf5ac1d

- run_id: `9d3eb96a39154d2daa3314194cf5ac1d`
- symbol: **N/A**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: Insufficient mock cash
- operator_intervention: none
- final_outcome: blocked:insufficient_mock_cash

## Run 77a3090683e641e58156b3dccf817e9a

- run_id: `77a3090683e641e58156b3dccf817e9a`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 465c30c753e940c9841360897712cdd9

- run_id: `465c30c753e940c9841360897712cdd9`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run 927899ece912403b8157f84a4a1a8206

- run_id: `927899ece912403b8157f84a4a1a8206`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 4232b75b67504e15b801f72c4a6992b9

- run_id: `4232b75b67504e15b801f72c4a6992b9`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run 5b6b6c9596974791939e11977ef4f465

- run_id: `5b6b6c9596974791939e11977ef4f465`
- symbol: **005930**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: UNSPECIFIED
- technical_evidence: -
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted
