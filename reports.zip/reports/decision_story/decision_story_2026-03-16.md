# Decision Story Report (2026-03-16)

- story_total: **163**
- rendered_story_total: **120**
- note: output truncated to first 120 runs

## Run 8687508da60d41f2a8d38f19ef60ab48

- run_id: `8687508da60d41f2a8d38f19ef60ab48`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.00823865175, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.00798, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 4430a575f6374f43b1b0ea9b812640c8

- run_id: `4430a575f6374f43b1b0ea9b812640c8`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.00823865175, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.00798, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run ebcda2b4ece048869d706d6a429f5119

- run_id: `ebcda2b4ece048869d706d6a429f5119`
- symbol: **032820**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: take_profit
- technical_evidence: stop_loss_pct=0.00823865175, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.00798, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 2f7fd3c050354f1bb961a65da45e3833

- run_id: `2f7fd3c050354f1bb961a65da45e3833`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.00823865175, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.00798, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 78e639c8ed9f46fd8f1172a73a62b7a6

- run_id: `78e639c8ed9f46fd8f1172a73a62b7a6`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.00823865175, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.00798, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run c1cb8239469f4b3992ff808d7bbb64cd

- run_id: `c1cb8239469f4b3992ff808d7bbb64cd`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.00823865175, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.00798, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run ea99c395bd924cb4bdaee1c0fc2b41a9

- run_id: `ea99c395bd924cb4bdaee1c0fc2b41a9`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.00823865175, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.00798, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 6baf0b80134445d5bcb7a15bc6cde37c

- run_id: `6baf0b80134445d5bcb7a15bc6cde37c`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run a7adb028fd924de0a9a2d676a050a780

- run_id: `a7adb028fd924de0a9a2d676a050a780`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.0079784838, take_profit_pct=0.0095038396416, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.007875, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 3c6c1eb4a41c4013aacfff3553334991

- run_id: `3c6c1eb4a41c4013aacfff3553334991`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run dedeaddbbbcb47889ce4ef24e344799c

- run_id: `dedeaddbbbcb47889ce4ef24e344799c`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 38aed7101e00409786c78bc561d01b5d

- run_id: `38aed7101e00409786c78bc561d01b5d`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 881326cb74e54b47bd4aa2edbf0ca906

- run_id: `881326cb74e54b47bd4aa2edbf0ca906`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 686da792538349b09be06cb0b29df0bf

- run_id: `686da792538349b09be06cb0b29df0bf`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 0b219084146245f2bcc84851cd256060

- run_id: `0b219084146245f2bcc84851cd256060`
- symbol: **032820**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: stop_loss
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 8f694d381dfe4158baef362c2a1bdf1f

- run_id: `8f694d381dfe4158baef362c2a1bdf1f`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 98bf6b0817604eb8bb02e3c9cb05ef5d

- run_id: `98bf6b0817604eb8bb02e3c9cb05ef5d`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run da8057a4fb8647168aaa12f2a72bffd1

- run_id: `da8057a4fb8647168aaa12f2a72bffd1`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run e33880a824cf49cd96f82270ddd790f3

- run_id: `e33880a824cf49cd96f82270ddd790f3`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 074c2bb35ed84d5baa047f719ac79181

- run_id: `074c2bb35ed84d5baa047f719ac79181`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 29d7f924d39346c486a9a4e0b9601f0d

- run_id: `29d7f924d39346c486a9a4e0b9601f0d`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 3340cf86a03f4b7a99bc8684005bb325

- run_id: `3340cf86a03f4b7a99bc8684005bb325`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run e8b4456fa65a4b06a58c7c815a0be1c2

- run_id: `e8b4456fa65a4b06a58c7c815a0be1c2`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run ca550b48221f41e49ab527671826724c

- run_id: `ca550b48221f41e49ab527671826724c`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 72d834ce20f349e9bc252781ec9473a6

- run_id: `72d834ce20f349e9bc252781ec9473a6`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run c5721c16e34543128d1f02c37d232c61

- run_id: `c5721c16e34543128d1f02c37d232c61`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run ef9ff875f1d4481f9da0d8c2095773c4

- run_id: `ef9ff875f1d4481f9da0d8c2095773c4`
- symbol: **032820**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: stop_loss
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 8c9f4a3502474335bc6f2e22c2f1fcab

- run_id: `8c9f4a3502474335bc6f2e22c2f1fcab`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 12dc8f82ba714c158d0ef54338ce6ab4

- run_id: `12dc8f82ba714c158d0ef54338ce6ab4`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run fc02f3e93dcf4f8fa199602464560f04

- run_id: `fc02f3e93dcf4f8fa199602464560f04`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 3d774dcbd191442e854adbe4480db0c8

- run_id: `3d774dcbd191442e854adbe4480db0c8`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 3c73ce53aa624ae48c133d5f29f6b294

- run_id: `3c73ce53aa624ae48c133d5f29f6b294`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 646caf7cd97a436a98cfc2babe742f29

- run_id: `646caf7cd97a436a98cfc2babe742f29`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 845e38a3581b412e8fa198f8cb204482

- run_id: `845e38a3581b412e8fa198f8cb204482`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 8ef2010a42444581ad8a413fd0b98d0f

- run_id: `8ef2010a42444581ad8a413fd0b98d0f`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run ddb1f92004fb4aca852727497f395d44

- run_id: `ddb1f92004fb4aca852727497f395d44`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 8acd68191d514207aadaea73080ebd37

- run_id: `8acd68191d514207aadaea73080ebd37`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 7071ddcc326c4ec0b811e5f415f27d22

- run_id: `7071ddcc326c4ec0b811e5f415f27d22`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 629f47f568ac4be48f7c7fb5050be3b2

- run_id: `629f47f568ac4be48f7c7fb5050be3b2`
- symbol: **032820**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: stop_loss
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 2b097e950a9141dc99a89ac46c112f43

- run_id: `2b097e950a9141dc99a89ac46c112f43`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 94f085655ae043c8bcaa8e77c097c64b

- run_id: `94f085655ae043c8bcaa8e77c097c64b`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 21a3f1a605624933a43a5811e2039253

- run_id: `21a3f1a605624933a43a5811e2039253`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run d021bd0776744cc38e120be65b4cc721

- run_id: `d021bd0776744cc38e120be65b4cc721`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run fef24b521a24495d84cdef66a73c186f

- run_id: `fef24b521a24495d84cdef66a73c186f`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run c43a468f6c2d47bb92d2be30f02e279e

- run_id: `c43a468f6c2d47bb92d2be30f02e279e`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run f60771eec65d4ce1a65458f98ac927db

- run_id: `f60771eec65d4ce1a65458f98ac927db`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run cb7f628c6df843ae9bb08e07da50c6d6

- run_id: `cb7f628c6df843ae9bb08e07da50c6d6`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 77176d58ff99496f9e399052c5a14ac2

- run_id: `77176d58ff99496f9e399052c5a14ac2`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run f8b27ff07e4e4003b95db1849324becb

- run_id: `f8b27ff07e4e4003b95db1849324becb`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 11d29b9d669740f0bf195523fc064ed0

- run_id: `11d29b9d669740f0bf195523fc064ed0`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 4f30d83498504c8485e86795cecb7abb

- run_id: `4f30d83498504c8485e86795cecb7abb`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run ad5f06c28a664e79ae6a8640ed4b49a2

- run_id: `ad5f06c28a664e79ae6a8640ed4b49a2`
- symbol: **032820**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: stop_loss
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 5426a01525914d6fb9d6dda123fc39e5

- run_id: `5426a01525914d6fb9d6dda123fc39e5`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 56b56601cfb3442d8d7621ba17d77059

- run_id: `56b56601cfb3442d8d7621ba17d77059`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 23025fe41b764d9f8fde2d847b6344ad

- run_id: `23025fe41b764d9f8fde2d847b6344ad`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run a7776f453aeb4e2e9a3299d1b2b5ab5a

- run_id: `a7776f453aeb4e2e9a3299d1b2b5ab5a`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run ada7c7e82a394fc2a042e2985cc2a8f0

- run_id: `ada7c7e82a394fc2a042e2985cc2a8f0`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 2751cf368fcd42ca922bd85c8260681f

- run_id: `2751cf368fcd42ca922bd85c8260681f`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 13d6b1fc402f490d8c79d12d1f2203c4

- run_id: `13d6b1fc402f490d8c79d12d1f2203c4`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 80ffa6d156a849e9a9c157c17dfc94ec

- run_id: `80ffa6d156a849e9a9c157c17dfc94ec`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 815f54ececf241b7b6b81718e0712062

- run_id: `815f54ececf241b7b6b81718e0712062`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run f52b6d00f0e1491bad8113ac10ba237e

- run_id: `f52b6d00f0e1491bad8113ac10ba237e`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 0da253ab47e240638479af6289878b91

- run_id: `0da253ab47e240638479af6289878b91`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 050f434c12c24dfa9b29d6c4e8abfb67

- run_id: `050f434c12c24dfa9b29d6c4e8abfb67`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 6045fe9ccde447f8bc6c318aa45b366e

- run_id: `6045fe9ccde447f8bc6c318aa45b366e`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.0095038396416, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run f17caf0d2fb7495f8577b8fc0f50554c

- run_id: `f17caf0d2fb7495f8577b8fc0f50554c`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 1e8a53e0903a4addbeae7c623dca327d

- run_id: `1e8a53e0903a4addbeae7c623dca327d`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run dfc1c5420c164792b73a076bd717a37f

- run_id: `dfc1c5420c164792b73a076bd717a37f`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 8abf08997b8d428fb52e2007e1aaefd3

- run_id: `8abf08997b8d428fb52e2007e1aaefd3`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.0095038396416, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run d9b49872d04b43dcbbebafe52c4f6a4d

- run_id: `d9b49872d04b43dcbbebafe52c4f6a4d`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.014968800000000004, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run f0334c1f587a40bcb15997c3fb176cad

- run_id: `f0334c1f587a40bcb15997c3fb176cad`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.058875166809416075, take_profit_pct=0.008363378884608001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.029437583404708038, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 303af41c628549c5a84d7ea2cbd570f0

- run_id: `303af41c628549c5a84d7ea2cbd570f0`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.0095038396416, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 4c9b426e12654c4ba43b258b9ad16b6d

- run_id: `4c9b426e12654c4ba43b258b9ad16b6d`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 917586ff70b34f17a43e0831d2dd4296

- run_id: `917586ff70b34f17a43e0831d2dd4296`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.058875166809416075, take_profit_pct=0.005939899776, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.029437583404708038, vol_expansion_ratio=1.6
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 7e9076219daf4f2a84ce081f7f5cfda0

- run_id: `7e9076219daf4f2a84ce081f7f5cfda0`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.058875166809416075, take_profit_pct=0.0095038396416, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.029437583404708038, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 952ea0fa9c534390bfc4359792808c61

- run_id: `952ea0fa9c534390bfc4359792808c61`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.058875166809416075, take_profit_pct=0.014968800000000004, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.029437583404708038, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 36068af0d37f4e7da4813114b07206ab

- run_id: `36068af0d37f4e7da4813114b07206ab`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.011079991296000003, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 85e8b128f35541aa84d7b8b9ece0d8f0

- run_id: `85e8b128f35541aa84d7b8b9ece0d8f0`
- symbol: **032820**
- final_action: **SELL 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: take_profit
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.011079991296000003, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run abd6d376ff80494483b06b6af8c104e7

- run_id: `abd6d376ff80494483b06b6af8c104e7`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run ffa3b341fbaa40ffa3ca0c136994bf57

- run_id: `ffa3b341fbaa40ffa3ca0c136994bf57`
- symbol: **0082N0**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.007180635420000002, take_profit_pct=0.008363378884608001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.007875, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 508f654641d04308b5394fc8dcb93213

- run_id: `508f654641d04308b5394fc8dcb93213`
- symbol: **006910**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 23eec01f13bb44b09ed77e5ff9054880

- run_id: `23eec01f13bb44b09ed77e5ff9054880`
- symbol: **006910**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run dd54b32cbe4d4b8c8dc6c153bed7a0d1

- run_id: `dd54b32cbe4d4b8c8dc6c153bed7a0d1`
- symbol: **0082N0**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.00823865175, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.00798, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run ca15dd7611074f2cb6ef3aa5b3168a7f

- run_id: `ca15dd7611074f2cb6ef3aa5b3168a7f`
- symbol: **0082N0**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.00823865175, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.00798, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 0f3db542d3ba41be9ff599e091521224

- run_id: `0f3db542d3ba41be9ff599e091521224`
- symbol: **006910**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 21e20349ebf44054a618362cf2bd2600

- run_id: `21e20349ebf44054a618362cf2bd2600`
- symbol: **006910**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run e6395a99c47b4bc1b4b0033ad1c8bb48

- run_id: `e6395a99c47b4bc1b4b0033ad1c8bb48`
- symbol: **006910**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.006463800000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=1.6
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 1a855ec3b6c549d5ba65690312c6c080

- run_id: `1a855ec3b6c549d5ba65690312c6c080`
- symbol: **005930**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.053418237444031076, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04807641369962797, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run a2069f8ce1f14797905c74b690851eb5

- run_id: `a2069f8ce1f14797905c74b690851eb5`
- symbol: **A0082N0**
- final_action: **SELL 1**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: take_profit
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run 86b1af4853de426bb94f354ae95d763c

- run_id: `86b1af4853de426bb94f354ae95d763c`
- symbol: **0082N0**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.01047375, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.008379000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 5951e061b37842829d2178a194095c37

- run_id: `5951e061b37842829d2178a194095c37`
- symbol: **A0082N0**
- final_action: **SELL 1**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: take_profit
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run f86a68e1779548d487c96730d08dbf0d

- run_id: `f86a68e1779548d487c96730d08dbf0d`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 11b9d7a45aed4a51899ad18ed8e88c53

- run_id: `11b9d7a45aed4a51899ad18ed8e88c53`
- symbol: **A0082N0**
- final_action: **SELL 1**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: take_profit
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.012985583688000006, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run 2547ee55d86744409faf7591fbe638d0

- run_id: `2547ee55d86744409faf7591fbe638d0`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 0b68de6c6a174e10a96537bcc10a15ec

- run_id: `0b68de6c6a174e10a96537bcc10a15ec`
- symbol: **005930**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.012985583688000006, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 95694e3f5afb4430ba2ff35cd784b167

- run_id: `95694e3f5afb4430ba2ff35cd784b167`
- symbol: **A0082N0**
- final_action: **SELL 1**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: take_profit
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run 30428fdaa6d347b4ad4e510ca4b0b9d8

- run_id: `30428fdaa6d347b4ad4e510ca4b0b9d8`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 083ecdf7421c4a33b62a8b80560f7734

- run_id: `083ecdf7421c4a33b62a8b80560f7734`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run c1c72777baaf456f960a407299021403

- run_id: `c1c72777baaf456f960a407299021403`
- symbol: **A0082N0**
- final_action: **SELL 1**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: take_profit
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run 39cf635cffe748dfb5f1bb0515d7f752

- run_id: `39cf635cffe748dfb5f1bb0515d7f752`
- symbol: **005930**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.006463800000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=1.6
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 5538afb7f9b84efb89597eb9b8b3ab13

- run_id: `5538afb7f9b84efb89597eb9b8b3ab13`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.012985583688000006, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 30a0560f1b294a618a27144caffd32df

- run_id: `30a0560f1b294a618a27144caffd32df`
- symbol: **A0082N0**
- final_action: **SELL 1**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: take_profit
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run 897c4f5bec484a50bf44080561e8417a

- run_id: `897c4f5bec484a50bf44080561e8417a`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 97bf2f6418ae458481b4a68a00b7d014

- run_id: `97bf2f6418ae458481b4a68a00b7d014`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run cef54b96173e4429b5a0d3ffd4592350

- run_id: `cef54b96173e4429b5a0d3ffd4592350`
- symbol: **A0082N0**
- final_action: **SELL 1**
- execution_status: **EXECUTED_FAIL**
- decision_reason_summary: take_profit
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010180485000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order rejected

## Run 5d4d2cd0542046f6a8ec76240e225e98

- run_id: `5d4d2cd0542046f6a8ec76240e225e98`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED_OK**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: order accepted

## Run 1f0305a9fdc744159cddbe2d9a006659

- run_id: `1f0305a9fdc744159cddbe2d9a006659`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010171432009728002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 99147646a1224167b84f4ae5791addc4

- run_id: `99147646a1224167b84f4ae5791addc4`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.011079991296000003, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run cc6deff802da4346ae185ef65d64bbf0

- run_id: `cc6deff802da4346ae185ef65d64bbf0`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 8f2c13c1b2c74019973665c68ea3d4f3

- run_id: `8f2c13c1b2c74019973665c68ea3d4f3`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run f16b46088b7c48f98fdba666c3ab50d3

- run_id: `f16b46088b7c48f98fdba666c3ab50d3`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run b2bf6527af8a4275b9b495040575fe74

- run_id: `b2bf6527af8a4275b9b495040575fe74`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.010171432009728002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run c9b4eb6b53164667913ba9b3bcaadbc9

- run_id: `c9b4eb6b53164667913ba9b3bcaadbc9`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 21e315568ac948cb827fefa9ecc073ff

- run_id: `21e315568ac948cb827fefa9ecc073ff`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.006463800000000001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.07200000000000001, vol_expansion_ratio=1.6
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 0907aa452e8446db818390e2b239420b

- run_id: `0907aa452e8446db818390e2b239420b`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.008933609263103999, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 857f9e58a0a54948a67974d61f9b25ae

- run_id: `857f9e58a0a54948a67974d61f9b25ae`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.011164598550000002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 32436a2729b74927a4a7e612389ca04f

- run_id: `32436a2729b74927a4a7e612389ca04f`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.0121908302208, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run b3883016eb664336ac03c31c620656f4

- run_id: `b3883016eb664336ac03c31c620656f4`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.00940379922432, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 3bb638ccd4e54d2782e7fd563b61189c

- run_id: `3bb638ccd4e54d2782e7fd563b61189c`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.011164598550000002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 3fe9a00ad320469386eab2cf73d6479f

- run_id: `3fe9a00ad320469386eab2cf73d6479f`
- symbol: **000660**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.011164598550000002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped
