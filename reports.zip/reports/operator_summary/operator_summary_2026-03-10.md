# Operator Daily Summary (2026-03-10)

## Executive Summary

- system_status: **[GREEN]**
- [GREEN] runs=1489, executions=313 (ok=161, fail=24), blocks=369.
- Top guard block: NOOP intent skipped (no order sent) (297)
- LLM success_rate=0.00%, interventions=18, cooldowns=18.

## Top Issues

- [GREEN] none: no critical or warning issues detected

## Recommended Operator Actions

- Continue current configuration and monitor next session for regression signals.

## System Health Status

- system_health_level: **[GREEN]**
- reasoning:
  - no critical or warning issues detected
- recommended_action:
  - Continue current configuration and monitor next session for regression signals.

## Trading Activity Summary

- run_total: **1489**
- decision_action_counts: `{"NOOP": 556, "BUY": 226, "SELL": 140}`
- strategy_counts: `{"RegimeMomentumV1": 296, "ExitPolicyStrategist": 220, "CooldownStrategist": 79, "OpenAIStrategist": 212, "RuleStrategist": 38, "AlwaysBuyStrategist": 20, "EODLiquidationStrategist": 21, "NewsMomentumV1": 18, "MeanReversionV1": 18}`
- executions_total: **313**
- blocked_total: **369**
- noop_reason_top_human: GUARD_BLOCK (blocked by safety guard) (312); NO_CANDIDATE (no candidate met entry conditions) (225)
- fallback_signal_status_top_human: global_sentiment_status:fallback (375); symbol_sentiment_status:fallback (355); symbol_sentiment_status:unavailable (20)

## Safety Guard Interventions

- blocked_total: **369**
- blocked_reason_top_human: NOOP intent skipped (no order sent) (297); Blocked by supervisor test rule (24); Blocked duplicate buy (position already open) (24); Insufficient mock cash (24)
- operator_intervention_total: **18**
- cooldown_transition_total: **18**
- duplicate_execution_total: **0**
- guard_precedence_violation_total: **0**
