# Operator Daily Summary (2026-03-09)

## Executive Summary

- system_status: **[GREEN]**
- [GREEN] runs=478, executions=9 (ok=2, fail=1), blocks=383.
- Top guard block: NOOP intent skipped (no order sent) (380)
- LLM success_rate=0.00%, interventions=1, cooldowns=1.

## Top Issues

- [GREEN] none: no critical or warning issues detected

## Recommended Operator Actions

- Continue current configuration and monitor next session for regression signals.

## System Health Status

- system_health_level: **[GREEN]**
- reasoning:
  - no critical or warning issues detected
- recommended_action:
  - Continue current configuration and monitor next session for regression signals.

## Trading Activity Summary

- run_total: **478**
- decision_action_counts: `{"NOOP": 415, "BUY": 13, "SELL": 14}`
- strategy_counts: `{"RegimeMomentumV1": 397, "ExitPolicyStrategist": 11, "CooldownStrategist": 3, "EODLiquidationStrategist": 3, "NewsMomentumV1": 1, "MeanReversionV1": 1, "OpenAIStrategist": 22, "RuleStrategist": 2, "AlwaysBuyStrategist": 2}`
- executions_total: **9**
- blocked_total: **383**
- noop_reason_top_human: GUARD_BLOCK (blocked by safety guard) (379); NO_CANDIDATE (no candidate met entry conditions) (33)
- fallback_signal_status_top_human: global_sentiment_status:fallback (38); symbol_sentiment_status:fallback (36); symbol_sentiment_status:unavailable (2)

## Safety Guard Interventions

- blocked_total: **383**
- blocked_reason_top_human: NOOP intent skipped (no order sent) (380); Blocked by supervisor test rule (1); Blocked duplicate buy (position already open) (1); Insufficient mock cash (1)
- operator_intervention_total: **1**
- cooldown_transition_total: **1**
- duplicate_execution_total: **0**
- guard_precedence_violation_total: **0**
