# Operator Daily Summary (2026-03-07)

## Executive Summary

- system_status: **[GREEN]**
- [GREEN] runs=735, executions=110 (ok=26, fail=13), blocks=64.
- Top guard block: NOOP intent skipped (no order sent) (25)
- LLM success_rate=79.26%, interventions=12, cooldowns=12.

## Top Issues

- [GREEN] none: no critical or warning issues detected

## Recommended Operator Actions

- Continue current configuration and monitor next session for regression signals.

## System Health Status

- system_health_level: **[GREEN]**
- reasoning:
  - no critical or warning issues detected
- recommended_action:
  - Continue current configuration and monitor next session for regression signals.

## Trading Activity Summary

- run_total: **735**
- decision_action_counts: `{"BUY": 170, "NOOP": 184, "SELL": 71}`
- strategy_counts: `{"OpenAIStrategist": 214, "RuleStrategist": 67, "AlwaysBuyStrategist": 23, "ExitPolicyStrategist": 48, "CooldownStrategist": 23, "EODLiquidationStrategist": 23, "RegimeMomentumV1": 17, "NewsMomentumV1": 5, "MeanReversionV1": 5}`
- executions_total: **110**
- blocked_total: **64**
- noop_reason_top_human: Model returned no trade signal (63); Trade rationale missing (23); Strategist runtime error (23); Position already open (23); Post-exit cooldown active (23)
- fallback_signal_status_top_human: global sentiment status:fallback (297); symbol sentiment status:fallback (281); symbol sentiment status:unavailable (16)

## Safety Guard Interventions

- blocked_total: **64**
- blocked_reason_top_human: NOOP intent skipped (no order sent) (25); Blocked by supervisor test rule (13); Blocked duplicate buy (position already open) (13); Insufficient mock cash (13)
- operator_intervention_total: **12**
- cooldown_transition_total: **12**
- duplicate_execution_total: **0**
- guard_precedence_violation_total: **0**
