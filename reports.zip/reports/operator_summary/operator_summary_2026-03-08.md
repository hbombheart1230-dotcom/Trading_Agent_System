# Operator Daily Summary (2026-03-08)

## Executive Summary

- system_status: **[GREEN]**
- [GREEN] runs=69, executions=9 (ok=2, fail=1), blocks=5.
- Top guard block: NOOP intent skipped (no order sent) (2)
- LLM success_rate=75.00%, interventions=1, cooldowns=1.

## Top Issues

- [GREEN] none: no critical or warning issues detected

## Recommended Operator Actions

- Continue current configuration and monitor next session for regression signals.

## System Health Status

- system_health_level: **[GREEN]**
- reasoning:
  - no critical or warning issues detected
- recommended_action:
  - Continue current configuration and monitor next session for regression signals.

## Trading Activity Summary

- run_total: **69**
- decision_action_counts: `{"NOOP": 12, "BUY": 15, "SELL": 4}`
- strategy_counts: `{"OpenAIStrategist": 12, "RuleStrategist": 8, "AlwaysBuyStrategist": 1, "ExitPolicyStrategist": 3, "CooldownStrategist": 1, "EODLiquidationStrategist": 1, "NewsMomentumV1": 1, "MeanReversionV1": 1, "RegimeMomentumV1": 3}`
- executions_total: **9**
- blocked_total: **5**
- noop_reason_top_human: Model returned no trade signal (3); Strategy-v1 returned NOOP (3); Trade rationale missing (1); Strategist runtime error (1); Position already open (1)
- fallback_signal_status_top_human: global_sentiment_status:fallback (24); symbol_sentiment_status:fallback (23); symbol_sentiment_status:unavailable (1)

## Safety Guard Interventions

- blocked_total: **5**
- blocked_reason_top_human: NOOP intent skipped (no order sent) (2); Blocked by supervisor test rule (1); Blocked duplicate buy (position already open) (1); Insufficient mock cash (1)
- operator_intervention_total: **1**
- cooldown_transition_total: **1**
- duplicate_execution_total: **0**
- guard_precedence_violation_total: **0**
