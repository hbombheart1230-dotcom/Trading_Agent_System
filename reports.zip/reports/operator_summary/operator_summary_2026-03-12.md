# Operator Daily Summary (2026-03-12)

## Executive Summary

- system_status: **[RED]**
- [RED] runs=959, executions=363 (ok=235, fail=21), blocks=105.
- Top guard block: NOOP intent skipped (no order sent) (63)
- LLM success_rate=95.78%, interventions=12, cooldowns=12.

## Top Issues

- [YELLOW] excessive_blocked_orders: blocked_rate=376.92% (49/13)
- [RED] slo_incident_gate_failed: m31_slo_incident failure_total=2

## Recommended Operator Actions

- Review allowlist, notional limits, and decision thresholds causing frequent guard blocks.

## System Health Status

- system_health_level: **[RED]**
- reasoning:
  - blocked_rate=376.92% (49/13)
  - m31_slo_incident failure_total=2
- recommended_action:
  - Review allowlist, notional limits, and decision thresholds causing frequent guard blocks.

## Trading Activity Summary

- run_total: **959**
- decision_action_counts: `{"NOOP": 148, "BUY": 98, "SELL": 48}`
- strategy_counts: `{"defensive": 324, "RegimeMomentumV1": 17, "RuleStrategist": 46, "OpenAIStrategist": 132, "AlwaysBuyStrategist": 12, "ExitPolicyStrategist": 53, "CooldownStrategist": 12, "EODLiquidationStrategist": 12, "breakout": 25, "NewsMomentumV1": 5, "MeanReversionV1": 5}`
- executions_total: **363**
- blocked_total: **105**
- noop_reason_top_human: NO_CANDIDATE (no candidate met entry conditions) (116); GUARD_BLOCK (blocked by safety guard) (20)
- fallback_signal_status_top_human: global_sentiment_status:fallback (243); symbol_sentiment_status:fallback (231); symbol_sentiment_status:unavailable (12)

## Safety Guard Interventions

- blocked_total: **105**
- blocked_reason_top_human: NOOP intent skipped (no order sent) (63); Insufficient mock cash (15); Blocked by supervisor test rule (13); Blocked duplicate buy (position already open) (13); Daily loss limit exceeded (1)
- operator_intervention_total: **12**
- cooldown_transition_total: **12**
- duplicate_execution_total: **0**
- guard_precedence_violation_total: **0**
