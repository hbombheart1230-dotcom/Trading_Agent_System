# Broker Trade Reconciliation

- Day: 2026-03-13
- Event log: `data\logs\events.jsonl`
- Generated at: 2026-03-13T05:24:08+00:00

## Summary

- Local executions: 106
- Broker rows: 30
- Matched by ord_no: 30
- Broker window limited: True
- Missing in local: 0
- Missing in broker: 76

## Local Counts
- `005860:BUY`: 7
- `005860:SELL`: 7
- `032820:BUY`: 29
- `032820:SELL`: 30
- `047040:BUY`: 6
- `047040:SELL`: 6
- `233740:BUY`: 10
- `233740:SELL`: 10
- `357880:SELL`: 1

## Broker Counts
- `032820:BUY`: 13
- `032820:SELL`: 13
- `047040:BUY`: 2
- `047040:SELL`: 2

## Missing In Local
- none

## Missing In Broker
- ord_no=0006997 symbol=032820 side=SELL qty=2
- ord_no=0010109 symbol=357880 side=SELL qty=1
- ord_no=0012409 symbol=032820 side=BUY qty=1
- ord_no=0014784 symbol=032820 side=SELL qty=1
- ord_no=0017420 symbol=032820 side=BUY qty=1
- ord_no=0023163 symbol=032820 side=SELL qty=1
- ord_no=0025674 symbol=005860 side=BUY qty=1
- ord_no=0027170 symbol=005860 side=SELL qty=1
- ord_no=0029181 symbol=233740 side=BUY qty=1
- ord_no=0030767 symbol=233740 side=SELL qty=1
- ord_no=0031986 symbol=233740 side=BUY qty=1
- ord_no=0033493 symbol=233740 side=SELL qty=1
- ord_no=0034709 symbol=005860 side=BUY qty=1
- ord_no=0036274 symbol=005860 side=SELL qty=1
- ord_no=0037675 symbol=005860 side=BUY qty=1
- ord_no=0038902 symbol=005860 side=SELL qty=1
- ord_no=0039927 symbol=005860 side=BUY qty=1
- ord_no=0040959 symbol=005860 side=SELL qty=1
- ord_no=0042345 symbol=233740 side=BUY qty=1
- ord_no=0043976 symbol=233740 side=SELL qty=1
