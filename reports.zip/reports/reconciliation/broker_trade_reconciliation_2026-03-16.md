# Broker Trade Reconciliation

- Day: 2026-03-16
- Event log: `data\logs\events.jsonl`
- Generated at: 2026-03-16T00:15:37+00:00

## Summary

- Local executions: 1
- Broker rows: 1
- Matched by ord_no: 1
- Broker window limited: False
- Missing in local: 0
- Missing in broker: 0

## Local Counts
- `032820:SELL`: 1

## Broker Counts
- `032820:SELL`: 1

## Missing In Local
- none

## Missing In Broker
- none
