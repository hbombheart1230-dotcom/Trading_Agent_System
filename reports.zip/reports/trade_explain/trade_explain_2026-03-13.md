# Trade Explain Report (2026-03-13)

- event_log_path: `data\logs\events.jsonl`
- executions_total: **177**
- sell_pairs_total: **63**

## Executive Summary

- symbols_executed: `['005860', '005930', '032820', '047040', '233740', '357880']`
- action_counts: `{'SELL': 63, 'BUY': 114}`
- symbol_side_counts: `{'032820:SELL': 31, '357880:SELL': 1, '032820:BUY': 31, '005930:BUY': 60, '005930:SELL': 8, '005860:BUY': 7, '005860:SELL': 7, '233740:BUY': 10, '233740:SELL': 10, '047040:BUY': 6, '047040:SELL': 6}`
- short_holds_lt_120s: **45**

## Agent Activity Snapshot

- `commander_router`: 822
- `strategist_llm`: 259
- `strategist`: 288
- `decision_trace`: 1465
- `scanner`: 346
- `monitor`: 447
- `execute_from_packet`: 1238
- `decision`: 88
- `skill_execute`: 20
- `skill_result`: 20
- `skill_hydration`: 240

## Report Inventory

- `reports\operator_summary\operator_summary_2026-03-13.md`
- `reports\decision_story\decision_story_2026-03-13.md`
- `reports\run_cards\run_cards_2026-03-13.md`
- `reports\metrics\metrics_2026-03-13.md`
- `reports\daily\daily_2026-03-13.md`

## Execution Timeline (Latest)

| ts | run_id | symbol | action | qty | price | strategy | reason |
| --- | --- | --- | --- | ---: | ---: | --- | --- |
| 2026-03-13T00:01:19+00:00 | `1bac177f42e84156ae4a216ac2196c91` | 032820 | SELL | 2 | 0.0 | - | - |
| 2026-03-13T00:02:52+00:00 | `82f0a7f9f5b1476eb33dc8d594e6d60c` | 357880 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T00:04:20+00:00 | `51dbcc5ff2154312a7390e7573264e8f` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T00:05:52+00:00 | `87859b03a878484fb467824f0e48f67c` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T00:07:32+00:00 | `5bf8f6f86efe4577a3e274dfbb3c8d3a` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T00:09:24+00:00 | `trace-r2` | 005930 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T00:09:24+00:00 | `47bc201927764ceea124cf051933f986` | 005930 | SELL | 20 | 70000.0 | - | - |
| 2026-03-13T00:09:24+00:00 | `a555848d5c594be696fa6f085434e57d` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:09:24+00:00 | `a9ed116eb93543028257b2c50abd0512` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:09:24+00:00 | `d634a41fc7db425580a2c09dbcd36be9` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:09:24+00:00 | `69eae09b171f489fae211b14c83af4ef` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:09:24+00:00 | `58b3e587a026431f8b7d2e17b3091e7b` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:09:28+00:00 | `6d061f3995dd4cba905db87101183255` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:09:28+00:00 | `b0e9c055b2c242b8a4506ce633d1d00d` | 005930 | BUY | 1 | 71200.0 | RuleStrategist | rule:cash_and_price_ok |
| 2026-03-13T00:09:51+00:00 | `7b6ceae5699241a99ae9beb44e5fe4a7` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:09:53+00:00 | `58c7843214454541a01a9757054fd766` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:11:47+00:00 | `12867f00ac1f41f8a669e74d8655f154` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T00:13:53+00:00 | `5ab553e30f61452da24cb509f218bbfd` | 005860 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T00:15:15+00:00 | `d2d1393d3f87427194002564c36e2225` | 005860 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T00:17:07+00:00 | `8a3ea770238e45f0a8e5bfc8a8f5ccce` | 233740 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T00:18:44+00:00 | `86277ec152f64f0ca232584e7441fe36` | 233740 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T00:20:11+00:00 | `64406162cdca40e984c03df056154fe0` | 233740 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T00:21:33+00:00 | `081bfddefd4f4d22a57d91ec904de89c` | 233740 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T00:22:52+00:00 | `d0a47ceeed53421689adff6d96b8a57a` | 005860 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T00:24:38+00:00 | `79d04336b65640939d273a2b91fbe834` | 005860 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T00:26:11+00:00 | `0a05658a92514653a037a7782db7b067` | 005860 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T00:27:32+00:00 | `049976e6bd9a4e4e9345427f0b7f97df` | 005860 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T00:28:54+00:00 | `f1b6bac7b1c344538625d468931cf05c` | 005860 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T00:30:11+00:00 | `ea15fbca7137450ea9420f8c711fe01a` | 005860 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T00:31:31+00:00 | `8e861c7f21874143a6af25bb97e2d08c` | 233740 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T00:33:27+00:00 | `37269a69769d4e3b9b2dbade9f7eda99` | 233740 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T00:34:50+00:00 | `4577bcc3fd8948e7b80d34e218a6755a` | 233740 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T00:37:28+00:00 | `fc86931f3ece400ba5d986e6eeeb8832` | 233740 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T00:38:45+00:00 | `3c8a2663f48b49baacd9ff6f40f7ad20` | 233740 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T00:40:12+00:00 | `cdd30fa5dde44101915221892a637fe4` | 233740 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T00:42:17+00:00 | `b7bbd6833f144ac692982200ca0fb29d` | 233740 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T00:43:29+00:00 | `86eb6f27ab1c42b3a4f9b65289da9a0d` | 233740 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T00:44:53+00:00 | `0d992cdbde6b44c2b9a9f71cbfd0f002` | 005860 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T00:46:04+00:00 | `c46f815522d04e02ad018892ec44107d` | 005860 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T00:46:07+00:00 | `5ad490b3f27c4ebd8ebab8e62ea4c3ae` | 005930 | SELL | 20 | 70000.0 | - | - |
| 2026-03-13T00:46:07+00:00 | `fa8ed8a702ba4d45a273c210ddc31dfc` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:46:07+00:00 | `0b08ddcab9054773a7ff0712254036d5` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:46:07+00:00 | `053205b32a7d4f8298b0e62b70281d43` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:46:07+00:00 | `2f13f33589c746db95aad2c088ca04fc` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:46:07+00:00 | `7193ea777bc443799609a8dd3aa24548` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:46:46+00:00 | `8e0cef0a8d4d43dfbaa971d2ff297381` | 005930 | SELL | 20 | 70000.0 | - | - |
| 2026-03-13T00:46:46+00:00 | `95bd651e5f5c477c8eb669b497817b1e` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:46:46+00:00 | `4570ae06d3d54eae84a90a3b261f97bb` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:46:46+00:00 | `d8c1fa9240bc4f05a7e1fc945523d33c` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:46:46+00:00 | `b06a3daf69e04967b2d997210c003693` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:46:46+00:00 | `292abdd6339342e780d8a3f3e71faa43` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:48:13+00:00 | `90d7564866e74dde8883279e85b4a345` | 005860 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T00:48:54+00:00 | `df1c388e00084f84bec3e5ae56e38c9d` | 005930 | SELL | 20 | 70000.0 | - | - |
| 2026-03-13T00:48:54+00:00 | `2c93efdd7c734a87942929ceeb4322f6` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:48:54+00:00 | `0fb469a5961c45d8bcc12435ed3c43f6` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:48:54+00:00 | `9901f1d3c2c740e7867e541327352a5d` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:48:54+00:00 | `2ef1680db1b24884bcfd11f305a4e57c` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:48:54+00:00 | `b6b6eb811c8b424c932b35009a0847ae` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:48:55+00:00 | `trace-r2` | 005930 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T00:48:55+00:00 | `0af4da673cf640bf92b46fd1be84b965` | 005930 | SELL | 20 | 70000.0 | - | - |
| 2026-03-13T00:48:55+00:00 | `6b9bca04cede42f89e50a9ea1d64fd23` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:48:55+00:00 | `6d95b3b69d2e4ea18912aebbf5aa74e9` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:48:55+00:00 | `7eae96dbed734b91ba608e5b54994948` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:48:55+00:00 | `b280d7b0b26348d5bd2f4600d3621eb9` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:48:55+00:00 | `643e460592464c3a972c99bf845d820b` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:48:58+00:00 | `6448c0fc963746e1845655f48159ae87` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:48:58+00:00 | `70c2b019fb4e42ca84cb17fdc72ff7ff` | 005930 | BUY | 1 | 71200.0 | RuleStrategist | rule:cash_and_price_ok |
| 2026-03-13T00:49:17+00:00 | `7bbddad2a31b44879f089faa2924e830` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:49:19+00:00 | `b0c5ecc55fbb4ec1ab480695e3467d08` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:49:44+00:00 | `1255b836814e47cc889d2ba099d5a050` | 005860 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T00:50:43+00:00 | `trace-r2` | 005930 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T00:50:43+00:00 | `b470744409434759b40b577e8a6d495c` | 005930 | SELL | 20 | 70000.0 | - | - |
| 2026-03-13T00:50:43+00:00 | `960e19ad85f543cea4e285f08352b5a9` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:50:43+00:00 | `b02a193428b54f54b2dfbe8a58f8d6a7` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:50:43+00:00 | `5bfc730097d84336898bc48cb6ba3e4a` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:50:43+00:00 | `a1f03353dad645a6bd4ecb66f45ca499` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:50:43+00:00 | `803aed8e117b461cb3197bbb17676245` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:50:46+00:00 | `4f54fec789e44ce5823fd8cefccb39c0` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:50:46+00:00 | `b5e2282c9eb8463fab7469cee46054e9` | 005930 | BUY | 1 | 71200.0 | RuleStrategist | rule:cash_and_price_ok |
| 2026-03-13T00:51:06+00:00 | `21ec3ec38abb4fbaaf1d4029bee180da` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:51:08+00:00 | `8c1dd745913a4bdab58cfbc74f83e0d8` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T00:51:12+00:00 | `19ed5c8e896649e1aae23d49d8b4c5c8` | 005860 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T00:52:45+00:00 | `29f980c740044136af220f65785a7097` | 005860 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T00:54:23+00:00 | `f7965ed7b6be42fe8b3e135c42e30418` | 233740 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T00:56:06+00:00 | `4bd27ead9f2047fd92b3f639e7fec0de` | 233740 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T01:00:24+00:00 | `1dcb69167c614340a135ddc152f14f6a` | 233740 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T01:03:23+00:00 | `119acd82029b43e59788c978828ae760` | 233740 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T01:05:05+00:00 | `34e491764dac4188a528835e429250a8` | 233740 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T01:06:51+00:00 | `493d8540e44448dbac34df9686dbf8d0` | 233740 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T01:08:20+00:00 | `ec2c3f7e27724462a1ee67cdbd9c409a` | 233740 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T01:09:59+00:00 | `2efee83ec26649e9bb6d4cccc5128590` | 233740 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T01:11:36+00:00 | `933b614fd70240f8a78274baa6c2c137` | 047040 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T01:13:24+00:00 | `f4b469f423af49b28fd59f4a6c2d9738` | 047040 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T01:14:56+00:00 | `e404d04de4354fdf81fbe605417832e1` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T01:16:13+00:00 | `cfc42c14c5134ef2a1df1aa48beacd7d` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T01:19:51+00:00 | `c47212ea897d4348a6f98cc955bb8750` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T01:21:25+00:00 | `95c6f2f5e2524b15b803d1aef1465b4e` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T01:22:45+00:00 | `7c85d0bc821e4746971810a530a685aa` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T01:24:09+00:00 | `e9f00830f21b4c77a13174584521e920` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T01:25:30+00:00 | `a481eaee6d0e463aaa96d529c2a940a4` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T01:26:59+00:00 | `83a8ffc8feb04536a1d8ac3178de0266` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T01:28:40+00:00 | `de109e451a9a41b5ac2bfb70be9454fa` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T01:30:11+00:00 | `03ed886afc0e4bb19e6316f8952b7c67` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T01:32:04+00:00 | `729966cad8ec44b2b6249bb06dd0e7c1` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T01:33:22+00:00 | `589da2143d414ed39bf95c6bb3331da6` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T01:34:44+00:00 | `86e5af2ba12b42cfabe5f924a35aff22` | 047040 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T01:36:22+00:00 | `52e1f38644644657aa59b1bded2a29e9` | 047040 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T01:38:01+00:00 | `0ac7e0d007444bd7a19ec44f1fdc4cfb` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T01:39:24+00:00 | `6f1c13adb0784834b303c4abe3099744` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T01:40:55+00:00 | `e3ae59e4b02844a38ff48270945ae8d1` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T01:42:18+00:00 | `91e128028d7d4447a5b003abfcd70875` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T01:43:46+00:00 | `003976726a2f42038eebb21abfd2d787` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T01:45:19+00:00 | `1dd3cb6176a64fa582c6a1d272662d6c` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T01:46:48+00:00 | `bb698d4a51ed4df2baaf0f21e2571af8` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T01:48:12+00:00 | `ddc240738a214098a44291d87972e413` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T01:49:39+00:00 | `74ba31809a5246b98e3afbf84a42332b` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T01:51:10+00:00 | `af54f16a693e4b2286c22545ab0dcc94` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T01:53:04+00:00 | `dcf49176ef5b40bba812428ae1c6f6f8` | 047040 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T01:54:31+00:00 | `c83c5d2a1d264c6b8626cc87d7cedffc` | 047040 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T02:15:01+00:00 | `a9f9e9bd842c4625822d382cab079e39` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T02:16:28+00:00 | `9242a5dab3f043a0ab43da5d35857400` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T02:17:52+00:00 | `e6a69adaf5424b2c98a09a864130cbaa` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T02:19:14+00:00 | `56b91822e0964d83a9e9119720224f23` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T02:20:44+00:00 | `822f8926d3cd43059ed9b650688048d9` | 047040 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T02:22:11+00:00 | `b8fbddabf3f745688b8a5392bab43d64` | 047040 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T02:23:57+00:00 | `0f49bcb301ba4ab1bcdc443f48eda01b` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T02:25:17+00:00 | `860a23e2a03e4312913847cb0aa64fca` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T02:26:49+00:00 | `f94985908503483ab6b7f0015c663b30` | 047040 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T02:28:15+00:00 | `e37ee613c79449be8d5ed7124104d57e` | 047040 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T02:29:42+00:00 | `b0a3d1ba06b24994b70682177748d7d4` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T02:31:18+00:00 | `9c985c703f814957adf6da24b4b709a6` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T02:33:43+00:00 | `4cc7486064d048759f91ef797f6ec396` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T02:35:12+00:00 | `b69f2bd678ce49edba43a297401828ec` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T02:36:44+00:00 | `3ae7e84401d44e1096c28668444c27be` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T02:38:10+00:00 | `229ad255d5ea42408ee55c2b8e76f2a7` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T02:38:58+00:00 | `b9f61609e4004ec8aabdc06fd40ae61d` | 005930 | SELL | 20 | 70000.0 | - | - |
| 2026-03-13T02:38:58+00:00 | `0084c002d2e84ed6bccf670bc8f3ecb6` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T02:38:58+00:00 | `7b0c793206ec4e248fca38ce6c751883` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T02:38:58+00:00 | `3fc54aa927d54e98a8f7b1bec0b25df4` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T02:38:58+00:00 | `a334dc6f39f443fbae78400a6252113e` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T02:38:58+00:00 | `63a9617253124ac3ac4bdf9f928aee50` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T02:39:18+00:00 | `trace-r2` | 005930 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T02:39:18+00:00 | `824a02de54824fc38357c44aa2e0d077` | 005930 | SELL | 20 | 70000.0 | - | - |
| 2026-03-13T02:39:18+00:00 | `d706e09d2bda4cd19057910567e9c093` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T02:39:18+00:00 | `e01a8738584c460f8903e40ab627e9f7` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T02:39:18+00:00 | `8c48917f0d6046b1af0827f43e25e602` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T02:39:18+00:00 | `be5270d9c14040749ae43314805f1c4e` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T02:39:18+00:00 | `214761af279341f9ac5b97cea83e0d38` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T02:39:33+00:00 | `8f3a6d7969424e11942e471b308194b1` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T02:39:33+00:00 | `8cc8229ffe674c9a84919da6a0a68097` | 005930 | BUY | 1 | 71200.0 | RuleStrategist | rule:cash_and_price_ok |
| 2026-03-13T02:39:35+00:00 | `8ee3e5c6a3d443bdb67bc0fcf07ebee9` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T02:40:21+00:00 | `c3d39e353bca45809ecb2bc5de6a708f` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T02:40:25+00:00 | `e0d6d1caa0c6414ba1cca9ebf30c5878` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-13T02:52:40+00:00 | `96adfc5568884a80a8d9b93321d5f33b` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T03:00:48+00:00 | `415422b248984e6da475831b1617405d` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T03:10:35+00:00 | `2cb35c0cf4154333ac061b33cd457bff` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T03:12:25+00:00 | `0f83887665184bbdba8fcbdf0363fa73` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T03:28:09+00:00 | `093092cf48bc47e0a841f08432af8cab` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T03:29:25+00:00 | `4f7b34eab8854252b06ca8d983c0971d` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T03:39:47+00:00 | `232c37904b5b4badbfba8ec8ec94e059` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T03:42:41+00:00 | `0c5b47f066c24d91842420600241ae9c` | 047040 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T03:50:57+00:00 | `07992db88e3d445b8329ee11491d935b` | 047040 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T03:52:26+00:00 | `ef2066b173f549ebb5a25927a0d43a99` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T04:05:45+00:00 | `e8068ee702df4b54a08c4c558fdaf9d2` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T04:07:16+00:00 | `ebaa63602b774e1ba2cc58e3ff3eb616` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T04:23:06+00:00 | `ba18195f27dc4714bd232a45270c1306` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T04:24:47+00:00 | `804cd3d25f6f4f8e91215d1d8d70cdf9` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T04:30:52+00:00 | `492255d84ae24af28ce47c77c2ae6bc3` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T04:32:30+00:00 | `97d850a56c6b4b398eee4bd07d90e590` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T04:47:37+00:00 | `19f59c5a218e4ff997fd6658ef6e1d3a` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T04:49:02+00:00 | `ccf18d1bad5a4ad2afe3481e66bf6765` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T05:04:04+00:00 | `a866121427ed4f5790cb46c863616238` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T05:05:37+00:00 | `981a6460918548b18f61bb956f31a6e7` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T05:21:23+00:00 | `a935927e1bc8418aa4dfad2cae198bfe` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T05:27:12+00:00 | `a061a807f963400bb01844314948c19a` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-13T05:39:10+00:00 | `6e27f72d0e8d4e3e8babf727be87ff34` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-13T05:55:06+00:00 | `a5a23498a5ec4752b85b6679ada7a521` | 032820 | BUY | 1 | 0.0 | - | - |

## Sell Pair Analysis (FIFO, Latest)

### SELL `1bac177f42e84156ae4a216ac2196c91` / 032820
- sell_ts: 2026-03-13T00:01:19+00:00
- qty: sell=2, matched=0, unmatched=2
- hold_duration_sec_avg: **0** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1266308607308542
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `[]`

### SELL `82f0a7f9f5b1476eb33dc8d594e6d60c` / 357880
- sell_ts: 2026-03-13T00:02:52+00:00
- qty: sell=1, matched=0, unmatched=1
- hold_duration_sec_avg: **0** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1210373460818166
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=take_profit, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `[]`

### SELL `87859b03a878484fb467824f0e48f67c` / 032820
- sell_ts: 2026-03-13T00:05:52+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **92** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1251503916588181
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['51dbcc5ff2154312a7390e7573264e8f']`

### SELL `47bc201927764ceea124cf051933f986` / 005930
- sell_ts: 2026-03-13T00:09:24+00:00
- qty: sell=20, matched=1, unmatched=19
- hold_duration_sec_avg: **0** / estimated_realized_pnl: **70000.0**
- entry_vs_exit_price: entry_avg=0.0, exit=70000.0
- strategy: -
- sell_reason: -
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['trace-r2']`

### SELL `12867f00ac1f41f8a669e74d8655f154` / 032820
- sell_ts: 2026-03-13T00:11:47+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **255** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=005860, top_score=0.4200608093449305
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['5bf8f6f86efe4577a3e274dfbb3c8d3a']`

### SELL `d2d1393d3f87427194002564c36e2225` / 005860
- sell_ts: 2026-03-13T00:15:15+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **82** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=233740, top_score=1.096860488306455
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['5ab553e30f61452da24cb509f218bbfd']`

### SELL `86277ec152f64f0ca232584e7441fe36` / 233740
- sell_ts: 2026-03-13T00:18:44+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **97** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=233740, top_score=1.096546733376543
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['8a3ea770238e45f0a8e5bfc8a8f5ccce']`

### SELL `081bfddefd4f4d22a57d91ec904de89c` / 233740
- sell_ts: 2026-03-13T00:21:33+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **82** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=233740, top_score=1.09615965176037
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['64406162cdca40e984c03df056154fe0']`

### SELL `79d04336b65640939d273a2b91fbe834` / 005860
- sell_ts: 2026-03-13T00:24:38+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **106** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=005860, top_score=0.4216625609387995
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['d0a47ceeed53421689adff6d96b8a57a']`

### SELL `049976e6bd9a4e4e9345427f0b7f97df` / 005860
- sell_ts: 2026-03-13T00:27:32+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **81** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=233740, top_score=1.0961630328081282
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['0a05658a92514653a037a7782db7b067']`

### SELL `ea15fbca7137450ea9420f8c711fe01a` / 005860
- sell_ts: 2026-03-13T00:30:11+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **77** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=233740, top_score=1.096164538369168
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['f1b6bac7b1c344538625d468931cf05c']`

### SELL `37269a69769d4e3b9b2dbade9f7eda99` / 233740
- sell_ts: 2026-03-13T00:33:27+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **116** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=233740, top_score=1.096931936635139
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['8e861c7f21874143a6af25bb97e2d08c']`

### SELL `fc86931f3ece400ba5d986e6eeeb8832` / 233740
- sell_ts: 2026-03-13T00:37:28+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **158** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=005860, top_score=0.4200762203537135
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['4577bcc3fd8948e7b80d34e218a6755a']`

### SELL `cdd30fa5dde44101915221892a637fe4` / 233740
- sell_ts: 2026-03-13T00:40:12+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **87** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=233740, top_score=1.0973182669129835
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['3c8a2663f48b49baacd9ff6f40f7ad20']`

### SELL `86eb6f27ab1c42b3a4f9b65289da9a0d` / 233740
- sell_ts: 2026-03-13T00:43:29+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **72** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=005860, top_score=0.42165917989104124
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['b7bbd6833f144ac692982200ca0fb29d']`

### SELL `c46f815522d04e02ad018892ec44107d` / 005860
- sell_ts: 2026-03-13T00:46:04+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **71** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=005860, top_score=0.4216542933174552
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['0d992cdbde6b44c2b9a9f71cbfd0f002']`

### SELL `5ad490b3f27c4ebd8ebab8e62ea4c3ae` / 005930
- sell_ts: 2026-03-13T00:46:07+00:00
- qty: sell=20, matched=9, unmatched=11
- hold_duration_sec_avg: **2196** / estimated_realized_pnl: **-1200.0**
- entry_vs_exit_price: entry_avg=70133.3333, exit=70000.0
- strategy: -
- sell_reason: -
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['a555848d5c594be696fa6f085434e57d', 'a9ed116eb93543028257b2c50abd0512', 'd634a41fc7db425580a2c09dbcd36be9', '69eae09b171f489fae211b14c83af4ef', '58b3e587a026431f8b7d2e17b3091e7b', '6d061f3995dd4cba905db87101183255', 'b0e9c055b2c242b8a4506ce633d1d00d', '7b6ceae5699241a99ae9beb44e5fe4a7', '58c7843214454541a01a9757054fd766']`

### SELL `8e0cef0a8d4d43dfbaa971d2ff297381` / 005930
- sell_ts: 2026-03-13T00:46:46+00:00
- qty: sell=20, matched=5, unmatched=15
- hold_duration_sec_avg: **39** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=70000.0, exit=70000.0
- strategy: -
- sell_reason: -
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['fa8ed8a702ba4d45a273c210ddc31dfc', '0b08ddcab9054773a7ff0712254036d5', '053205b32a7d4f8298b0e62b70281d43', '2f13f33589c746db95aad2c088ca04fc', '7193ea777bc443799609a8dd3aa24548']`

### SELL `df1c388e00084f84bec3e5ae56e38c9d` / 005930
- sell_ts: 2026-03-13T00:48:54+00:00
- qty: sell=20, matched=5, unmatched=15
- hold_duration_sec_avg: **128** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=70000.0, exit=70000.0
- strategy: -
- sell_reason: -
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['95bd651e5f5c477c8eb669b497817b1e', '4570ae06d3d54eae84a90a3b261f97bb', 'd8c1fa9240bc4f05a7e1fc945523d33c', 'b06a3daf69e04967b2d997210c003693', '292abdd6339342e780d8a3f3e71faa43']`

### SELL `0af4da673cf640bf92b46fd1be84b965` / 005930
- sell_ts: 2026-03-13T00:48:55+00:00
- qty: sell=20, matched=6, unmatched=14
- hold_duration_sec_avg: **1** / estimated_realized_pnl: **70000.0**
- entry_vs_exit_price: entry_avg=58333.3333, exit=70000.0
- strategy: -
- sell_reason: -
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['2c93efdd7c734a87942929ceeb4322f6', '0fb469a5961c45d8bcc12435ed3c43f6', '9901f1d3c2c740e7867e541327352a5d', '2ef1680db1b24884bcfd11f305a4e57c', 'b6b6eb811c8b424c932b35009a0847ae', 'trace-r2']`

### SELL `1255b836814e47cc889d2ba099d5a050` / 005860
- sell_ts: 2026-03-13T00:49:44+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **91** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=233740, top_score=1.0929502782441214
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['90d7564866e74dde8883279e85b4a345']`

### SELL `b470744409434759b40b577e8a6d495c` / 005930
- sell_ts: 2026-03-13T00:50:43+00:00
- qty: sell=20, matched=10, unmatched=10
- hold_duration_sec_avg: **92** / estimated_realized_pnl: **68800.0**
- entry_vs_exit_price: entry_avg=63120.0, exit=70000.0
- strategy: -
- sell_reason: -
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['6b9bca04cede42f89e50a9ea1d64fd23', '6d95b3b69d2e4ea18912aebbf5aa74e9', '7eae96dbed734b91ba608e5b54994948', 'b280d7b0b26348d5bd2f4600d3621eb9', '643e460592464c3a972c99bf845d820b', '6448c0fc963746e1845655f48159ae87', '70c2b019fb4e42ca84cb17fdc72ff7ff', '7bbddad2a31b44879f089faa2924e830', 'b0c5ecc55fbb4ec1ab480695e3467d08', 'trace-r2']`

### SELL `29f980c740044136af220f65785a7097` / 005860
- sell_ts: 2026-03-13T00:52:45+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **93** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=233740, top_score=1.0903121332733854
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['19ed5c8e896649e1aae23d49d8b4c5c8']`

### SELL `4bd27ead9f2047fd92b3f639e7fec0de` / 233740
- sell_ts: 2026-03-13T00:56:06+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **103** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=233740, top_score=1.0965328250414808
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['f7965ed7b6be42fe8b3e135c42e30418']`

### SELL `119acd82029b43e59788c978828ae760` / 233740
- sell_ts: 2026-03-13T01:03:23+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **179** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=047040, top_score=0.5908251218884479
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['1dcb69167c614340a135ddc152f14f6a']`

### SELL `493d8540e44448dbac34df9686dbf8d0` / 233740
- sell_ts: 2026-03-13T01:06:51+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **106** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=233740, top_score=1.0953877396977734
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['34e491764dac4188a528835e429250a8']`

### SELL `2efee83ec26649e9bb6d4cccc5128590` / 233740
- sell_ts: 2026-03-13T01:09:59+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **99** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=047040, top_score=0.590052787778115
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['ec2c3f7e27724462a1ee67cdbd9c409a']`

### SELL `f4b469f423af49b28fd59f4a6c2d9738` / 047040
- sell_ts: 2026-03-13T01:13:24+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **108** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1149189719320043
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['933b614fd70240f8a78274baa6c2c137']`

### SELL `cfc42c14c5134ef2a1df1aa48beacd7d` / 032820
- sell_ts: 2026-03-13T01:16:13+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **77** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1157945106512352
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['e404d04de4354fdf81fbe605417832e1']`

### SELL `95c6f2f5e2524b15b803d1aef1465b4e` / 032820
- sell_ts: 2026-03-13T01:21:25+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **94** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1247967615680683
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['c47212ea897d4348a6f98cc955bb8750']`

### SELL `e9f00830f21b4c77a13174584521e920` / 032820
- sell_ts: 2026-03-13T01:24:09+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **84** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1474975679063422
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['7c85d0bc821e4746971810a530a685aa']`

### SELL `83a8ffc8feb04536a1d8ac3178de0266` / 032820
- sell_ts: 2026-03-13T01:26:59+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **89** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1262668804654465
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['a481eaee6d0e463aaa96d529c2a940a4']`

### SELL `03ed886afc0e4bb19e6316f8952b7c67` / 032820
- sell_ts: 2026-03-13T01:30:11+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **91** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1281991780591343
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['de109e451a9a41b5ac2bfb70be9454fa']`

### SELL `589da2143d414ed39bf95c6bb3331da6` / 032820
- sell_ts: 2026-03-13T01:33:22+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **78** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1283458384507612
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['729966cad8ec44b2b6249bb06dd0e7c1']`

### SELL `52e1f38644644657aa59b1bded2a29e9` / 047040
- sell_ts: 2026-03-13T01:36:22+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **98** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=047040, top_score=0.5908326380976996
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['86e5af2ba12b42cfabe5f924a35aff22']`

### SELL `6f1c13adb0784834b303c4abe3099744` / 032820
- sell_ts: 2026-03-13T01:39:24+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **83** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1300781230873347
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['0ac7e0d007444bd7a19ec44f1fdc4cfb']`

### SELL `91e128028d7d4447a5b003abfcd70875` / 032820
- sell_ts: 2026-03-13T01:42:18+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **83** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.130073612174683
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['e3ae59e4b02844a38ff48270945ae8d1']`

### SELL `1dd3cb6176a64fa582c6a1d272662d6c` / 032820
- sell_ts: 2026-03-13T01:45:19+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **93** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1291624130755822
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['003976726a2f42038eebb21abfd2d787']`

### SELL `ddc240738a214098a44291d87972e413` / 032820
- sell_ts: 2026-03-13T01:48:12+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **84** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1304033913503637
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['bb698d4a51ed4df2baaf0f21e2571af8']`

### SELL `af54f16a693e4b2286c22545ab0dcc94` / 032820
- sell_ts: 2026-03-13T01:51:10+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **91** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1104045183425266
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['74ba31809a5246b98e3afbf84a42332b']`

### SELL `c83c5d2a1d264c6b8626cc87d7cedffc` / 047040
- sell_ts: 2026-03-13T01:54:31+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **87** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=047040, top_score=0.5908172272342711
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['dcf49176ef5b40bba812428ae1c6f6f8']`

### SELL `9242a5dab3f043a0ab43da5d35857400` / 032820
- sell_ts: 2026-03-13T02:16:28+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **87** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=047040, top_score=0.5900370013243302
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['a9f9e9bd842c4625822d382cab079e39']`

### SELL `56b91822e0964d83a9e9119720224f23` / 032820
- sell_ts: 2026-03-13T02:19:14+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **82** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.111526489929546
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['e6a69adaf5424b2c98a09a864130cbaa']`

### SELL `b8fbddabf3f745688b8a5392bab43d64` / 047040
- sell_ts: 2026-03-13T02:22:11+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **87** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.111529873762424
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['822f8926d3cd43059ed9b650688048d9']`

### SELL `860a23e2a03e4312913847cb0aa64fca` / 032820
- sell_ts: 2026-03-13T02:25:17+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **80** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=047040, top_score=0.5900358743490739
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['0f49bcb301ba4ab1bcdc443f48eda01b']`

### SELL `e37ee613c79449be8d5ed7124104d57e` / 047040
- sell_ts: 2026-03-13T02:28:15+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **86** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=047040, top_score=0.5900321149108543
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['f94985908503483ab6b7f0015c663b30']`

### SELL `9c985c703f814957adf6da24b4b709a6` / 032820
- sell_ts: 2026-03-13T02:31:18+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **96** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1115167199240232
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['b0a3d1ba06b24994b70682177748d7d4']`

### SELL `b69f2bd678ce49edba43a297401828ec` / 032820
- sell_ts: 2026-03-13T02:35:12+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **89** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1115129605025251
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['4cc7486064d048759f91ef797f6ec396']`

### SELL `229ad255d5ea42408ee55c2b8e76f2a7` / 032820
- sell_ts: 2026-03-13T02:38:10+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **86** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1104107534272223
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['3ae7e84401d44e1096c28668444c27be']`

### SELL `b9f61609e4004ec8aabdc06fd40ae61d` / 005930
- sell_ts: 2026-03-13T02:38:58+00:00
- qty: sell=20, matched=9, unmatched=11
- hold_duration_sec_avg: **6489** / estimated_realized_pnl: **-1200.0**
- entry_vs_exit_price: entry_avg=70133.3333, exit=70000.0
- strategy: -
- sell_reason: -
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['960e19ad85f543cea4e285f08352b5a9', 'b02a193428b54f54b2dfbe8a58f8d6a7', '5bfc730097d84336898bc48cb6ba3e4a', 'a1f03353dad645a6bd4ecb66f45ca499', '803aed8e117b461cb3197bbb17676245', '4f54fec789e44ce5823fd8cefccb39c0', 'b5e2282c9eb8463fab7469cee46054e9', '21ec3ec38abb4fbaaf1d4029bee180da', '8c1dd745913a4bdab58cfbc74f83e0d8']`

### SELL `824a02de54824fc38357c44aa2e0d077` / 005930
- sell_ts: 2026-03-13T02:39:18+00:00
- qty: sell=20, matched=6, unmatched=14
- hold_duration_sec_avg: **17** / estimated_realized_pnl: **70000.0**
- entry_vs_exit_price: entry_avg=58333.3333, exit=70000.0
- strategy: -
- sell_reason: -
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['0084c002d2e84ed6bccf670bc8f3ecb6', '7b0c793206ec4e248fca38ce6c751883', '3fc54aa927d54e98a8f7b1bec0b25df4', 'a334dc6f39f443fbae78400a6252113e', '63a9617253124ac3ac4bdf9f928aee50', 'trace-r2']`

### SELL `96adfc5568884a80a8d9b93321d5f33b` / 032820
- sell_ts: 2026-03-13T02:52:40+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **785** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1104006051179711
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['8ee3e5c6a3d443bdb67bc0fcf07ebee9']`

### SELL `2cb35c0cf4154333ac061b33cd457bff` / 032820
- sell_ts: 2026-03-13T03:10:35+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **587** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=047040, top_score=0.5886254224937408
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['415422b248984e6da475831b1617405d']`

### SELL `093092cf48bc47e0a841f08432af8cab` / 032820
- sell_ts: 2026-03-13T03:28:09+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **944** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1331465572339197
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['0f83887665184bbdba8fcbdf0363fa73']`

### SELL `232c37904b5b4badbfba8ec8ec94e059` / 032820
- sell_ts: 2026-03-13T03:39:47+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **622** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1099871604832714
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['4f7b34eab8854252b06ca8d983c0971d']`

### SELL `07992db88e3d445b8329ee11491d935b` / 047040
- sell_ts: 2026-03-13T03:50:57+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **496** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1099807718000805
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['0c5b47f066c24d91842420600241ae9c']`

### SELL `e8068ee702df4b54a08c4c558fdaf9d2` / 032820
- sell_ts: 2026-03-13T04:05:45+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **799** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=047040, top_score=0.5900031756802325
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['ef2066b173f549ebb5a25927a0d43a99']`

### SELL `ba18195f27dc4714bd232a45270c1306` / 032820
- sell_ts: 2026-03-13T04:23:06+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **950** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1109370624292212
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['ebaa63602b774e1ba2cc58e3ff3eb616']`

### SELL `492255d84ae24af28ce47c77c2ae6bc3` / 032820
- sell_ts: 2026-03-13T04:30:52+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **365** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1097348166506813
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['804cd3d25f6f4f8e91215d1d8d70cdf9']`

### SELL `19f59c5a218e4ff997fd6658ef6e1d3a` / 032820
- sell_ts: 2026-03-13T04:47:37+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **907** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1097116287727686
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['97d850a56c6b4b398eee4bd07d90e590']`

### SELL `a866121427ed4f5790cb46c863616238` / 032820
- sell_ts: 2026-03-13T05:04:04+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **902** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=0.9916028488003779
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['ccf18d1bad5a4ad2afe3481e66bf6765']`

### SELL `a935927e1bc8418aa4dfad2cae198bfe` / 032820
- sell_ts: 2026-03-13T05:21:23+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **946** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.215920232109234
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['981a6460918548b18f61bb956f31a6e7']`

### SELL `6e27f72d0e8d4e3e8babf727be87ff34` / 032820
- sell_ts: 2026-03-13T05:39:10+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **718** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=0.99568584217026
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=stop_loss, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['a061a807f963400bb01844314948c19a']`

## Data Gaps

- scanner_score_breakdown_missing_total: 60
- news_items_missing_total: 177
- note: news headline text and scanner score_breakdown are limited by current event-log payload policy.
