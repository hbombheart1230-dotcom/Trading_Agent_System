# Incident Timeline Reconstruction (2026-03-14)

- ok: **True**
- events: **9**
- runs: **3**
- incident_total: **3**
- recovered_incident_total: **3**
- unresolved_incident_total: **0**

## Trigger Totals

- commander_router:error:RuntimeError: 1
- commander_router:resilience:cooldown_active: 1
- commander_router:transition:incident_threshold_cooldown: 1

## Recovery Totals

- commander_router:end:ok: 1
- commander_router:intervention: 2

## Time To Recovery (sec)

- count: 3
- avg: 23.333
- p50: 20.000
- p95: 30.000
- max: 30.000

## Failures

- (none)
