# M30 Post-go-live Monitoring Policy (2026-03-07)

- ok: **True**
- release_ready: **True**
- escalation_level: **normal**

## Sign-off Snapshot

- signoff_rc: 0
- signoff_ok: True
- required_fail_total: 0
- quality_gates_ok: True

## Active Policy

- heartbeat_sec: 300
- alert_fail_on: critical
- oncall_escalation: none
- execution_mode: normal
- manual_approval_only: False
- route_provider: slack_webhook

## Monitoring Targets

- strategist_llm.success_rate >= 99%
- strategist_llm.circuit_open_rate <= 1%
- execution.intents_blocked ratio baseline drift <= 10%
- broker_api.api_429_rate <= 2%
- incident_time_to_recovery_sec p95 <= 900

## Failures

- (none)
