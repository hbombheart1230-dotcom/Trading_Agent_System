# M31 Mock Session Monitoring Checkpoint

- Date (KST): 2026-03-03
- Checkpoint time (KST): 11:35
- Session window: 09:00-15:30
- Runtime profile: staging
- Kiwoom mode: mock
- Approval mode: manual

## 1) Pre-open / Session Gate Status

- `run_m31_mock_investor_exam_check.py --strict-session --json`: `ok=true`
  - `now_kst=2026-03-03T11:28:58+09:00`
  - `market_open_now=true`
- `run_m31_slo_incident_review_check.py --json`: `ok=true`
  - availability `1.0`, error_rate `0.0`
- `run_m31_agent_chain_probe.py --json`: `ok=true`
  - integrated chain path verified
- `smoke_m20_llm.py --provider openai --require-openai --show-llm-event`
  - strategist selected: `OpenAIStrategist`
  - latest smoke intent: `NOOP(model_no_signal)`

## 2) Intraday LLM Metrics (last 20 strategist events)

- total: `20`
- ok: `12`
- success_ratio: `0.600`
- avg_latency_ms: `4631.6`
- strategist_error_total: `4`
- model_no_signal_total: `7`
- action mix:
  - BUY: `6`
  - SELL: `0`
  - NOOP: `14`
- circuit_open_total: `4`

## 3) Decision / Execution Flow Snapshot

- decision action mix (last 20):
  - BUY: `11`
  - SELL: `0`
  - NOOP: `9`
- execution flow health:
  - recent execute run_id coverage: `3`
  - missing_end_run_total: `0`
  - error_run_total: `0`
  - status: `OK`

## 4) Immediate Improvement Actions (during session)

1. Reduce `model_no_signal` ratio:
   - verify live snapshot quality (`price/cash/open_positions`) in decision trace.
   - check whether too many ticks have weak features (currently many NOOP decisions).
2. Stabilize strategist errors:
   - monitor `circuit_open_total`; if it increases, reduce model load or tighten retry budget.
3. Maintain safe mode:
   - keep manual approval and current guardrails unchanged during today session.

## 5) End-of-day TODO

Run at close:

```powershell
python scripts/run_m29_closeout_check.py --json
python scripts/run_m31_slo_incident_review_check.py --json
```

Then update:

- Total intents: `TBD`
- Approved intents: `TBD`
- Executed intents: `TBD`
- Blocked intents: `TBD`
- Error total: `TBD`
- Duplicate execution incidents: `TBD`
