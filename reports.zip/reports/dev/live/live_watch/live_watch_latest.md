# Live Session Watch (2026-03-10T13:52:45+09:00)

- status: **GREEN**
- loop_alive: **True** (pid=24068)
- event_lag_sec: **14**
- summary_rc: **1**

## Metrics

- window_total: **99**
- decision action_counts: `{"SELL": 2, "NOOP": 21, "BUY": 1}`
- llm_error_rate: **0.00%**
- blocked_rate: **87.50%**
- executed_broker_fail_total: **0**

## Reasons

- none

## Recommended Actions

- none

## Artifacts

- summary_report_json_path: `C:\Trading_Agent_System\reports\live_summary\live_summary_20260310_045246.json`
- summary_report_md_path: `C:\Trading_Agent_System\reports\live_summary\live_summary_20260310_045246.md`
- watch_jsonl_path: `C:\Trading_Agent_System\reports\live_watch\live_watch_2026-03-10.jsonl`