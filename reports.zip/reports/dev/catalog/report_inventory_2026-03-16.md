# Report Inventory

- generated_at_utc: `2026-03-16T07:44:42.850519+00:00`
- report_root: `C:\Trading_Agent_System\reports`
- top_level_entry_total: **12**
- archive_candidate_total: **0**
- warning_total: **0**

## Canonical Directories

- `reports/daily`
- `reports/metrics`
- `reports/operator_summary`
- `reports/decision_story`
- `reports/run_cards`
- `reports/reconciliation`
- `reports/dev`
- `reports/milestones`

## Archive Candidates

- none

## Warnings

- none

## Top Level Snapshot

- `archive` (dir, files=2, archive_candidate=False)
- `daily` (dir, files=18, archive_candidate=False)
- `decision_story` (dir, files=8, archive_candidate=False)
- `dev` (dir, files=209, archive_candidate=False)
- `m31_slo_incident` (dir, files=2, archive_candidate=False)
- `metrics` (dir, files=20, archive_candidate=False)
- `milestones` (dir, files=121, archive_candidate=False)
- `operator_summary` (dir, files=16, archive_candidate=False)
- `orchestration` (dir, files=0, archive_candidate=False)
- `reconciliation` (dir, files=4, archive_candidate=False)
- `run_cards` (dir, files=8, archive_candidate=False)
- `trade_explain` (dir, files=4, archive_candidate=False)
