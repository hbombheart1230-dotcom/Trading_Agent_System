# Report Inventory

- generated_at_utc: `2026-03-13T07:49:52.167688+00:00`
- report_root: `C:\Trading_Agent_System\reports`
- top_level_entry_total: **8**
- archive_candidate_total: **0**
- warning_total: **0**

## Canonical Directories

- `reports/daily`
- `reports/metrics`
- `reports/operator_summary`
- `reports/decision_story`
- `reports/run_cards`
- `reports/reconciliation`
- `reports/dev`
- `reports/milestones`

## Archive Candidates

- none

## Warnings

- none

## Top Level Snapshot

- `daily` (dir, files=16, archive_candidate=False)
- `decision_story` (dir, files=7, archive_candidate=False)
- `dev` (dir, files=87, archive_candidate=False)
- `metrics` (dir, files=18, archive_candidate=False)
- `milestones` (dir, files=111, archive_candidate=False)
- `operator_summary` (dir, files=14, archive_candidate=False)
- `reconciliation` (dir, files=2, archive_candidate=False)
- `run_cards` (dir, files=7, archive_candidate=False)
