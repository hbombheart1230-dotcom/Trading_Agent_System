# Decision Story Report (2026-03-09)

- story_total: **378**
- rendered_story_total: **120**
- note: output truncated to first 120 runs

## Run 7dc46c32464a45789f4e85a8ec3d5554

- run_id: `7dc46c32464a45789f4e85a8ec3d5554`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.0, ma20_gap=-0.6083916083916083, volatility20=0.1481682461261132, rsi14=29.367088607594937, composite_score=-0.05603278198295807
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06032781982958071
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run fcfa05b14f834da1891b5494bf3c3171

- run_id: `fcfa05b14f834da1891b5494bf3c3171`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.0, ma20_gap=-0.5972266175666734, volatility20=0.14807418672515651, rsi14=25.9946949602122, composite_score=-0.05603278198295807
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06032781982958071
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run db6d0d75ab1b4a24a14dc32a0bb82890

- run_id: `db6d0d75ab1b4a24a14dc32a0bb82890`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.0, ma20_gap=-0.586606035551881, volatility20=0.14796078736691243, rsi14=25.13416815742397, composite_score=-0.05603278198295807
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06032781982958071
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run cf7974ed36f04b5bb560c667f24150b2

- run_id: `cf7974ed36f04b5bb560c667f24150b2`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.2, ma20_gap=-0.5755003032140691, volatility20=0.14798963457413183, rsi14=22.067039106145245, composite_score=0.04396721801704193
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06032781982958071
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 4ec2644c8c8f4220a46fada93467b5a7

- run_id: `4ec2644c8c8f4220a46fada93467b5a7`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.2, ma20_gap=-0.5627186406796602, volatility20=0.1472010002878972, rsi14=22.030740568234748, composite_score=0.04396721801704193
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06032781982958071
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 654295368c0f46a887501e992e075ce1

- run_id: `654295368c0f46a887501e992e075ce1`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.2, ma20_gap=-0.5492304720200915, volatility20=0.1472280430915189, rsi14=20.963172804532576, composite_score=0.043955641722743036
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06044358277256965
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run d03e5dbef36b4b12bbc8472ae87ec2cc

- run_id: `d03e5dbef36b4b12bbc8472ae87ec2cc`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.2, ma20_gap=-0.5345744680851063, volatility20=0.14710457073400612, rsi14=18.26171875, composite_score=0.043955641722743036
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06044358277256965
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 54474c7d880b4af1ac1891404412e71c

- run_id: `54474c7d880b4af1ac1891404412e71c`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.2, ma20_gap=-0.5171414775470787, volatility20=0.1458260738183128, rsi14=16.840536512667654, composite_score=0.043955641722743036
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06044358277256965
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 355d67942afa4db3950e06954f1ce4e7

- run_id: `355d67942afa4db3950e06954f1ce4e7`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.2, ma20_gap=-0.4978839394591493, volatility20=0.1456499761130665, rsi14=10.385438972162746, composite_score=0.043955641722743036
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06044358277256965
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run cb036eefc14144d1aed1432bb431b39a

- run_id: `cb036eefc14144d1aed1432bb431b39a`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.2, ma20_gap=-0.4753017015216251, volatility20=0.1447495739581204, rsi14=10.469508904479213, composite_score=0.043955641722743036
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06044358277256965
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 993fa7e76a9a4951b922086b9ec8bf87

- run_id: `993fa7e76a9a4951b922086b9ec8bf87`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.2, ma20_gap=-0.4505710136964798, volatility20=0.14474392920878035, rsi14=11.836485661989016, composite_score=0.04395513874315853
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.0604486125684147
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 653b0c328d364e9f938c933edc1cb67d

- run_id: `653b0c328d364e9f938c933edc1cb67d`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=0.2, ma20_gap=-0.4227042183827471, volatility20=0.14453928246288536, rsi14=13.758865248226954, composite_score=0.04395513874315853
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.0604486125684147
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 96be87a7bb7c441297aa095810d379d6

- run_id: `96be87a7bb7c441297aa095810d379d6`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.39000479281948497, volatility20=0.14390299495720887, rsi14=0.0, composite_score=-0.30604486125684144
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.0604486125684147
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run d1135e247a4e4b02808702dc51016c7d

- run_id: `d1135e247a4e4b02808702dc51016c7d`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.5, ma20_gap=-0.3523316062176166, volatility20=0.14364396437571253, rsi14=0.0, composite_score=-0.30604486125684144
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.0604486125684147
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 9f8e499878344b9bb7daa90a8be77ef0

- run_id: `9f8e499878344b9bb7daa90a8be77ef0`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=-0.3047278506158124, volatility20=0.14185558841806706, rsi14=100.0, composite_score=-0.1560448612568415
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.0604486125684147
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 4a1bddbf2525483c96eb7f6b07e3980e

- run_id: `4a1bddbf2525483c96eb7f6b07e3980e`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=-0.25017406673450804, volatility20=0.14193850745584746, rsi14=100.0, composite_score=-0.1560509008274136
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06050900827413582
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 047c9903c7eb453bba8e70d29e2804e7

- run_id: `047c9903c7eb453bba8e70d29e2804e7`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=-0.19632606199770375, volatility20=0.14143531720973163, rsi14=100.0, composite_score=-0.14531611322695434
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06050900827413582
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run b412c0394c4d4acabb9f0b5084f0a371

- run_id: `b412c0394c4d4acabb9f0b5084f0a371`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=-0.14623734601780702, volatility20=0.14022277887273563, rsi14=100.0, composite_score=-0.135298370030975
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06050900827413582
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run a8cb5a6687a14db4931a11d6a6b411c6

- run_id: `a8cb5a6687a14db4931a11d6a6b411c6`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=-0.0778553550256883, volatility20=0.13673247373475597, rsi14=100.0, composite_score=-0.12162197183255125
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06050900827413582
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run d279573d3d064998a0848610aa1ea963

- run_id: `d279573d3d064998a0848610aa1ea963`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.13688147054370553, rsi14=100.0, composite_score=-0.10605090082741359
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06050900827413582
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 538806894082496d91561858a36e0e55

- run_id: `538806894082496d91561858a36e0e55`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.10603731269128261
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06037312691282607
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 5efecdb3d86448199e380804e0ffad4c

- run_id: `5efecdb3d86448199e380804e0ffad4c`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.10603731269128261
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06037312691282607
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 53ad1bad674d4751b0893f6d20ecfbd3

- run_id: `53ad1bad674d4751b0893f6d20ecfbd3`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.10603731269128261
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06037312691282607
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 6a20f5d28d434373a853bf7b4dd2f781

- run_id: `6a20f5d28d434373a853bf7b4dd2f781`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.10603731269128261
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06037312691282607
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 078ec0c983d04500a735d6876a57906f

- run_id: `078ec0c983d04500a735d6876a57906f`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.10603731269128261
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.06037312691282607
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 8a980f77813a42018a02cd389688c749

- run_id: `8a980f77813a42018a02cd389688c749`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.10605694035368078
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.0605694035368077
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 4589ecb0900e4afeab142d9eaa44d9a6

- run_id: `4589ecb0900e4afeab142d9eaa44d9a6`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.10605694035368078
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.0605694035368077
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run b1d6e9c219144812b587ee280e455312

- run_id: `b1d6e9c219144812b587ee280e455312`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.10605694035368078
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.0605694035368077
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 2ed4b9fa42364a7d9961d75b4b6ba5f3

- run_id: `2ed4b9fa42364a7d9961d75b4b6ba5f3`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.10605694035368078
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.0605694035368077
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run c8161b73def04218ab71504dc455f99e

- run_id: `c8161b73def04218ab71504dc455f99e`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.10605694035368078
- sentiment_evidence: symbol_sentiment_score=0.0, global_sentiment_score=-0.0605694035368077
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 28047da9dd4e4b86b3a2862b98ddb091

- run_id: `28047da9dd4e4b86b3a2862b98ddb091`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.12606146708968455
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06061467089684525
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 15f8e2830914402383759b399674c962

- run_id: `15f8e2830914402383759b399674c962`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.12606146708968455
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06061467089684525
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run b33fdb55b70449a382b5f436aad03248

- run_id: `b33fdb55b70449a382b5f436aad03248`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.12606146708968455
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06061467089684525
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run e0222c8c943445feaad1745ea196b820

- run_id: `e0222c8c943445feaad1745ea196b820`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.12606146708968455
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06061467089684525
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run ee5ed99d3183481696de5cc14ac2522e

- run_id: `ee5ed99d3183481696de5cc14ac2522e`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.12606146708968455
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06061467089684525
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 946dee08f23a41cea1050c7caf6fb677

- run_id: `946dee08f23a41cea1050c7caf6fb677`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.12605744332557856
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06057443325578534
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 1afddde1945940ecb9734473dfe23812

- run_id: `1afddde1945940ecb9734473dfe23812`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.12605744332557856
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06057443325578534
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 69d60eec41aa47288dc60cb0a785faf4

- run_id: `69d60eec41aa47288dc60cb0a785faf4`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.12605744332557856
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06057443325578534
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run f98a2d86df4d4a449a46208c70ec0682

- run_id: `f98a2d86df4d4a449a46208c70ec0682`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.12605744332557856
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06057443325578534
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 9974976f7c98406f8f2c78987b6e40e3

- run_id: `9974976f7c98406f8f2c78987b6e40e3`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.12605744332557856
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06057443325578534
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run b704c76b1d214514b67f29a5668c5861

- run_id: `b704c76b1d214514b67f29a5668c5861`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260509008274136
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06050900827413582
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 97062519fad64411a23ca8cad5975bd2

- run_id: `97062519fad64411a23ca8cad5975bd2`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260509008274136
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06050900827413582
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 217a5e37f6ab4c9a93d64c68b0149977

- run_id: `217a5e37f6ab4c9a93d64c68b0149977`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260509008274136
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06050900827413582
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 35376bccf9154addb7674e8aaa4e0bc7

- run_id: `35376bccf9154addb7674e8aaa4e0bc7`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260509008274136
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06050900827413582
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 9c11d7203ff94ee5884e6504bbd0cde2

- run_id: `9c11d7203ff94ee5884e6504bbd0cde2`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260509008274136
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06050900827413582
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run d9168c8319ca4d0a846d1770006ec9a0

- run_id: `d9168c8319ca4d0a846d1770006ec9a0`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260222153530869
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06022215353086913
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 6de69b8d16c44e55b58469b33efa15cd

- run_id: `6de69b8d16c44e55b58469b33efa15cd`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260222153530869
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06022215353086913
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run e5c94d30becd422eb02ee7518ef2faa9

- run_id: `e5c94d30becd422eb02ee7518ef2faa9`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260222153530869
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06022215353086913
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run b15c25b2ea4c4ab69ec78541aafbb8f0

- run_id: `b15c25b2ea4c4ab69ec78541aafbb8f0`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260222153530869
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06022215353086913
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run f1546e27b2bb41999b0d6fab6542978d

- run_id: `f1546e27b2bb41999b0d6fab6542978d`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260222153530869
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06022215353086913
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 7eab942eeb184ea4967b4f1af92a13fb

- run_id: `7eab942eeb184ea4967b4f1af92a13fb`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260342909419669
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.0603429094196688
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 3749a64192ff49dc885518959b7275e9

- run_id: `3749a64192ff49dc885518959b7275e9`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260342909419669
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.0603429094196688
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run e5e05ddd781f4ffbb6b72aefe0a6b54c

- run_id: `e5e05ddd781f4ffbb6b72aefe0a6b54c`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260342909419669
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.0603429094196688
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 8f8578f87d1540939e319b2c0b18686a

- run_id: `8f8578f87d1540939e319b2c0b18686a`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260342909419669
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.0603429094196688
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 66a7cd45d1c24982904498598e465a6d

- run_id: `66a7cd45d1c24982904498598e465a6d`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260342909419669
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.0603429094196688
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 17f47a8d2031472da3a0d6bde4d0d356

- run_id: `17f47a8d2031472da3a0d6bde4d0d356`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14606599764019432
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06065997640194303
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run c1a9f70cad5545e9bf097eb9f46b21fc

- run_id: `c1a9f70cad5545e9bf097eb9f46b21fc`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14606599764019432
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06065997640194303
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 2424889caff1481a9d41d3d6b783c84b

- run_id: `2424889caff1481a9d41d3d6b783c84b`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14606599764019432
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06065997640194303
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run aa1da11f12304581af619ba1f2c5e01a

- run_id: `aa1da11f12304581af619ba1f2c5e01a`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14606599764019432
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06065997640194303
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 8c51f7273c2a489ba7becb3917c7d7ee

- run_id: `8c51f7273c2a489ba7becb3917c7d7ee`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14606599764019432
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06065997640194303
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 921fd304e687474b9361ab875888e7fa

- run_id: `921fd304e687474b9361ab875888e7fa`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14606046115050442
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06060461150504417
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run b3ab5617e2f54101b812abcd55bd0ec6

- run_id: `b3ab5617e2f54101b812abcd55bd0ec6`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14606046115050442
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06060461150504417
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run fd24eb8ec006436b8d8d49e59498d4c1

- run_id: `fd24eb8ec006436b8d8d49e59498d4c1`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14606046115050442
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06060461150504417
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run af9633ed33e3482d9ecf9ae66d6e004a

- run_id: `af9633ed33e3482d9ecf9ae66d6e004a`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14606046115050442
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06060461150504417
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run b73b496fc67648819fe79ef9535c7691

- run_id: `b73b496fc67648819fe79ef9535c7691`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14606046115050442
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06060461150504417
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 719d46c35f1049ab9b282eb856c532bc

- run_id: `719d46c35f1049ab9b282eb856c532bc`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14608260304581777
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.0608260304581776
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run dfa2238e068d4bf08453aec092238e37

- run_id: `dfa2238e068d4bf08453aec092238e37`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14608260304581777
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.0608260304581776
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 07e745d047e842289e12d30873feee07

- run_id: `07e745d047e842289e12d30873feee07`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14608260304581777
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.0608260304581776
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run f9c5986fc3764a8597cdde7cf8f5efc0

- run_id: `f9c5986fc3764a8597cdde7cf8f5efc0`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14608260304581777
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.0608260304581776
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run c8f1307b13a84551a49ce72da9c0801d

- run_id: `c8f1307b13a84551a49ce72da9c0801d`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14608260304581777
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.0608260304581776
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 0f353ce0acf143eea2a39e4e92919c1e

- run_id: `0f353ce0acf143eea2a39e4e92919c1e`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460951845359465
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06095184535946478
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run b723b2947b354d09acfbf21a45af2e4f

- run_id: `b723b2947b354d09acfbf21a45af2e4f`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460951845359465
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06095184535946478
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 9ae285011b1a42fca54988a28ee32872

- run_id: `9ae285011b1a42fca54988a28ee32872`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460951845359465
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06095184535946478
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 23d7180585d44351a369dfd13f68514a

- run_id: `23d7180585d44351a369dfd13f68514a`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460951845359465
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06095184535946478
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run d50e5fe9145c4790b993ee1df8c02a55

- run_id: `d50e5fe9145c4790b993ee1df8c02a55`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460951845359465
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06095184535946478
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 28dcc9a8b7ca4d1ebd9167dd65b922f7

- run_id: `28dcc9a8b7ca4d1ebd9167dd65b922f7`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460866305258707
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06086630525870698
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run b3d5413b7eb74d37bd68d0c3ca373bb5

- run_id: `b3d5413b7eb74d37bd68d0c3ca373bb5`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460866305258707
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06086630525870698
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 0d47f20b6855466f94e33a14ef96a482

- run_id: `0d47f20b6855466f94e33a14ef96a482`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460866305258707
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06086630525870698
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 46c7157ff138442d8f5abf4b84c129a9

- run_id: `46c7157ff138442d8f5abf4b84c129a9`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460866305258707
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06086630525870698
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run d776f048229a4e6cad8fa86d11f62c3d

- run_id: `d776f048229a4e6cad8fa86d11f62c3d`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460866305258707
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06086630525870698
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 6e1aed0878864f1ea687cee46b923fdb

- run_id: `6e1aed0878864f1ea687cee46b923fdb`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460916638882351
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.060916638882350806
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 5de524caceef4d109421a76a9edaa38c

- run_id: `5de524caceef4d109421a76a9edaa38c`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460916638882351
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.060916638882350806
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 487dd5461f8944a6a36d0f970e09625f

- run_id: `487dd5461f8944a6a36d0f970e09625f`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460916638882351
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.060916638882350806
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 2c3b6003ba0d4eefbd24320ad588ed41

- run_id: `2c3b6003ba0d4eefbd24320ad588ed41`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460916638882351
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.060916638882350806
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run ba58db1211af4064b29e5a8bcd43a9e1

- run_id: `ba58db1211af4064b29e5a8bcd43a9e1`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460916638882351
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.060916638882350806
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 73b1bffc28304829bf038b70c557e61b

- run_id: `73b1bffc28304829bf038b70c557e61b`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1461057540665538
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06105754066553788
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 5b90dbba2e104d39a11288d1e0d8d195

- run_id: `5b90dbba2e104d39a11288d1e0d8d195`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1461057540665538
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06105754066553788
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 13cc8505c0ea4977ba653dac9d248772

- run_id: `13cc8505c0ea4977ba653dac9d248772`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1461057540665538
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06105754066553788
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 7435bef0f40548068c79daeab30fa33c

- run_id: `7435bef0f40548068c79daeab30fa33c`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1461057540665538
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06105754066553788
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 3302f37511d84c5ea1931122b796313e

- run_id: `3302f37511d84c5ea1931122b796313e`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1461057540665538
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06105754066553788
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 56b417d7126d403cb272b2129c327a58

- run_id: `56b417d7126d403cb272b2129c327a58`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14610675995009337
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06106759950093351
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run a7f4d9d62e9642eda1310b29406b3412

- run_id: `a7f4d9d62e9642eda1310b29406b3412`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14610675995009337
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06106759950093351
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 57d8b874e9c14f7196010573a60bf0bd

- run_id: `57d8b874e9c14f7196010573a60bf0bd`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14610675995009337
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06106759950093351
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run afe7291728fb418dbfe1368394eb47e4

- run_id: `afe7291728fb418dbfe1368394eb47e4`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14610675995009337
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06106759950093351
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run e6714edc8868443f924712e52fd1e111

- run_id: `e6714edc8868443f924712e52fd1e111`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14610675995009337
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06106759950093351
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 9b4b73e50bc84b4094c7948bcf307073

- run_id: `9b4b73e50bc84b4094c7948bcf307073`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460936756887839
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06093675688783889
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run ee1433c2a63e4c6183ebac1a6bb1617d

- run_id: `ee1433c2a63e4c6183ebac1a6bb1617d`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460936756887839
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06093675688783889
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 0fb69f4dea2046e09e39402467515179

- run_id: `0fb69f4dea2046e09e39402467515179`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460936756887839
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06093675688783889
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 7faa0d86d7084589826fcd9b0bb26922

- run_id: `7faa0d86d7084589826fcd9b0bb26922`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460936756887839
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06093675688783889
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 4179124e91ab473e8e9c46dc826c58a1

- run_id: `4179124e91ab473e8e9c46dc826c58a1`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1460936756887839
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06093675688783889
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 9c3c3ae7f5ad46c59c1097fb1af1d43d

- run_id: `9c3c3ae7f5ad46c59c1097fb1af1d43d`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260775734671319
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.060775734671318686
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 7101e8d617654be8a965106915cbf6ff

- run_id: `7101e8d617654be8a965106915cbf6ff`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260775734671319
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.060775734671318686
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 84535bb0b1d442b7b629912869cc0dd5

- run_id: `84535bb0b1d442b7b629912869cc0dd5`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260775734671319
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.060775734671318686
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run de4b9d9fa9d14e899670858397597c90

- run_id: `de4b9d9fa9d14e899670858397597c90`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260775734671319
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.060775734671318686
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 40692fb181d54ca895266edffd5f7b26

- run_id: `40692fb181d54ca895266edffd5f7b26`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260775734671319
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.060775734671318686
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run fc88e237e86543cb95b0b0a99b356153

- run_id: `fc88e237e86543cb95b0b0a99b356153`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260579462971687
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06057946297168698
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 6c9e53b0a541419fbd7441691b3a3fb6

- run_id: `6c9e53b0a541419fbd7441691b3a3fb6`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260579462971687
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06057946297168698
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 0ee71a54cd1849f4b4ccce21527597c3

- run_id: `0ee71a54cd1849f4b4ccce21527597c3`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260579462971687
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06057946297168698
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 52a0c784cf4c4b2d9a01d14af218fb1e

- run_id: `52a0c784cf4c4b2d9a01d14af218fb1e`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260579462971687
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06057946297168698
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run b9e4f95bfc8e401fad70699fea20c9fd

- run_id: `b9e4f95bfc8e401fad70699fea20c9fd`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260579462971687
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.06057946297168698
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 78b4b4e3114545e9a29a296497c3743d

- run_id: `78b4b4e3114545e9a29a296497c3743d`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260775734671319
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.060775734671318686
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run b120a7ae3ce24b83bc9620bbd11b3d1f

- run_id: `b120a7ae3ce24b83bc9620bbd11b3d1f`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260775734671319
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.060775734671318686
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 93ed5073968042f9af0bedad0dca4809

- run_id: `93ed5073968042f9af0bedad0dca4809`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260775734671319
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.060775734671318686
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 698198a8b27d4650a5b552b9a21d941b

- run_id: `698198a8b27d4650a5b552b9a21d941b`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260775734671319
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.060775734671318686
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run a2173cc1984d4cceb07811f602e4ade6

- run_id: `a2173cc1984d4cceb07811f602e4ade6`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.1260775734671319
- sentiment_evidence: symbol_sentiment_score=-0.1, global_sentiment_score=-0.060775734671318686
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run d41173cab7da4663bab2d821ae857513

- run_id: `d41173cab7da4663bab2d821ae857513`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14607908234397937
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06079082343979366
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 7917dd7123ef43df97eebc34c21cb46b

- run_id: `7917dd7123ef43df97eebc34c21cb46b`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14607908234397937
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06079082343979366
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 7804848727c34148b750055dd0c92761

- run_id: `7804848727c34148b750055dd0c92761`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14607908234397937
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06079082343979366
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 30b0fc039aed423c8cf426b677978a78

- run_id: `30b0fc039aed423c8cf426b677978a78`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14607908234397937
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06079082343979366
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 844f26a641594973aeca1ddb16779c02

- run_id: `844f26a641594973aeca1ddb16779c02`
- symbol: **005930**
- final_action: **NOOP**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: signal_score=-0.2, ma20_gap=0.0, volatility20=0.0, rsi14=100.0, composite_score=-0.14607908234397937
- sentiment_evidence: symbol_sentiment_score=-0.2, global_sentiment_score=-0.06079082343979366
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped
