# Operator Daily Summary (2026-03-13)

## Executive Summary

- system_status: **[YELLOW]**
- [YELLOW] runs=527, executions=185 (ok=125, fail=8), blocks=134.
- Top guard block: NOOP intent skipped (no order sent) (110)
- LLM success_rate=79.54%, interventions=4, cooldowns=4.

## Top Issues

- [YELLOW] excessive_blocked_orders: blocked_rate=304.55% (134/44)

## Recommended Operator Actions

- Review allowlist, notional limits, and decision thresholds causing frequent guard blocks.

## System Health Status

- system_health_level: **[YELLOW]**
- reasoning:
  - blocked_rate=304.55% (134/44)
- recommended_action:
  - Review allowlist, notional limits, and decision thresholds causing frequent guard blocks.

## Trading Activity Summary

- run_total: **527**
- decision_action_counts: `{"BUY": 28, "NOOP": 44, "SELL": 16}`
- strategy_counts: `{"pullback": 215, "defensive": 15, "RuleStrategist": 16, "OpenAIStrategist": 44, "AlwaysBuyStrategist": 4, "ExitPolicyStrategist": 16, "CooldownStrategist": 4, "EODLiquidationStrategist": 4, "reversal": 1}`
- executions_total: **185**
- blocked_total: **134**
- noop_reason_top_human: NO_CANDIDATE (no candidate met entry conditions) (36); GUARD_BLOCK (blocked by safety guard) (4)
- fallback_signal_status_top_human: global_sentiment_status:fallback (80); symbol_sentiment_status:fallback (76); symbol_sentiment_status:unavailable (4)

## Safety Guard Interventions

- blocked_total: **134**
- blocked_reason_top_human: NOOP intent skipped (no order sent) (110); Blocked by supervisor test rule (8); Blocked duplicate buy (position already open) (8); Insufficient mock cash (8)
- operator_intervention_total: **4**
- cooldown_transition_total: **4**
- duplicate_execution_total: **0**
- guard_precedence_violation_total: **0**
