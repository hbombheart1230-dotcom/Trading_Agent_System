# Report Inventory

- generated_at_utc: `2026-03-14T08:23:04.551586+00:00`
- report_root: `C:\Trading_Agent_System\reports\dev\exam\mock_exam_day_check`
- top_level_entry_total: **8**
- archive_candidate_total: **0**
- warning_total: **0**

## Canonical Directories

- `reports/metrics`
- `reports/operator_summary`
- `reports/decision_story`
- `reports/run_cards`
- `reports/dev`

## Archive Candidates

- none

## Warnings

- none

## Top Level Snapshot

- `decision_story` (dir, files=1, archive_candidate=False)
- `dev` (dir, files=4, archive_candidate=False)
- `m31_mock_exam_readiness` (dir, files=2, archive_candidate=False)
- `m31_slo_incident` (dir, files=2, archive_candidate=False)
- `metrics` (dir, files=2, archive_candidate=False)
- `operator_summary` (dir, files=2, archive_candidate=False)
- `orchestration` (dir, files=6, archive_candidate=False)
- `run_cards` (dir, files=1, archive_candidate=False)
