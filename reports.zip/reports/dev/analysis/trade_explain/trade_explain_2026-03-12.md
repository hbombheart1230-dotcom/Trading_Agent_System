# Trade Explain Report (2026-03-12)

- event_log_path: `data\logs\events.jsonl`
- executions_total: **196**
- sell_pairs_total: **80**

## Executive Summary

- symbols_executed: `['005930', '006910', '024060', '032820', '046120', '051910', '095910', '307870', '357880', '380540']`
- action_counts: `{'BUY': 116, 'SELL': 80}`
- symbol_side_counts: `{'024060:BUY': 2, '032820:BUY': 70, '006910:BUY': 2, '380540:BUY': 13, '307870:BUY': 1, '357880:BUY': 9, '005930:SELL': 6, '032820:SELL': 54, '005930:BUY': 14, '006910:SELL': 1, '024060:SELL': 1, '051910:SELL': 1, '357880:SELL': 1, '380540:SELL': 11, '046120:BUY': 1, '046120:SELL': 1, '095910:BUY': 4, '095910:SELL': 4}`
- short_holds_lt_120s: **62**

## Agent Activity Snapshot

- `commander_router`: 592
- `strategist_llm`: 237
- `strategist`: 252
- `decision_trace`: 1251
- `scanner`: 268
- `monitor`: 494
- `execute_from_packet`: 990
- `decision`: 28
- `skill_execute`: 1
- `skill_result`: 1
- `skill_hydration`: 12

## Report Inventory

- `reports\live_watch\live_watch_latest.md`

## Execution Timeline (Latest)

| ts | run_id | symbol | action | qty | price | strategy | reason |
| --- | --- | --- | --- | ---: | ---: | --- | --- |
| 2026-03-12T00:00:36+00:00 | `75c3739b0d1a4f7cb5cc97910e99209c` | 024060 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:01:56+00:00 | `4ecc4f6b97254c69a58207d23fe430ab` | 024060 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:04:42+00:00 | `cfedf8f1a65d49d4809249695154bc18` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:06:24+00:00 | `40f6e2e3aab04942913632725de79ee8` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:07:29+00:00 | `4b0e90a60eff42f88e2c6ca53e0ea264` | 006910 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:08:34+00:00 | `d00cca0f269643eb8c1a97f6ecb30b1e` | 006910 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:11:37+00:00 | `b15496873e274707955dccf2c02f7bdc` | 380540 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:12:50+00:00 | `daf656d3405c4cf0a59e230a8e1f4f25` | 380540 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:13:55+00:00 | `a9cb0ebaacd64e8d92b9312b68dd23e3` | 307870 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:15:08+00:00 | `685be82701b9464196eb0aa6f6a68efa` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:16:19+00:00 | `4302ce0ee7a84193b8c6e73e533c50fd` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:17:32+00:00 | `1c60c02fe381441f90d4dd709d7575c6` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:19:01+00:00 | `897f80af557747929398653b10dc5fe8` | 380540 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:20:32+00:00 | `347c3d096f504b73ae6c01b5b61899dd` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:21:43+00:00 | `1d1bd8b216f4497aaa8d364001d9c2e8` | 357880 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:22:58+00:00 | `4bdcaca2a1ac4f68a8a36dd80d54cf1f` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:24:11+00:00 | `2161cccd31b641a5a7cebcc05e2c3fa3` | 357880 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:25:21+00:00 | `ef7f0ed7944a4fe4856528001f3a52ae` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:26:33+00:00 | `a900404075904b60bbae67065a43391e` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:27:53+00:00 | `179c2a35c9a0476daa7146608f4dce3e` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:29:22+00:00 | `0a8df67abc7047d1a21f30a9aac2c0de` | 357880 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:30:31+00:00 | `efafedb80583409aad50ef0a9e16f030` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:31:42+00:00 | `5835be0f79ff42eeb9c70619fbda859b` | 357880 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:33:03+00:00 | `0b5dd9bf60d542d38d13f5910d60721a` | 357880 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:34:14+00:00 | `e59e65f284f648b8a808e679e285938c` | 357880 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:35:24+00:00 | `c7884a8183ed4c1b9c68d3ca538b0540` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:36:34+00:00 | `919425ddd88543269e3c07b569ccb766` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:37:44+00:00 | `78757acd8615460dbb7ff80577598a52` | 357880 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:39:19+00:00 | `e6c7aa046df64470bbdf0546d016eb98` | 357880 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:41:57+00:00 | `bb8919bfb5f7413d96cefd6fae8815b0` | 357880 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:43:07+00:00 | `5bd64f2da6c64d92919f96a46193ffc3` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:44:17+00:00 | `4260abb217fe473e85cf44e501f710e9` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T00:45:23+00:00 | `7ccad0276ed74780a7cbd898f157d050` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T01:19:38+00:00 | `60e74545f2954e9b94a5fd1b6c482432` | 005930 | SELL | 2 | 0.0 | - | - |
| 2026-03-12T01:23:38+00:00 | `96d05655a3e7459c8d94a2613e143ca1` | 005930 | SELL | 2 | 0.0 | - | - |
| 2026-03-12T01:24:51+00:00 | `8abcd31b7b454b73bac4770e501e0610` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T01:36:06+00:00 | `966e416b56054976a3022a1d6d7926c2` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T01:37:22+00:00 | `f33d1e79c3464d3e99b3f2b68387395d` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T01:39:09+00:00 | `fd9d71d98eba4703b949ac773a520e4c` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T01:40:38+00:00 | `11e2fb08ff3340f08b4904a1120aec21` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T01:41:56+00:00 | `0795f8c1bd2f4f9b80720f699771f640` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T01:58:53+00:00 | `b36cc6d1f351441baadb6f0dfe16ed84` | 005930 | SELL | 20 | 70000.0 | - | - |
| 2026-03-12T01:58:53+00:00 | `276a767311874448a24ffb2c42b41471` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-12T01:58:53+00:00 | `161e3f0b11094df2b0ea415e4d115633` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-12T01:58:54+00:00 | `55d4380b861b42b488041a76599e5f48` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-12T01:58:54+00:00 | `7bfd87bf38c5406d80db13fb86900105` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-12T01:58:54+00:00 | `9bacfc9629d94496a79c5fb5c8da9a8b` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-12T01:59:31+00:00 | `1846e0d5d9b84b75a47baf4b49515598` | 032820 | SELL | 16 | 0.0 | - | - |
| 2026-03-12T02:00:47+00:00 | `c3767e3bd8c24cdc8e7f9ff2bd4b6663` | 006910 | SELL | 2 | 0.0 | - | - |
| 2026-03-12T02:02:15+00:00 | `bca1f45a15cf49d69542a75235b5b556` | 024060 | SELL | 2 | 0.0 | - | - |
| 2026-03-12T02:03:37+00:00 | `995f0ebc11fb4e0a9650377d75baeab6` | 051910 | SELL | 324 | 0.0 | - | - |
| 2026-03-12T02:05:46+00:00 | `f1ca5678c36343c38167d4fdc9b7981f` | 357880 | SELL | 9 | 0.0 | - | - |
| 2026-03-12T02:07:03+00:00 | `af94ca714b034a28b4b7aa10cd04dcd0` | 005930 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T02:11:43+00:00 | `5ce388e8e9de4e07b827ed21b0fb184e` | 380540 | SELL | 3 | 0.0 | - | - |
| 2026-03-12T02:14:00+00:00 | `084bfad5f260424c9334eb6cc355475e` | 380540 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T02:15:23+00:00 | `43cb751563644832b064af98dda81c6a` | 380540 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T02:16:48+00:00 | `a62d4ef310de4f8c9955c6db7ee48fa5` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T02:18:41+00:00 | `6a923132c4854676bf9748bad8d41729` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T02:19:49+00:00 | `7b656329d62c46d4955b8f4307c86515` | 046120 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T02:21:17+00:00 | `cba0dafe11324a4486ba5eda62854cdd` | 046120 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T02:23:26+00:00 | `4e492828e1cf45b68349ca6b1f480729` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T02:24:50+00:00 | `39e5db0373f04e4fb2da4a509c70c666` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T02:26:09+00:00 | `684e5ac951164f1cbef78cb20c35d421` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T02:27:57+00:00 | `40e75e7f897d4da29f7d8006421eddb9` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T02:29:05+00:00 | `fe92900464ef4438a6ae0171853271ce` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T02:30:28+00:00 | `55b9325640fe42cfa4ca808a05e67d7b` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T02:32:12+00:00 | `bcd8fffc6a674b008704f3eab0d67bd5` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T02:33:22+00:00 | `trace-r2` | 005930 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T02:33:37+00:00 | `c88427e9935e4bc19c5088bdbe835ba8` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T02:33:46+00:00 | `trace-r2` | 005930 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T02:33:47+00:00 | `eaaecd4e0ffd4f0591f27a6e3d75c9a6` | 005930 | SELL | 20 | 70000.0 | - | - |
| 2026-03-12T02:33:47+00:00 | `77a3090683e641e58156b3dccf817e9a` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-12T02:33:47+00:00 | `465c30c753e940c9841360897712cdd9` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-12T02:33:47+00:00 | `927899ece912403b8157f84a4a1a8206` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-12T02:33:47+00:00 | `4232b75b67504e15b801f72c4a6992b9` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-12T02:33:47+00:00 | `5b6b6c9596974791939e11977ef4f465` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-12T02:34:06+00:00 | `c992b5c73afd485abf7fc649c1c10a6b` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-12T02:34:14+00:00 | `ee260f0703d0462cbc83476e397fd379` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T02:39:03+00:00 | `0e185bfbeecf468088dfd821ab5df369` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T02:39:03+00:00 | `trace-r2` | 005930 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T02:41:26+00:00 | `a4fc50a18762464b9978d55c2065b633` | 005930 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T02:43:45+00:00 | `a42595d091dd482a94b38384c135e785` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T02:44:55+00:00 | `b8d04932945b43f0b83b46fd4b5736ca` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T02:46:11+00:00 | `7c6bac55c2d541de9e55146b50f6b821` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T02:48:33+00:00 | `15438ecdf5104fd5a10616a196c088d8` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T02:49:59+00:00 | `b929d1326116455bbb54135f7663f3d8` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T02:51:22+00:00 | `3c5608206224445a85d36e270986fc4a` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T02:52:43+00:00 | `46fffc53ee0f453793b5a925ec1906dd` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T02:54:02+00:00 | `ef9a7eae8ca04b21b6c8925b483f347d` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T02:56:20+00:00 | `7c0b8b2fcd05472583afe3bf9903707e` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T02:57:42+00:00 | `f73fd2a04486414ca2d269c3165c10d0` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:00:33+00:00 | `83ab963ea0ee4f24a4eb3c4589b16d2a` | 380540 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:03:39+00:00 | `f94ab36e09de4801bc858215a14b8b3a` | 380540 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:04:59+00:00 | `01d3028757484f989d328591a859d964` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:06:25+00:00 | `c7aba95f1c6f4612a1cf4d2dc74ecbc6` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:08:36+00:00 | `2591e17bc1294b71a118eaa83552289d` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:09:59+00:00 | `481fc66532394ab0826867ef93afff72` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:11:24+00:00 | `f3dea97cc5614ecbb82495aa861c24a5` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:12:41+00:00 | `1443a97aa51f435b8696f0d151fbe87e` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:14:00+00:00 | `76cf9d4163b34e399e0a1caa931845be` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:15:28+00:00 | `ea596f9a050242ea806203cab1c75e57` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:16:36+00:00 | `9ed931b2dbce4c83b1a594a37ed951af` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:17:51+00:00 | `1a1c0c99d4bd40e986a776a4fae5a700` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:19:05+00:00 | `9655ef3a9dd542c5b6a4fd00b75a1d55` | 380540 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:21:10+00:00 | `d20fb34914f8460ba37721f702555206` | 380540 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:22:41+00:00 | `97a494e85d8446e890c20cc69d469f77` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:23:51+00:00 | `e26c6ebdf8c34dbe998adce648231b4a` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:25:07+00:00 | `66869abb6e4448f3b2c6f108c5c665b6` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:26:22+00:00 | `9408d7e9b19f402d9d431dd96d9bf887` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:27:33+00:00 | `51bb3293c1534e3a81f1a128ace26cb5` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:28:43+00:00 | `0e44dc190ab14eb49f3c37902eedd139` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:31:32+00:00 | `98e01f533a4f4e358f741176127b1bf7` | 380540 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:32:48+00:00 | `5ef3402000e349ec859a3c8bec97bb01` | 380540 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:34:05+00:00 | `c2e553223b1544d98be49b4f0c118e5e` | 380540 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:35:29+00:00 | `e00b72e36b2a4191bf39c8d51201e291` | 380540 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:36:48+00:00 | `4141499845bf4dcc93f115cb1ff7df69` | 380540 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:38:00+00:00 | `5048d39696dd4fc389cd2e233b326657` | 380540 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:39:25+00:00 | `2dbc5ac379cc4b87943f687ba066b737` | 380540 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:41:32+00:00 | `7fce2f53e1ce4a8cabd0eef46e08a7a3` | 380540 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:43:39+00:00 | `18c56d785c61414fa28d8c633e30e4c3` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:44:57+00:00 | `28559633a3fa4e8495cea07ffed11775` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:46:27+00:00 | `0d7cd5545505439fa4397863755f3a74` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:48:14+00:00 | `d3c44f4a53a7478a8c2f5f4e99c80dc3` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:49:35+00:00 | `52fcff392cc54a06b1c6603fd6e4e232` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:50:50+00:00 | `9dd5f393bb084b8ba66e7a98311e4827` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:52:09+00:00 | `8d4f39a00c1448f48f2ad0dda139ebc1` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:53:36+00:00 | `c135529f39de4e0a929893f4b04ab9f0` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:55:02+00:00 | `1b8604f5f6024993a9381031049f7709` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:56:18+00:00 | `4fd595a45caa4435aafbc7155d4dcea6` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T03:57:45+00:00 | `1c44cf2c539f49a5b589eec2f1335715` | 380540 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T03:59:02+00:00 | `4912065c23b54922ab5a08301ada1c02` | 380540 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:00:17+00:00 | `25638c8e6f9e46caa0d6ed26a56e5eb0` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:01:58+00:00 | `c6e7fdead26d4305b85f0ab5fc076e26` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:03:10+00:00 | `f8b260e52a2145749166ea6c2cf3c458` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:04:24+00:00 | `1fa9313a956b4d6bb15f652cf645b6a7` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:05:36+00:00 | `371b51a7e8ef4d349de421d323e44df8` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:06:52+00:00 | `b9b9a48ec0d14551a9879c8951d5d16a` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:08:13+00:00 | `74585ed814f247b29052872a5393a319` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:09:27+00:00 | `61b3bd58cd2f42deb15ef2f6ce9e4fee` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:11:08+00:00 | `c55776dea34a4e71bb76db08678f7414` | 095910 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:12:16+00:00 | `a24d00e1d4cc4ed08311320b366f9867` | 095910 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:13:31+00:00 | `6f7de9a33a3c4260be2e0df847a67a2e` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:14:42+00:00 | `84bef6765e004fcb8028495824f503b3` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:15:52+00:00 | `e3477c6d5aea4cc4a1eb4bda7f2fd656` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:17:11+00:00 | `c70289d8b2984a69a795876b5675c0be` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:18:30+00:00 | `a44ad291617545d1b310f257ecda00c3` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:19:49+00:00 | `0f074776d214460893b85a633ba4c71a` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:20:57+00:00 | `d9d6756d8c6147a1ae6e24ea4c788bc2` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:22:15+00:00 | `5e48a33ce50749fc9e8397916736cb8c` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:23:32+00:00 | `c0d925f32aa143ed96abf60d016dc66a` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:24:43+00:00 | `657d4098d8c44295bfdc09028a2cecdb` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:26:00+00:00 | `edc8d5d9aa174d64a1894a5758817cd4` | 095910 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:27:37+00:00 | `6ffcc2f496dd46b8b1d68697d54eac47` | 095910 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:28:57+00:00 | `b2f165ca46ae489290863775d87f4e5c` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:30:16+00:00 | `e1d8abf09c434db2b44767f3b5752c00` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:31:39+00:00 | `cddcbc69dd4b4232adb8d7632822796a` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:32:49+00:00 | `67a20d2508b6490d838274e40d7b770a` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:34:09+00:00 | `c73837e2aa56449ea51ac93529e92cde` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:35:26+00:00 | `7a87b8224acc4baa97f496bfb17b56fe` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:36:38+00:00 | `4bae5289d2b34c3f9dd82e595da1dec8` | 380540 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:38:05+00:00 | `b5443203ae5d4e619cd7ea35c5fa4d39` | 380540 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:39:24+00:00 | `709fb94e36f442679ca763176a7d966b` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:40:32+00:00 | `5f1edeb538de4456ab31ec51030c8a60` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:41:40+00:00 | `ca3d6cc9272b42189a893a6e67ae8297` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:42:57+00:00 | `1f6599c17d6e40538dd874f9b041b276` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:44:41+00:00 | `be7511a3cdce422985142d8a4350c46d` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:46:03+00:00 | `40af167b6db343fba56fae5dafe72ccf` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:47:18+00:00 | `2f74dd89427e44cd888727a930943bd0` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:48:43+00:00 | `322b2af0c8f541ad8e4eb2965f799613` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:50:03+00:00 | `2eb40d6dcfe4400494dd7d71698427bb` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:51:17+00:00 | `325b47eac51e4d86b35e2464907eea09` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:52:28+00:00 | `2f7ca16249454815a184e49eecd532d0` | 095910 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:53:38+00:00 | `adc295fcf01b4a048b7ee0df2c84a36e` | 095910 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:54:43+00:00 | `38c2d2e5608f46ddb13821c512098ce2` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:55:55+00:00 | `5202403e7d44431a8465001b36d8f482` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T04:57:38+00:00 | `805c4370ed1240c3aee60d36c4ad476b` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T04:58:54+00:00 | `f84b216ac4db42ca8a24a2ccf23d6af5` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T05:00:23+00:00 | `221bc8f28d7d480abe0fe64dc9650014` | 095910 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T05:01:42+00:00 | `3d050d82fbf447a399cf44ce3eda79cf` | 095910 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T05:02:50+00:00 | `664a84db4b83485da219c7a587f946ee` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T05:04:02+00:00 | `270eec33a4ee44f19111f1a503c075bb` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T05:05:24+00:00 | `ad3c09ffd5544fe386bffdcc9c0e4d6c` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T05:06:51+00:00 | `32c46eb5553742f5a156e04e4d150193` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T05:08:13+00:00 | `4426c6ff18a34d3984b24751e356e1f9` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T05:09:39+00:00 | `09f2b267b1364c939277fcfa5d37b07d` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T05:11:07+00:00 | `fd4ade101a31479d98cff856d3cce2c8` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T05:12:25+00:00 | `a9692c77ffd14e14b31bdb653cb854fb` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T05:14:13+00:00 | `fc1ca638d9154b13b46713597ad7d690` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T05:15:25+00:00 | `1865a4d323c244a781a2a0bcf9bfeac9` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T05:18:12+00:00 | `0621d712711d42f89115e9598f0e3e20` | 380540 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T05:20:48+00:00 | `b3216de3a7284a3c9c7ce06692ba6430` | 380540 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T05:22:22+00:00 | `07feba83be9b4a06934b389c0366e6e9` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T05:24:32+00:00 | `9b335c2577324f5ca7abb7207fdf1d2b` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T05:25:42+00:00 | `a116fa8bf8d042ee8d5d08b14609d5cc` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-12T05:26:57+00:00 | `bb6fbdfd8ee14fabb2de067071e199c7` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-12T05:28:21+00:00 | `21bf6f5f28374d6cb62507658d4e833e` | 032820 | BUY | 1 | 0.0 | - | - |

## Sell Pair Analysis (FIFO, Latest)

### SELL `60e74545f2954e9b94a5fd1b6c482432` / 005930
- sell_ts: 2026-03-12T01:19:38+00:00
- qty: sell=2, matched=0, unmatched=2
- hold_duration_sec_avg: **0** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1556569317255232
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `[]`

### SELL `96d05655a3e7459c8d94a2613e143ca1` / 005930
- sell_ts: 2026-03-12T01:23:38+00:00
- qty: sell=2, matched=0, unmatched=2
- hold_duration_sec_avg: **0** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1418426196775542
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `[]`

### SELL `966e416b56054976a3022a1d6d7926c2` / 032820
- sell_ts: 2026-03-12T01:36:06+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **5484** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1373778037805045
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['cfedf8f1a65d49d4809249695154bc18']`

### SELL `fd9d71d98eba4703b949ac773a520e4c` / 032820
- sell_ts: 2026-03-12T01:39:09+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **5565** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1618491493640997
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['40f6e2e3aab04942913632725de79ee8']`

### SELL `0795f8c1bd2f4f9b80720f699771f640` / 032820
- sell_ts: 2026-03-12T01:41:56+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **5208** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1618461156339723
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['685be82701b9464196eb0aa6f6a68efa']`

### SELL `b36cc6d1f351441baadb6f0dfe16ed84` / 005930
- sell_ts: 2026-03-12T01:58:53+00:00
- qty: sell=20, matched=0, unmatched=20
- hold_duration_sec_avg: **0** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=70000.0
- strategy: -
- sell_reason: -
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `[]`

### SELL `1846e0d5d9b84b75a47baf4b49515598` / 032820
- sell_ts: 2026-03-12T01:59:31+00:00
- qty: sell=16, matched=16, unmatched=0
- hold_duration_sec_avg: **4639** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.16562860913088
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=stop_loss, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['4302ce0ee7a84193b8c6e73e533c50fd', '1c60c02fe381441f90d4dd709d7575c6', '347c3d096f504b73ae6c01b5b61899dd', '4bdcaca2a1ac4f68a8a36dd80d54cf1f', 'ef7f0ed7944a4fe4856528001f3a52ae', 'a900404075904b60bbae67065a43391e', '179c2a35c9a0476daa7146608f4dce3e', 'efafedb80583409aad50ef0a9e16f030', 'c7884a8183ed4c1b9c68d3ca538b0540', '919425ddd88543269e3c07b569ccb766', '5bd64f2da6c64d92919f96a46193ffc3', '4260abb217fe473e85cf44e501f710e9', '7ccad0276ed74780a7cbd898f157d050', '8abcd31b7b454b73bac4770e501e0610', 'f33d1e79c3464d3e99b3f2b68387395d', '11e2fb08ff3340f08b4904a1120aec21']`

### SELL `c3767e3bd8c24cdc8e7f9ff2bd4b6663` / 006910
- sell_ts: 2026-03-12T02:00:47+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **6766** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1432952203750806
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=stop_loss, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['4b0e90a60eff42f88e2c6ca53e0ea264', 'd00cca0f269643eb8c1a97f6ecb30b1e']`

### SELL `bca1f45a15cf49d69542a75235b5b556` / 024060
- sell_ts: 2026-03-12T02:02:15+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **7259** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1656205114624238
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=stop_loss, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['75c3739b0d1a4f7cb5cc97910e99209c', '4ecc4f6b97254c69a58207d23fe430ab']`

### SELL `995f0ebc11fb4e0a9650377d75baeab6` / 051910
- sell_ts: 2026-03-12T02:03:37+00:00
- qty: sell=324, matched=0, unmatched=324
- hold_duration_sec_avg: **0** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.143278017661872
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=stop_loss, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `[]`

### SELL `f1ca5678c36343c38167d4fdc9b7981f` / 357880
- sell_ts: 2026-03-12T02:05:46+00:00
- qty: sell=9, matched=9, unmatched=0
- hold_duration_sec_avg: **5591** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=357880, top_score=0.9154731167409126
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=stop_loss, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['1d1bd8b216f4497aaa8d364001d9c2e8', '2161cccd31b641a5a7cebcc05e2c3fa3', '0a8df67abc7047d1a21f30a9aac2c0de', '5835be0f79ff42eeb9c70619fbda859b', '0b5dd9bf60d542d38d13f5910d60721a', 'e59e65f284f648b8a808e679e285938c', '78757acd8615460dbb7ff80577598a52', 'e6c7aa046df64470bbdf0546d016eb98', 'bb8919bfb5f7413d96cefd6fae8815b0']`

### SELL `af94ca714b034a28b4b7aa10cd04dcd0` / 005930
- sell_ts: 2026-03-12T02:07:03+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **490** / estimated_realized_pnl: **-70000.0**
- entry_vs_exit_price: entry_avg=70000.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=357880, top_score=0.9153131189726836
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=stop_loss, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['276a767311874448a24ffb2c42b41471']`

### SELL `5ce388e8e9de4e07b827ed21b0fb184e` / 380540
- sell_ts: 2026-03-12T02:11:43+00:00
- qty: sell=3, matched=3, unmatched=0
- hold_duration_sec_avg: **7034** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1445634779212
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=take_profit, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['b15496873e274707955dccf2c02f7bdc', 'daf656d3405c4cf0a59e230a8e1f4f25', '897f80af557747929398653b10dc5fe8']`

### SELL `43cb751563644832b064af98dda81c6a` / 380540
- sell_ts: 2026-03-12T02:15:23+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **83** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1552620609450888
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['084bfad5f260424c9334eb6cc355475e']`

### SELL `6a923132c4854676bf9748bad8d41729` / 032820
- sell_ts: 2026-03-12T02:18:41+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **113** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=380540, top_score=0.8210951209437065
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['a62d4ef310de4f8c9955c6db7ee48fa5']`

### SELL `cba0dafe11324a4486ba5eda62854cdd` / 046120
- sell_ts: 2026-03-12T02:21:17+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **88** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=380540, top_score=0.8210961321869548
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['7b656329d62c46d4955b8f4307c86515']`

### SELL `39e5db0373f04e4fb2da4a509c70c666` / 032820
- sell_ts: 2026-03-12T02:24:50+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **84** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1552504239316506
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['4e492828e1cf45b68349ca6b1f480729']`

### SELL `40e75e7f897d4da29f7d8006421eddb9` / 032820
- sell_ts: 2026-03-12T02:27:57+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **108** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1775828014474716
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['684e5ac951164f1cbef78cb20c35d421']`

### SELL `55b9325640fe42cfa4ca808a05e67d7b` / 032820
- sell_ts: 2026-03-12T02:30:28+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **83** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1555954513229718
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['fe92900464ef4438a6ae0171853271ce']`

### SELL `c88427e9935e4bc19c5088bdbe835ba8` / 032820
- sell_ts: 2026-03-12T02:33:37+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **85** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1748747142160951
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['bcd8fffc6a674b008704f3eab0d67bd5']`

### SELL `eaaecd4e0ffd4f0591f27a6e3d75c9a6` / 005930
- sell_ts: 2026-03-12T02:33:47+00:00
- qty: sell=20, matched=6, unmatched=14
- hold_duration_sec_avg: **1400** / estimated_realized_pnl: **140000.0**
- entry_vs_exit_price: entry_avg=46666.6667, exit=70000.0
- strategy: -
- sell_reason: -
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['161e3f0b11094df2b0ea415e4d115633', '55d4380b861b42b488041a76599e5f48', '7bfd87bf38c5406d80db13fb86900105', '9bacfc9629d94496a79c5fb5c8da9a8b', 'trace-r2', 'trace-r2']`

### SELL `0e185bfbeecf468088dfd821ab5df369` / 032820
- sell_ts: 2026-03-12T02:39:03+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **289** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.174868137305408
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=stop_loss, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['ee260f0703d0462cbc83476e397fd379']`

### SELL `a4fc50a18762464b9978d55c2065b633` / 005930
- sell_ts: 2026-03-12T02:41:26+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **459** / estimated_realized_pnl: **-70000.0**
- entry_vs_exit_price: entry_avg=70000.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1744341883676572
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=stop_loss, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['77a3090683e641e58156b3dccf817e9a']`

### SELL `b8d04932945b43f0b83b46fd4b5736ca` / 032820
- sell_ts: 2026-03-12T02:44:55+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **70** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1739941720149736
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['a42595d091dd482a94b38384c135e785']`

### SELL `15438ecdf5104fd5a10616a196c088d8` / 032820
- sell_ts: 2026-03-12T02:48:33+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **142** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1739734301279394
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['7c6bac55c2d541de9e55146b50f6b821']`

### SELL `3c5608206224445a85d36e270986fc4a` / 032820
- sell_ts: 2026-03-12T02:51:22+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **83** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1739815238568403
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['b929d1326116455bbb54135f7663f3d8']`

### SELL `ef9a7eae8ca04b21b6c8925b483f347d` / 032820
- sell_ts: 2026-03-12T02:54:02+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **79** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1709375181167767
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['46fffc53ee0f453793b5a925ec1906dd']`

### SELL `f73fd2a04486414ca2d269c3165c10d0` / 032820
- sell_ts: 2026-03-12T02:57:42+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **82** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1709309412390503
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['7c0b8b2fcd05472583afe3bf9903707e']`

### SELL `f94ab36e09de4801bc858215a14b8b3a` / 380540
- sell_ts: 2026-03-12T03:03:39+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **186** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=380540, top_score=0.8205453068828377
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['83ab963ea0ee4f24a4eb3c4589b16d2a']`

### SELL `c7aba95f1c6f4612a1cf4d2dc74ecbc6` / 032820
- sell_ts: 2026-03-12T03:06:25+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **86** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.170945611853055
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['01d3028757484f989d328591a859d964']`

### SELL `481fc66532394ab0826867ef93afff72` / 032820
- sell_ts: 2026-03-12T03:09:59+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **83** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.170946117470642
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['2591e17bc1294b71a118eaa83552289d']`

### SELL `1443a97aa51f435b8696f0d151fbe87e` / 032820
- sell_ts: 2026-03-12T03:12:41+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **77** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1490904567947302
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['f3dea97cc5614ecbb82495aa861c24a5']`

### SELL `ea596f9a050242ea806203cab1c75e57` / 032820
- sell_ts: 2026-03-12T03:15:28+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **88** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=380540, top_score=0.8169103630539494
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['76cf9d4163b34e399e0a1caa931845be']`

### SELL `1a1c0c99d4bd40e986a776a4fae5a700` / 032820
- sell_ts: 2026-03-12T03:17:51+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **75** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.149087423088264
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['9ed931b2dbce4c83b1a594a37ed951af']`

### SELL `d20fb34914f8460ba37721f702555206` / 380540
- sell_ts: 2026-03-12T03:21:10+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **125** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.170945611853055
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['9655ef3a9dd542c5b6a4fd00b75a1d55']`

### SELL `e26c6ebdf8c34dbe998adce648231b4a` / 032820
- sell_ts: 2026-03-12T03:23:51+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **70** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=380540, top_score=0.8169002468556096
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['97a494e85d8446e890c20cc69d469f77']`

### SELL `9408d7e9b19f402d9d431dd96d9bf887` / 032820
- sell_ts: 2026-03-12T03:26:22+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **75** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1709294243895871
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['66869abb6e4448f3b2c6f108c5c665b6']`

### SELL `0e44dc190ab14eb49f3c37902eedd139` / 032820
- sell_ts: 2026-03-12T03:28:43+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **70** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1709375181167767
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['51bb3293c1534e3a81f1a128ace26cb5']`

### SELL `5ef3402000e349ec859a3c8bec97bb01` / 380540
- sell_ts: 2026-03-12T03:32:48+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **76** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=380540, top_score=0.8175139062355031
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['98e01f533a4f4e358f741176127b1bf7']`

### SELL `e00b72e36b2a4191bf39c8d51201e291` / 380540
- sell_ts: 2026-03-12T03:35:29+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **84** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.149087423088264
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['c2e553223b1544d98be49b4f0c118e5e']`

### SELL `5048d39696dd4fc389cd2e233b326657` / 380540
- sell_ts: 2026-03-12T03:38:00+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **72** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=380540, top_score=0.8175042917893701
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['4141499845bf4dcc93f115cb1ff7df69']`

### SELL `7fce2f53e1ce4a8cabd0eef46e08a7a3` / 380540
- sell_ts: 2026-03-12T03:41:32+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **127** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=380540, top_score=0.8175078349679512
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['2dbc5ac379cc4b87943f687ba066b737']`

### SELL `28559633a3fa4e8495cea07ffed11775` / 032820
- sell_ts: 2026-03-12T03:44:57+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **78** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.170946117470642
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['18c56d785c61414fa28d8c633e30e4c3']`

### SELL `d3c44f4a53a7478a8c2f5f4e99c80dc3` / 032820
- sell_ts: 2026-03-12T03:48:14+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **107** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1487327799039022
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['0d7cd5545505439fa4397863755f3a74']`

### SELL `9dd5f393bb084b8ba66e7a98311e4827` / 032820
- sell_ts: 2026-03-12T03:50:50+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **75** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1705960287021622
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['52fcff392cc54a06b1c6603fd6e4e232']`

### SELL `c135529f39de4e0a929893f4b04ab9f0` / 032820
- sell_ts: 2026-03-12T03:53:36+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **87** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1487403680252706
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['8d4f39a00c1448f48f2ad0dda139ebc1']`

### SELL `4fd595a45caa4435aafbc7155d4dcea6` / 032820
- sell_ts: 2026-03-12T03:56:18+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **76** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1487434055918344
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['1b8604f5f6024993a9381031049f7709']`

### SELL `4912065c23b54922ab5a08301ada1c02` / 380540
- sell_ts: 2026-03-12T03:59:02+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **77** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1706015904963878
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['1c44cf2c539f49a5b589eec2f1335715']`

### SELL `c6e7fdead26d4305b85f0ab5fc076e26` / 032820
- sell_ts: 2026-03-12T04:01:58+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **101** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1487464048808562
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['25638c8e6f9e46caa0d6ed26a56e5eb0']`

### SELL `1fa9313a956b4d6bb15f652cf645b6a7` / 032820
- sell_ts: 2026-03-12T04:04:24+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **74** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1705980167532177
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['f8b260e52a2145749166ea6c2cf3c458']`

### SELL `b9b9a48ec0d14551a9879c8951d5d16a` / 032820
- sell_ts: 2026-03-12T04:06:52+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **76** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=380540, top_score=0.8182281361719833
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['371b51a7e8ef4d349de421d323e44df8']`

### SELL `61b3bd58cd2f42deb15ef2f6ce9e4fee` / 032820
- sell_ts: 2026-03-12T04:09:27+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **74** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1487388167532178
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['74585ed814f247b29052872a5393a319']`

### SELL `a24d00e1d4cc4ed08311320b366f9867` / 095910
- sell_ts: 2026-03-12T04:12:16+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **68** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.148938652258412
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['c55776dea34a4e71bb76db08678f7414']`

### SELL `84bef6765e004fcb8028495824f503b3` / 032820
- sell_ts: 2026-03-12T04:14:42+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **71** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.148938652258412
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['6f7de9a33a3c4260be2e0df847a67a2e']`

### SELL `c70289d8b2984a69a795876b5675c0be` / 032820
- sell_ts: 2026-03-12T04:17:11+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **79** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1489426809888676
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['e3477c6d5aea4cc4a1eb4bda7f2fd656']`

### SELL `0f074776d214460893b85a633ba4c71a` / 032820
- sell_ts: 2026-03-12T04:19:49+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **79** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=095910, top_score=0.8421658027509353
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['a44ad291617545d1b310f257ecda00c3']`

### SELL `5e48a33ce50749fc9e8397916736cb8c` / 032820
- sell_ts: 2026-03-12T04:22:15+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **78** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1708049063819455
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['d9d6756d8c6147a1ae6e24ea4c788bc2']`

### SELL `657d4098d8c44295bfdc09028a2cecdb` / 032820
- sell_ts: 2026-03-12T04:24:43+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **71** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1708023845802846
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['c0d925f32aa143ed96abf60d016dc66a']`

### SELL `6ffcc2f496dd46b8b1d68697d54eac47` / 095910
- sell_ts: 2026-03-12T04:27:37+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **97** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.170803895354682
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['edc8d5d9aa174d64a1894a5758817cd4']`

### SELL `e1d8abf09c434db2b44767f3b5752c00` / 032820
- sell_ts: 2026-03-12T04:30:16+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **79** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1489472171567077
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['b2f165ca46ae489290863775d87f4e5c']`

### SELL `67a20d2508b6490d838274e40d7b770a` / 032820
- sell_ts: 2026-03-12T04:32:49+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **70** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1708049063819455
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['cddcbc69dd4b4232adb8d7632822796a']`

### SELL `7a87b8224acc4baa97f496bfb17b56fe` / 032820
- sell_ts: 2026-03-12T04:35:26+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **77** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=095910, top_score=0.836086628993338
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['c73837e2aa56449ea51ac93529e92cde']`

### SELL `b5443203ae5d4e619cd7ea35c5fa4d39` / 380540
- sell_ts: 2026-03-12T04:38:05+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **87** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1708008738061066
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['4bae5289d2b34c3f9dd82e595da1dec8']`

### SELL `5f1edeb538de4456ab31ec51030c8a60` / 032820
- sell_ts: 2026-03-12T04:40:32+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **68** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1708043989461965
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['709fb94e36f442679ca763176a7d966b']`

### SELL `1f6599c17d6e40538dd874f9b041b276` / 032820
- sell_ts: 2026-03-12T04:42:57+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **77** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.170801377397475
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['ca3d6cc9272b42189a893a6e67ae8297']`

### SELL `40af167b6db343fba56fae5dafe72ccf` / 032820
- sell_ts: 2026-03-12T04:46:03+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **82** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1707882763415094
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['be7511a3cdce422985142d8a4350c46d']`

### SELL `322b2af0c8f541ad8e4eb2965f799613` / 032820
- sell_ts: 2026-03-12T04:48:43+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **85** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1707847512069731
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['2f74dd89427e44cd888727a930943bd0']`

### SELL `325b47eac51e4d86b35e2464907eea09` / 032820
- sell_ts: 2026-03-12T04:51:17+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **74** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1489245401817019
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['2eb40d6dcfe4400494dd7d71698427bb']`

### SELL `adc295fcf01b4a048b7ee0df2c84a36e` / 095910
- sell_ts: 2026-03-12T04:53:38+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **70** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1489205114584429
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['2f7ca16249454815a184e49eecd532d0']`

### SELL `5202403e7d44431a8465001b36d8f482` / 032820
- sell_ts: 2026-03-12T04:55:55+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **72** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=095910, top_score=0.8430940598055774
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['38c2d2e5608f46ddb13821c512098ce2']`

### SELL `f84b216ac4db42ca8a24a2ccf23d6af5` / 032820
- sell_ts: 2026-03-12T04:58:54+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **76** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.148916478892619
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['805c4370ed1240c3aee60d36c4ad476b']`

### SELL `3d050d82fbf447a399cf44ce3eda79cf` / 095910
- sell_ts: 2026-03-12T05:01:42+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **79** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1489210150487612
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['221bc8f28d7d480abe0fe64dc9650014']`

### SELL `270eec33a4ee44f19111f1a503c075bb` / 032820
- sell_ts: 2026-03-12T05:04:02+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **72** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1489220222294743
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['664a84db4b83485da219c7a587f946ee']`

### SELL `32c46eb5553742f5a156e04e4d150193` / 032820
- sell_ts: 2026-03-12T05:06:51+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **87** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1707812222294742
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['ad3c09ffd5544fe386bffdcc9c0e4d6c']`

### SELL `09f2b267b1364c939277fcfa5d37b07d` / 032820
- sell_ts: 2026-03-12T05:09:39+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **86** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1707776970974255
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['4426c6ff18a34d3984b24751e356e1f9']`

### SELL `a9692c77ffd14e14b31bdb653cb854fb` / 032820
- sell_ts: 2026-03-12T05:12:25+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **78** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1707792078681503
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['fd4ade101a31479d98cff856d3cce2c8']`

### SELL `1865a4d323c244a781a2a0bcf9bfeac9` / 032820
- sell_ts: 2026-03-12T05:15:25+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **72** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1707958340495672
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['fc1ca638d9154b13b46713597ad7d690']`

### SELL `b3216de3a7284a3c9c7ce06692ba6430` / 380540
- sell_ts: 2026-03-12T05:20:48+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **156** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1708099422986646
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['0621d712711d42f89115e9598f0e3e20']`

### SELL `9b335c2577324f5ca7abb7207fdf1d2b` / 032820
- sell_ts: 2026-03-12T05:24:32+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **130** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=380540, top_score=0.8210898339924053
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['07feba83be9b4a06934b389c0366e6e9']`

### SELL `bb6fbdfd8ee14fabb2de067071e199c7` / 032820
- sell_ts: 2026-03-12T05:26:57+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **75** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1489361304584698
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=max_hold, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['a116fa8bf8d042ee8d5d08b14609d5cc']`

## Data Gaps

- scanner_score_breakdown_missing_total: 16
- news_items_missing_total: 196
- note: news headline text and scanner score_breakdown are limited by current event-log payload policy.
