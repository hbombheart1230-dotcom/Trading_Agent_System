# Trade Explain Report (2026-03-16)

- event_log_path: `data\logs\events.jsonl`
- executions_total: **12**
- sell_pairs_total: **6**

## Executive Summary

- symbols_executed: `['032820']`
- action_counts: `{'SELL': 6, 'BUY': 6}`
- symbol_side_counts: `{'032820:SELL': 6, '032820:BUY': 6}`
- short_holds_lt_120s: **5**

## Agent Activity Snapshot

- `commander_router`: 532
- `strategist_llm`: 264
- `strategist`: 264
- `decision_trace`: 1119
- `scanner`: 266
- `monitor`: 264
- `execute_from_packet`: 509
- `skill_execute`: 109
- `skill_result`: 109
- `skill_hydration`: 203

## Report Inventory

- none

## Execution Timeline (Latest)

| ts | run_id | symbol | action | qty | price | strategy | reason |
| --- | --- | --- | --- | ---: | ---: | --- | --- |
| 2026-03-16T00:03:42+00:00 | `ebcda2b4ece048869d706d6a429f5119` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-16T00:19:41+00:00 | `686da792538349b09be06cb0b29df0bf` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-16T00:21:05+00:00 | `0b219084146245f2bcc84851cd256060` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-16T00:36:50+00:00 | `c5721c16e34543128d1f02c37d232c61` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-16T00:38:15+00:00 | `ef9ff875f1d4481f9da0d8c2095773c4` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-16T00:54:30+00:00 | `7071ddcc326c4ec0b811e5f415f27d22` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-16T00:55:57+00:00 | `629f47f568ac4be48f7c7fb5050be3b2` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-16T01:11:45+00:00 | `11d29b9d669740f0bf195523fc064ed0` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-16T01:13:10+00:00 | `ad5f06c28a664e79ae6a8640ed4b49a2` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-16T01:34:53+00:00 | `13d6b1fc402f490d8c79d12d1f2203c4` | 032820 | BUY | 1 | 0.0 | - | - |
| 2026-03-16T02:55:50+00:00 | `85e8b128f35541aa84d7b8b9ece0d8f0` | 032820 | SELL | 1 | 0.0 | - | - |
| 2026-03-16T03:41:51+00:00 | `5d4d2cd0542046f6a8ec76240e225e98` | 032820 | BUY | 1 | 0.0 | - | - |

## Sell Pair Analysis (FIFO, Latest)

### SELL `ebcda2b4ece048869d706d6a429f5119` / 032820
- sell_ts: 2026-03-16T00:03:42+00:00
- qty: sell=1, matched=0, unmatched=1
- hold_duration_sec_avg: **0** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.2354203052469261
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=take_profit, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `[]`

### SELL `0b219084146245f2bcc84851cd256060` / 032820
- sell_ts: 2026-03-16T00:21:05+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **84** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.307409913365549
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=stop_loss, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['686da792538349b09be06cb0b29df0bf']`

### SELL `ef9ff875f1d4481f9da0d8c2095773c4` / 032820
- sell_ts: 2026-03-16T00:38:15+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **85** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.3792572584405651
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=stop_loss, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['c5721c16e34543128d1f02c37d232c61']`

### SELL `629f47f568ac4be48f7c7fb5050be3b2` / 032820
- sell_ts: 2026-03-16T00:55:57+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **87** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.1526061611320766
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=stop_loss, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['7071ddcc326c4ec0b811e5f415f27d22']`

### SELL `ad5f06c28a664e79ae6a8640ed4b49a2` / 032820
- sell_ts: 2026-03-16T01:13:10+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **85** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=032820, top_score=1.42729100925596
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=stop_loss, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['11d29b9d669740f0bf195523fc064ed0']`

### SELL `85e8b128f35541aa84d7b8b9ece0d8f0` / 032820
- sell_ts: 2026-03-16T02:55:50+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **4857** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=0.0, exit=0.0
- strategy: -
- sell_reason: -
- scanner_context: source=kiwoom_market_data, top_stock=000660, top_score=1.139632717199362
- sentiment_context: symbol=None, global=None, status=(-, -)
- technical_context: signal_score=None, rsi14=None, ma20_gap=None, volatility20=None, composite=None
- monitor_context: exit_reason=take_profit, monitor_reason=confirmed_exit_signal
- matched_buy_runs: `['13d6b1fc402f490d8c79d12d1f2203c4']`

## Data Gaps

- scanner_score_breakdown_missing_total: 0
- news_items_missing_total: 12
- note: news headline text and scanner score_breakdown are limited by current event-log payload policy.
