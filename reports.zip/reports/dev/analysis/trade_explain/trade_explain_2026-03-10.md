# Trade Explain Report (2026-03-10)

- event_log_path: `data\logs\events.jsonl`
- executions_total: **290**
- sell_pairs_total: **56**

## Executive Summary

- symbols_executed: `['005930']`
- action_counts: `{'BUY': 234, 'SELL': 56}`
- symbol_side_counts: `{'005930:BUY': 234, '005930:SELL': 56}`
- short_holds_lt_120s: **29**

## Agent Activity Snapshot

- `decision`: 922
- `execute_from_packet`: 2589
- `strategist_llm`: 212
- `monitor`: 680
- `skill_execute`: 18
- `skill_result`: 18
- `commander_router`: 1728
- `skill_hydration`: 216
- `scanner`: 296

## Report Inventory

- `reports\operator_summary\operator_summary_2026-03-10.md`
- `reports\decision_story\decision_story_2026-03-10.md`
- `reports\run_cards\run_cards_2026-03-10.md`
- `reports\metrics\metrics_2026-03-10.md`
- `reports\daily_report_2026-03-10.md`
- `reports\live_watch\live_watch_latest.md`

## Execution Timeline (Latest)

| ts | run_id | symbol | action | qty | price | strategy | reason |
| --- | --- | --- | --- | ---: | ---: | --- | --- |
| 2026-03-10T00:01:11+00:00 | `3d81f378160c4fed9bc692915c0ba378` | 005930 | BUY | 1 | 187900.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2370 regime=high_volatility |
| 2026-03-10T00:02:13+00:00 | `18c2b1bc5a1d4ac9b88ca6805c4abd11` | 005930 | SELL | 1 | 187100.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T00:16:44+00:00 | `f9e2fc3d7bc54d82854f4d3de966f6a8` | 005930 | BUY | 1 | 187500.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2364 regime=high_volatility |
| 2026-03-10T00:17:46+00:00 | `65219cd36eec46b7a3d254a0010b0a23` | 005930 | SELL | 1 | 187700.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T00:19:50+00:00 | `08cda0a38432400d8f31d1591dc92e65` | 005930 | BUY | 2 | 187800.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2361 regime=trend |
| 2026-03-10T00:20:53+00:00 | `73579a1591ec4a8fbd61fa9ec9fda28c` | 005930 | SELL | 2 | 187800.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T00:23:58+00:00 | `6acb22e0f6c544df8004c343fb7f1efe` | 005930 | BUY | 2 | 187400.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2349 regime=range |
| 2026-03-10T00:25:02+00:00 | `b22102e64d24487b8f06764941080a27` | 005930 | SELL | 2 | 187900.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T00:28:09+00:00 | `05985d2ab4974d47abe34b52c7318223` | 005930 | BUY | 2 | 187800.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2351 regime=range |
| 2026-03-10T00:29:11+00:00 | `7301c6f2c97849648135164c3f1e22dc` | 005930 | SELL | 2 | 187900.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T00:31:17+00:00 | `3cf08da38c5543b78ef096e7d3522d06` | 005930 | BUY | 2 | 188300.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2553 regime=range |
| 2026-03-10T00:32:20+00:00 | `271ed4656dbb4702ad394d3390d80881` | 005930 | SELL | 2 | 188300.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T00:34:24+00:00 | `814d734dbbb24c42a21bd9902966ec77` | 005930 | BUY | 2 | 188200.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2550 regime=range |
| 2026-03-10T00:35:26+00:00 | `8907d620bb8d4c76867309d10505ac8a` | 005930 | SELL | 2 | 187400.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T00:37:32+00:00 | `4b057edfb35d4ea1819e9f3a76694058` | 005930 | BUY | 2 | 188200.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2548 regime=range |
| 2026-03-10T00:38:35+00:00 | `60ca4494e57945f1bcd0dd392618a914` | 005930 | SELL | 2 | 188500.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T00:40:39+00:00 | `b467a05999934db88ee3649e7ec28b2b` | 005930 | BUY | 2 | 188400.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2549 regime=range |
| 2026-03-10T00:41:43+00:00 | `4a4cd8d8af0c411d80428fd3c92289b1` | 005930 | SELL | 2 | 188900.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T00:44:48+00:00 | `c8fd92cef3374f17b67882e870ce44f7` | 005930 | BUY | 2 | 189850.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2561 regime=range |
| 2026-03-10T00:45:51+00:00 | `34825c12fb71494ea2e47e972cb3a017` | 005930 | SELL | 2 | 190000.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T00:56:12+00:00 | `5f61f56353064052813f25893e39449f` | 005930 | BUY | 2 | 189700.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2546 regime=range |
| 2026-03-10T00:57:16+00:00 | `f49bb89735cf46299097c7ee8a8a313e` | 005930 | SELL | 2 | 189800.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T01:12:48+00:00 | `74239b6113144caab3e863262560e90f` | 005930 | BUY | 2 | 189800.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2748 regime=range |
| 2026-03-10T01:13:51+00:00 | `980eec326e664b5696fba7d3d4833b65` | 005930 | SELL | 2 | 189600.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T01:18:00+00:00 | `75d7227b1a5341f3b7337eff0d6ababa` | 005930 | BUY | 2 | 189450.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2746 regime=range |
| 2026-03-10T01:19:03+00:00 | `ca7341fe10ca4581ad81f4d0b29e3e97` | 005930 | SELL | 2 | 189750.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T01:21:07+00:00 | `24ecf022f4974ca7bfd5d287e1526c1d` | 005930 | BUY | 2 | 189600.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2747 regime=range |
| 2026-03-10T01:22:09+00:00 | `cdba216e794c4049aaa8c14292c8548c` | 005930 | SELL | 2 | 189900.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T01:24:15+00:00 | `13c7c240229d4b92aebbd22fe283349e` | 005930 | BUY | 2 | 189900.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2750 regime=range |
| 2026-03-10T01:25:18+00:00 | `5104b9fbacd4437aa6188ca82141a583` | 005930 | SELL | 2 | 190000.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T01:29:27+00:00 | `f959954e58154d5d8661202779a9f895` | 005930 | BUY | 2 | 189650.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2746 regime=range |
| 2026-03-10T01:30:30+00:00 | `dcaada65326e4d00a6179201779dcbc5` | 005930 | SELL | 2 | 189500.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T01:32:34+00:00 | `79979b70bd4b4daabc2c2ca7d5fe4086` | 005930 | BUY | 2 | 189800.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2747 regime=range |
| 2026-03-10T01:33:39+00:00 | `a3c2f7faf13a4aae87cc35ff64a76c80` | 005930 | SELL | 2 | 190000.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T01:35:44+00:00 | `eee4479dfd53430195788cd26dc5c4f0` | 005930 | BUY | 2 | 189950.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2747 regime=range |
| 2026-03-10T01:36:47+00:00 | `3e1585dd1e104efe9c1f090ce330178f` | 005930 | SELL | 2 | 190050.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T01:38:54+00:00 | `426c1db12c9341fc89e667de49891809` | 005930 | BUY | 2 | 189950.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2746 regime=range |
| 2026-03-10T01:39:57+00:00 | `a9232aa5ade2466eb61c60892525517f` | 005930 | SELL | 2 | 189800.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T01:42:02+00:00 | `956d30790f794369ae7ab6d3cb9207b2` | 005930 | BUY | 2 | 190000.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2746 regime=range |
| 2026-03-10T01:43:05+00:00 | `68286db051604148b37de0494a593bf3` | 005930 | SELL | 2 | 189900.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T01:45:12+00:00 | `a5e788e27b8a440f9aa00a1887d4b8ec` | 005930 | BUY | 2 | 190000.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2746 regime=range |
| 2026-03-10T01:46:15+00:00 | `2de3c5001bad47fda40c2b60d777492a` | 005930 | SELL | 2 | 190400.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T01:48:20+00:00 | `c4445f3691a0494faa71010e3f2169f4` | 005930 | BUY | 2 | 190400.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2749 regime=range |
| 2026-03-10T01:49:31+00:00 | `0673267227224f078584eeeb1ee11d2d` | 005930 | SELL | 2 | 190400.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T01:55:48+00:00 | `d5642538216140f8835155e269840aef` | 005930 | BUY | 2 | 190800.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2749 regime=range |
| 2026-03-10T01:56:51+00:00 | `9f4bc92f08f14ebbb65cdcd98a8d226a` | 005930 | SELL | 2 | 190400.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T01:58:56+00:00 | `7097871385694c0bbf114a76a1ebea02` | 005930 | BUY | 2 | 190800.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2748 regime=range |
| 2026-03-10T02:00:00+00:00 | `8a948c5f4c1e402eb6c39bccdf14b355` | 005930 | SELL | 2 | 190700.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T02:02:05+00:00 | `d9fa1807412b4dcfbf4b9f6622028718` | 005930 | BUY | 2 | 190600.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2745 regime=range |
| 2026-03-10T02:03:08+00:00 | `1866ccfd781b411cb8bcbbc0a3fd1768` | 005930 | SELL | 2 | 190300.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T02:15:40+00:00 | `03a14a9be7be4f4e8ccc5c6d41a69c9c` | 005930 | BUY | 2 | 190400.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.3146 regime=range |
| 2026-03-10T02:16:43+00:00 | `cf5f56086de3492d96471ce79d0f3a03` | 005930 | SELL | 2 | 190100.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T02:18:48+00:00 | `349500a29e5c48a49f64f682743c4385` | 005930 | BUY | 2 | 190500.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.3147 regime=range |
| 2026-03-10T02:19:51+00:00 | `e4ba18041ea84ab9940df434c5e123ef` | 005930 | SELL | 2 | 190500.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T02:21:59+00:00 | `cefda5d714c34240adfa6313ec858fdb` | 005930 | BUY | 2 | 190400.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.3146 regime=range |
| 2026-03-10T02:23:02+00:00 | `bf1c52dd0fbe4f2b99a44a20e873baf9` | 005930 | SELL | 2 | 190400.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T02:25:07+00:00 | `9b0b6d56bb7741c28498dc1a0608095d` | 005930 | BUY | 2 | 190300.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.3145 regime=range |
| 2026-03-10T02:26:12+00:00 | `683043d2950b493f9c422e3f92ee1754` | 005930 | SELL | 2 | 190450.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T02:26:35+00:00 | `0551c1da46a44975ab1b1bdd533a2201` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:26:35+00:00 | `c0acebeb730b4d9c8ee11047e847bede` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:26:35+00:00 | `b8701760c29b4bca896ff00ad6512e54` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:26:35+00:00 | `f4d93f72251a4eb4b648d38abc9857a2` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:26:35+00:00 | `f75cd81c49c54eec81efb96a118b4681` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:28:17+00:00 | `3783fd8f382947f698abd80c81f79f01` | 005930 | BUY | 2 | 190300.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.3145 regime=range |
| 2026-03-10T02:29:20+00:00 | `0c33a7b903654fdc95f9373e31585173` | 005930 | SELL | 2 | 190400.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T02:34:13+00:00 | `98befb135de44610a089bb7f7d416201` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:34:13+00:00 | `4c71c6b404234a8fb4c6a5b21f1efcfa` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:34:13+00:00 | `fdce5642f85d4867b23097f70f6c6980` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:34:13+00:00 | `db8120959002426a820abe25d687feda` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:34:13+00:00 | `487b56dbb1864531bfeaa3d8b2256e2f` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:39:18+00:00 | `518f4cdd204f475aa5fd0d88f5694293` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:39:18+00:00 | `919a374534644907b7ce23b657b3c90d` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:39:18+00:00 | `b25690979fa54a7e96b9a4fd9274d685` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:39:18+00:00 | `c17058f6e1f645ce95222e6a6b9d2567` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:39:18+00:00 | `aa1200da5cf14055a03b414be73c7b39` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:39:33+00:00 | `92e8cb9677b54fb89cd215f35b944865` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:40:20+00:00 | `ec34524f405743e59172e55dff30006d` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:40:24+00:00 | `b6e0f3e359ea4c5aaca2c66ab10df7b1` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:49:36+00:00 | `59340100b91247fdaed20c391dccbeeb` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:49:36+00:00 | `a19bdde3bc304374b867080a1d77a2ce` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:49:36+00:00 | `842866b8746c40219ae1d046d27d7255` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:49:36+00:00 | `ed4240bfc6c2408a82520a51ceba0968` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:49:36+00:00 | `2eeaf48f79c74835a8dd2cabedbcde9d` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:50:12+00:00 | `d41ec995d712434fa2bad4c550b39aa0` | 005930 | BUY | 2 | 188100.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.1433 regime=range |
| 2026-03-10T02:50:12+00:00 | `170176d90eb04704b7c652f2240e2026` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:50:12+00:00 | `de63649b77ff4734908f9d758b3a9266` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:50:12+00:00 | `c78d956f83a14475b069b786edf7d3be` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:50:12+00:00 | `42f7b91763fe4eb2a0694f8c7538ae3a` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:50:12+00:00 | `92928ff1de3f47bf8eb36e7c70d48d39` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:50:17+00:00 | `81704de8eb2c4079abb3f536a0140c46` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:51:08+00:00 | `e003a8daaa4b4f1e9c71d1d0eb913cba` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:51:13+00:00 | `819b1b495f8346da9aceb567269ebb61` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T02:51:16+00:00 | `01f8bee29b0642898102a7f1f5cf800a` | 005930 | SELL | 2 | 187700.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T02:53:23+00:00 | `b45394901fe34cacba4b1fb6d8817a4e` | 005930 | BUY | 2 | 187400.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.1429 regime=range |
| 2026-03-10T02:54:26+00:00 | `57d876df7a30470ea96d9b7a872c7cb0` | 005930 | SELL | 2 | 187300.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T02:56:31+00:00 | `f90e125a26d04afd9d1e79cfe1718045` | 005930 | BUY | 2 | 187000.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.1429 regime=range |
| 2026-03-10T02:57:36+00:00 | `9dac04aed14b47589536706e12f24bdc` | 005930 | SELL | 2 | 187000.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T02:59:42+00:00 | `e8519584a575455798fe69f0a1b8eb39` | 005930 | BUY | 2 | 186800.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.1431 regime=range |
| 2026-03-10T03:00:45+00:00 | `3e220a94805741289991784ad0752cd3` | 005930 | SELL | 2 | 187200.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T03:06:05+00:00 | `644fc8489a0f4c69a0233dcf42759d61` | 005930 | BUY | 2 | 187850.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2747 regime=range |
| 2026-03-10T03:07:08+00:00 | `1ce01bcb65b94788b1f8d389f0a2961a` | 005930 | SELL | 2 | 187600.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T03:09:15+00:00 | `042ac78d298243ecb0f50d1a06d64c21` | 005930 | BUY | 2 | 187600.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2746 regime=range |
| 2026-03-10T03:10:18+00:00 | `8b1338218bb54f0cbac07d233264861d` | 005930 | SELL | 2 | 187600.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T03:12:23+00:00 | `75d908ead2314b2cb5e2eb0cf815286c` | 005930 | BUY | 2 | 187500.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2745 regime=range |
| 2026-03-10T03:13:28+00:00 | `7f9eaf89255d49a59c6c718413fb5399` | 005930 | SELL | 2 | 187200.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T03:18:42+00:00 | `2cca93aafe604561afd533bd4c73001c` | 005930 | BUY | 2 | 187400.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2745 regime=range |
| 2026-03-10T03:19:45+00:00 | `9fbb4316446f4cbe90071c63c58878d0` | 005930 | SELL | 2 | 187200.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T03:21:50+00:00 | `07dd60bc7a0a4f549deaae07896b3f2c` | 005930 | BUY | 2 | 188100.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2751 regime=range |
| 2026-03-10T03:22:53+00:00 | `ca2a605ff17f444ca5da8ddb727f398d` | 005930 | SELL | 2 | 188100.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T03:25:01+00:00 | `aab2fc80dd3c42748fa7238449fdae51` | 005930 | BUY | 2 | 187900.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2749 regime=range |
| 2026-03-10T03:26:05+00:00 | `7c89f988d5824464bbe83474a2fbed41` | 005930 | SELL | 2 | 187800.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T03:44:51+00:00 | `9165d2c7b46d4f58b51bceda9b426d4d` | 005930 | BUY | 2 | 185550.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.1233 regime=range |
| 2026-03-10T03:45:54+00:00 | `be84c5552c5d40c1809f4568f07dc442` | 005930 | SELL | 2 | 185100.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T03:47:59+00:00 | `c133ed62b73046f1bc6e06858f5de3ba` | 005930 | BUY | 2 | 185000.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.1231 regime=range |
| 2026-03-10T03:49:02+00:00 | `5c1094a946b14cbe8d504e1595b083fb` | 005930 | SELL | 2 | 184650.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T03:51:09+00:00 | `7065bd814f4b4f5f94b4046e8c4d20e2` | 005930 | BUY | 2 | 184500.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.1230 regime=range |
| 2026-03-10T03:52:12+00:00 | `b016fc30fae2492cb2e281902e615715` | 005930 | SELL | 2 | 185000.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T03:56:24+00:00 | `9e517d644c8f4103bdb1c982316ee433` | 005930 | BUY | 2 | 186100.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2750 regime=range |
| 2026-03-10T03:57:28+00:00 | `1159283f2f834a2194ed38d2b4ee800d` | 005930 | SELL | 2 | 185700.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T03:59:33+00:00 | `e07db6a85cc44711aa4c9f9684de6291` | 005930 | BUY | 2 | 185600.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2746 regime=range |
| 2026-03-10T04:00:38+00:00 | `135f3072a8824e52aabe43d5a3d07852` | 005930 | SELL | 2 | 185400.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T04:07:56+00:00 | `b3987846684547559040e35c956d3ce7` | 005930 | BUY | 2 | 185700.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2750 regime=range |
| 2026-03-10T04:08:59+00:00 | `6a90d4ecea5f4aee919af57cb2ec0a42` | 005930 | SELL | 2 | 186000.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T04:12:08+00:00 | `85658ca195f54e54964b959dec2d5348` | 005930 | BUY | 2 | 186200.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2754 regime=range |
| 2026-03-10T04:13:11+00:00 | `f2bae0791b8540ec92ac8e02647ed6ea` | 005930 | SELL | 2 | 186400.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T04:15:18+00:00 | `2357d2feb96c45ab9a79c4cf1e3b8611` | 005930 | BUY | 2 | 186200.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2752 regime=range |
| 2026-03-10T04:16:23+00:00 | `2b76bbad49044f99847e777fdefd59e6` | 005930 | SELL | 2 | 186500.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T04:22:38+00:00 | `02557f51df164532a5bd41a82b0d695b` | 005930 | BUY | 2 | 186800.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2555 regime=range |
| 2026-03-10T04:23:41+00:00 | `ea0b9ef630894292b45b41ffaaf92ddd` | 005930 | SELL | 2 | 186900.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T04:35:46+00:00 | `75dd2274c1d74e2d8a2733ba8461b770` | 005930 | BUY | 1 | 187100.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2555 regime=high_volatility |
| 2026-03-10T04:46:17+00:00 | `8797859e93574010bbef3d1fa456ce3e` | 005930 | SELL | 1 | 186800.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T04:59:48+00:00 | `c5488c3645dd45079f561ad8f403d5d2` | 005930 | BUY | 1 | 187200.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2556 regime=high_volatility |
| 2026-03-10T05:09:44+00:00 | `09d00b22d53144658d415e085ac3b5d6` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:09:44+00:00 | `2f8fa2f320aa4d359d4a1dc43e50528e` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:09:44+00:00 | `2f0a6eebc20840ca97ebfd7b23be33c6` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:09:44+00:00 | `8fc375cac55f4427910b4bd2b7cf57e1` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:09:44+00:00 | `184e7e40052d406d8ebc0013ac375304` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:10:10+00:00 | `e2c59445d5524c2bb941de31d1f46bb4` | 005930 | SELL | 1 | 187800.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T05:12:13+00:00 | `fdb966cce8894c62acfe84a81aebf200` | 005930 | BUY | 2 | 187400.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2549 regime=range |
| 2026-03-10T05:21:41+00:00 | `623b93c0d61c4144ad74f3397c632fca` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:21:41+00:00 | `ec8231d38c5c489188b672833b2c8195` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:21:41+00:00 | `238d23b5814a43abb691b10a9b14637e` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:21:41+00:00 | `973f5805148842a4bd8d5efc54dd2b8a` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:21:41+00:00 | `8aa746e432fa489aa85915eaa0b4bf9c` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:21:46+00:00 | `f5273a07c678484994116a02a3395027` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:22:29+00:00 | `35d4ce7aee7d49f9b2f75e21509bc1be` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:22:33+00:00 | `2de351b716544a428ff305543cb3628b` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:22:50+00:00 | `f6da291d03c54a4499964f7dd3be38d7` | 005930 | SELL | 2 | 187400.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T05:26:02+00:00 | `616a04d08c5f4dd2995d171edb7e38c2` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:26:02+00:00 | `53f1ec8168174159a82c84af7a351825` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:26:02+00:00 | `a784b6e2379641e3bfcfc0801d4a896d` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:26:02+00:00 | `bccb8cc7f7154c3996651e5d7b170bb0` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:26:02+00:00 | `7f9bb651015740e6abe6de27dd09e06f` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:26:07+00:00 | `78b4c3a87b4d4968aa3451f09805f8f1` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:26:53+00:00 | `b3ac2a74f7774d078820efe44e240541` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:26:58+00:00 | `6f325bac279f43f58ee1de1adf6b6ff1` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:32:20+00:00 | `eb237c4ee4cb4a4a91a13432ac5c1ce8` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:32:20+00:00 | `f89023c10152451a91eff56c866e01cf` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:32:20+00:00 | `6ad617fcadc64a8c88bc385a65fa7c53` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:32:20+00:00 | `374375d090cd43338f46f7fd27f5f5a9` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:32:20+00:00 | `b0441ee4310f4beda91d3440c134ffdf` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:32:24+00:00 | `83993855665c4fa19c2c5cd6949299ed` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:33:37+00:00 | `9e9aac1b81b044208568570983561d32` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:33:42+00:00 | `99f5dba25a2145c49fccd6102bee49b8` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:34:18+00:00 | `f7e8d0cfa75f4dc995036c11f7291007` | 005930 | BUY | 1 | 187400.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2562 regime=high_volatility |
| 2026-03-10T05:43:30+00:00 | `23ccc614a1b448129431308fca608339` | 005930 | BUY | 2 | 70000.0 | - | - |
| 2026-03-10T05:43:30+00:00 | `a3cd208315b44248b2e192a6da262b54` | 005930 | BUY | 2 | 70000.0 | - | - |
| 2026-03-10T05:43:30+00:00 | `2e3a76f175374c97a276550f94d573c0` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:43:30+00:00 | `fbea8f2ebb1b42b3acc0716c6d308729` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:43:30+00:00 | `2dfc569132bf4ef692e7bd132565be82` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:43:30+00:00 | `0361d35220784233ad5aed98b3cda858` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:43:30+00:00 | `3be17a158d7145e28f21ea1fb970084f` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:44:19+00:00 | `c0b481a143a941faa46ca056cd3b4906` | 005930 | BUY | 2 | 70000.0 | - | - |
| 2026-03-10T05:44:41+00:00 | `bb8eec2195cd4fe2a7a06ea30b876f75` | 005930 | SELL | 1 | 186800.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T05:45:57+00:00 | `6a5d6171fc5b4356912c5b928433c36b` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:45:57+00:00 | `8b6d6c6b766341a19ed8dfdbb4ad57d0` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:45:57+00:00 | `374951b98bd845fbad1769108c8e9f45` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:45:57+00:00 | `7ad5cb49f6004dc3a0604f36c774eb36` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:45:57+00:00 | `c1a4703026374ac5b38bd10fc12e54de` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:46:14+00:00 | `87ca63c468614065aa233a5a632b091d` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:46:14+00:00 | `f101df1669e3469ba08484e7c667e14c` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:46:14+00:00 | `610244b3633c4ee2aa44b5afb09eb222` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:46:14+00:00 | `3fa21563a007412aba45f2514cf73a9c` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:46:14+00:00 | `e9740313af5d45058e40f9feb611ae9b` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:46:19+00:00 | `d2a8e3344f5f461c9ec034dce2d6ca4d` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:46:47+00:00 | `84759d38d820489b9aaaf95daeea11f5` | 005930 | BUY | 2 | 187000.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2547 regime=range |
| 2026-03-10T05:47:02+00:00 | `15758fce47d54cf19b40e334ed3fb161` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:47:05+00:00 | `b5e81f94ed7f4542a310fb154e248936` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T05:57:11+00:00 | `2819c10beab442ce832da8c81cefa767` | 005930 | SELL | 2 | 187700.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T05:59:15+00:00 | `7a40f6d925fd4bc98b16fa82631f46cd` | 005930 | BUY | 2 | 187800.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2552 regime=range |
| 2026-03-10T06:02:42+00:00 | `c7a50514e79c4e5aabd90807fe955d92` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:02:42+00:00 | `fc25be2f24104ec09f772a1227b04120` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:02:42+00:00 | `af08f7eb4d5348fba7b6801001264a6b` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:02:43+00:00 | `a60e5cdbd6554eb5bd619fffbc40ebba` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:02:43+00:00 | `07eef55d5d5c41e7b09d338d5b00a924` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:02:47+00:00 | `9a266a2472d14b0fb62c9e3649ac8b92` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:03:31+00:00 | `32ae72104ee0411086a584004ee90e31` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:03:35+00:00 | `d336af1ac5f84304b76cd0556de81c85` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:08:47+00:00 | `0eac4ab8b98d451284069df4043b0c95` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:08:47+00:00 | `0c20df328f5e4d7a9919e9cc58896e62` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:08:47+00:00 | `23073b74cb30458aad6d017cf45fd9f7` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:08:47+00:00 | `9485c23688864509b737113694481893` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:08:47+00:00 | `994ebcc2bf9046d696ea985d9d350f6e` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:08:51+00:00 | `15ab830c665c49a89d86e5cc82f87b1b` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:09:36+00:00 | `4bf3991effc044d59e67899225f55c29` | 005930 | SELL | 2 | 188200.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T06:09:37+00:00 | `f69efa69546c4c559315b41cd4128edc` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:09:41+00:00 | `3654820c7596426795e618a2b31364a3` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:11:42+00:00 | `5acd7734a1f1403ca94c62f3a55dde51` | 005930 | BUY | 2 | 188200.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.2347 regime=range |
| 2026-03-10T06:13:37+00:00 | `f46cfd9d914142859803bfc61a9a7a93` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:13:37+00:00 | `74d6258e77d44634b61aa0f03158a340` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:13:37+00:00 | `64d353c86f5947169c05464bc86cdd55` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:13:37+00:00 | `44efdf7ad15344f1a7c7c2677bf4acca` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:13:37+00:00 | `a74c1edd33c64a0aa65f1f715abf3030` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:13:40+00:00 | `3f92f53413744157962d552b7fe7159e` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:14:24+00:00 | `c40b4bf547ce4d50beafd1ef8e21da7b` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:14:27+00:00 | `1356a84313c04f71864876d7aa89d79d` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:22:04+00:00 | `9712d370b5c84009a3dbe24c47c5eee0` | 005930 | SELL | 2 | 187900.0 | ExitPolicyStrategist | exit_policy:max_hold |
| 2026-03-10T06:28:16+00:00 | `3393cba4635c480abb2d5622b25e943a` | 005930 | BUY | 2 | 187900.0 | RegimeMomentumV1 | strategy_v1_entry: composite=0.0844 regime=range |
| 2026-03-10T06:30:42+00:00 | `37a69f205d00400c832223ab1605126c` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:30:42+00:00 | `edd5ce09b170438abdc6c588260943af` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:30:42+00:00 | `48646ba7fa0a4aa3b6970bfe2f3066ee` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:30:42+00:00 | `81905bc7158c4d3b8fcdf2728476b434` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:30:42+00:00 | `ed5f3bd535ab42a2b6db1bcca80eb6d0` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:30:46+00:00 | `09530b03437a4709841923da4325d717` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:31:30+00:00 | `a936ac500aab4fbe84263dcd12b351cb` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:31:34+00:00 | `a57c31e0a5bf454fa06720575710b3bb` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:32:38+00:00 | `45e4f2f7549d45f89a97dd7e883f409d` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:32:38+00:00 | `4e390ec9441a4d5aa9f37bd8e4912c42` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:32:38+00:00 | `ff41a4b038eb4ecf920054f074f69467` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:32:38+00:00 | `46eb9cc664684b8188be59d581cf63de` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:32:38+00:00 | `e2798a8efda3464e9589e1a25b0b2f4c` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:32:42+00:00 | `898f8b09cf2041318b86e0cd46fe54e8` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:33:19+00:00 | `949febb3bf804a46906aef7340d650ba` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:33:23+00:00 | `1dc66ee2656c4cefb57ea8d56f21e4c5` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:34:15+00:00 | `a68b8fddf5c140e0b0d2d4aa7642dd23` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:34:15+00:00 | `ae3007a810aa43858e419e177a15aec9` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:34:15+00:00 | `7902d1d7fbf94dbf89a3087785c3e931` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:34:15+00:00 | `2e055a9747714522ad7cc0c08e1085c6` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:34:15+00:00 | `4eb8759bb759481ab67238dc74ec6849` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:34:19+00:00 | `f1d632e92d394bc180d0fe18f490c5a5` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:34:53+00:00 | `0e0b007c22f542e0a572018daf2176cd` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:34:57+00:00 | `1d92f2baeee041b6abe9bc55a8799c0b` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:48:19+00:00 | `393098507af24bb286137825f210dca9` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:48:19+00:00 | `a51ed1a030a743ddae339bd7f403dead` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:48:19+00:00 | `2eee3b417267401486ec4f4665ece3a7` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:48:19+00:00 | `ca1e20a4eb7141d9ba177dfc7083c795` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:48:19+00:00 | `3364d577e94a457e9f8a726165aaf103` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:48:23+00:00 | `53d3970206dc433795d0f071be2ccc7b` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:49:07+00:00 | `967ea058fded415c87692e32ea8c5c86` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:49:10+00:00 | `da47108dc9334370856d6c86a8c2edf1` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:51:56+00:00 | `613616f28f874b5fbb931ae6a8fb96f2` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:51:56+00:00 | `af49c32ce4ce44b7869db3915e48d8f6` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:51:56+00:00 | `1ac30d2894be436e8f97d6184e183fbc` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:51:56+00:00 | `01d130feb801424b92e0c14f9452850a` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:51:56+00:00 | `1e1b2bab49854dc0bcb7da0917172f5d` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:52:01+00:00 | `40f39cc98b974b37827c5cbb03d2ce33` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:52:36+00:00 | `21f70755e2e740e481f15f3e0100b97b` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T06:52:40+00:00 | `fbdeaf8ce58348ac8d3ec53a8fdbc892` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T12:54:48+00:00 | `5ad06a961680485f8ef89efb7774f11f` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T12:54:48+00:00 | `baed8e65303c4acfb69ca298968de4c4` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T12:54:48+00:00 | `bb51eb9f5f9c476084fef65b7ba6357b` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T12:54:48+00:00 | `17f4f89c08754c388e587663759d1596` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T12:54:48+00:00 | `3e2ec590b45147088b741bdd7c0e28a2` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T12:55:09+00:00 | `f4cec904226a4319ba91ab298fca7dc6` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T12:56:12+00:00 | `f7476758b6b043ae8e8f8cba76dd269b` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T12:56:16+00:00 | `65a9c74df1334f31bccfca612a75dbc3` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T12:57:44+00:00 | `98b2b27dfd2447d7948630e157cf30b1` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T12:57:44+00:00 | `cc5d3024b4ba44a5b7a92b80c2d51c82` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T12:57:44+00:00 | `3dd82a8c86454e54b5baba9927cc7d5c` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T12:57:44+00:00 | `5ef06f54f45a4140b2bd1736a14c6147` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T12:57:44+00:00 | `a13794eb417847259848499388441836` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T12:57:49+00:00 | `6d911429f82f4378854921034ece48d1` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T12:58:49+00:00 | `3abf585322a24f3488d6d9a123f3b218` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T12:58:55+00:00 | `49c6c1e89e3042168554317aab90739e` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T13:14:12+00:00 | `4c2d8cb0eae1419fb55c47a657cbb586` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T13:14:12+00:00 | `75a459d1edb8404aae4244844060c6ea` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T13:14:12+00:00 | `9e7926952014484ea2a68034ba49376d` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T13:14:12+00:00 | `bbe6156efafc469a8c648c0859578c72` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T13:14:12+00:00 | `fac6169dbb0d431498b89cfc9eefcef3` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T13:14:17+00:00 | `1a395f3b6aca4741985f9572716343db` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T13:14:48+00:00 | `776a7a89fbea4dd8a39ef028ddd13c8a` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T13:14:52+00:00 | `00bba874a4a94a52a523c774e42c48f8` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T13:24:58+00:00 | `1cea1093ba6a4721bebe0405d0598209` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T13:24:58+00:00 | `d4454dd6a1d24a6c8c6f4bc5640a6798` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T13:24:58+00:00 | `4113934d5f9e4074944aeaa6db89deb3` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T13:24:58+00:00 | `53b708e053fc4952b732088ccd9ff80d` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T13:24:58+00:00 | `725f344cc4c34cc385ba8f05fa1322ef` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T13:25:01+00:00 | `ede328c869704d80a46860cbc917d104` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T13:25:33+00:00 | `7744764cdaec44048e2a77cd5af3d40f` | 005930 | BUY | 1 | 70000.0 | - | - |
| 2026-03-10T13:25:57+00:00 | `01656cbc636f4b0cb30d6b2fa2e525d2` | 005930 | BUY | 1 | 70000.0 | - | - |

## Sell Pair Analysis (FIFO, Latest)

### SELL `18c2b1bc5a1d4ac9b88ca6805c4abd11` / 005930
- sell_ts: 2026-03-10T00:02:13+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **62** / estimated_realized_pnl: **-800.0**
- entry_vs_exit_price: entry_avg=187900.0, exit=187100.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=-0.1, global=0.04461909761307881, status=(-, -)
- technical_context: signal_score=0.5, rsi14=52.4907063197026, ma20_gap=0.012528627239660528, volatility20=0.05651006816162046, composite=0.23696763520923997
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['3d81f378160c4fed9bc692915c0ba378']`

### SELL `65219cd36eec46b7a3d254a0010b0a23` / 005930
- sell_ts: 2026-03-10T00:17:46+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **62** / estimated_realized_pnl: **200.0**
- entry_vs_exit_price: entry_avg=187500.0, exit=187700.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=-0.1, global=0.04446283570143613, status=(-, -)
- technical_context: signal_score=0.5, rsi14=53.125, ma20_gap=0.009543551708820708, volatility20=0.03582498165915517, composite=0.23635499391190776
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['f9e2fc3d7bc54d82854f4d3de966f6a8']`

### SELL `73579a1591ec4a8fbd61fa9ec9fda28c` / 005930
- sell_ts: 2026-03-10T00:20:53+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **63** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=187800.0, exit=187800.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=-0.1, global=0.04446283570143613, status=(-, -)
- technical_context: signal_score=0.5, rsi14=56.060606060606055, ma20_gap=0.00841689823204872, volatility20=0.01830326573673543, composite=0.23612966321655335
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['08cda0a38432400d8f31d1591dc92e65']`

### SELL `b22102e64d24487b8f06764941080a27` / 005930
- sell_ts: 2026-03-10T00:25:02+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **64** / estimated_realized_pnl: **1000.0**
- entry_vs_exit_price: entry_avg=187400.0, exit=187900.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=-0.1, global=0.04450817995582823, status=(-, -)
- technical_context: signal_score=0.5, rsi14=67.61904761904762, ma20_gap=0.002286432496757529, volatility20=0.0026250242175061703, composite=0.23490810449493432
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['6acb22e0f6c544df8004c343fb7f1efe']`

### SELL `7301c6f2c97849648135164c3f1e22dc` / 005930
- sell_ts: 2026-03-10T00:29:11+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **62** / estimated_realized_pnl: **200.0**
- entry_vs_exit_price: entry_avg=187800.0, exit=187900.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=-0.1, global=0.04455356248652503, status=(-, -)
- technical_context: signal_score=0.5, rsi14=66.66666666666666, ma20_gap=0.0033793260047818574, volatility20=0.002522337114353752, composite=0.23513122144960885
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['05985d2ab4974d47abe34b52c7318223']`

### SELL `271ed4656dbb4702ad394d3390d80881` / 005930
- sell_ts: 2026-03-10T00:32:20+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **63** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=188300.0, exit=188300.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.0, global=0.04487115812492072, status=(-, -)
- technical_context: signal_score=0.5, rsi14=65.38461538461539, ma20_gap=0.003972168164005252, volatility20=0.0022352140019710103, composite=0.25528154944529313
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['3cf08da38c5543b78ef096e7d3522d06']`

### SELL `8907d620bb8d4c76867309d10505ac8a` / 005930
- sell_ts: 2026-03-10T00:35:26+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **62** / estimated_realized_pnl: **-1600.0**
- entry_vs_exit_price: entry_avg=188200.0, exit=187400.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.0, global=0.04487115812492072, status=(-, -)
- technical_context: signal_score=0.5, rsi14=57.692307692307686, ma20_gap=0.0023167256943519288, volatility20=0.0013503559975870307, composite=0.2549504609513624
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['814d734dbbb24c42a21bd9902966ec77']`

### SELL `60ca4494e57945f1bcd0dd392618a914` / 005930
- sell_ts: 2026-03-10T00:38:35+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **63** / estimated_realized_pnl: **600.0**
- entry_vs_exit_price: entry_avg=188200.0, exit=188500.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.0, global=0.0449669196248767, status=(-, -)
- technical_context: signal_score=0.5, rsi14=56.41025641025641, ma20_gap=0.0016765574686643525, volatility20=0.0016342202486154763, composite=0.2548320034562206
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['4b057edfb35d4ea1819e9f3a76694058']`

### SELL `4a4cd8d8af0c411d80428fd3c92289b1` / 005930
- sell_ts: 2026-03-10T00:41:43+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **64** / estimated_realized_pnl: **1000.0**
- entry_vs_exit_price: entry_avg=188400.0, exit=188900.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.0, global=0.0449669196248767, status=(-, -)
- technical_context: signal_score=0.5, rsi14=60.6060606060606, ma20_gap=0.00223428024257899, volatility20=0.001641135916569475, composite=0.2549435480110035
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['b467a05999934db88ee3649e7ec28b2b']`

### SELL `34825c12fb71494ea2e47e972cb3a017` / 005930
- sell_ts: 2026-03-10T00:45:51+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **63** / estimated_realized_pnl: **300.0**
- entry_vs_exit_price: entry_avg=189850.0, exit=190000.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.0, global=0.044951805515302395, status=(-, -)
- technical_context: signal_score=0.5, rsi14=67.90123456790123, ma20_gap=0.00792376199514222, volatility20=0.0017833592374899938, composite=0.2560799329505587
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['c8fd92cef3374f17b67882e870ce44f7']`

### SELL `f49bb89735cf46299097c7ee8a8a313e` / 005930
- sell_ts: 2026-03-10T00:57:16+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **64** / estimated_realized_pnl: **200.0**
- entry_vs_exit_price: entry_avg=189700.0, exit=189800.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.0, global=0.045163516546286864, status=(-, -)
- technical_context: signal_score=0.5, rsi14=61.11111111111111, ma20_gap=0.0005933935517901112, volatility20=0.00162764281232115, composite=0.2546350303649867
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['5f61f56353064052813f25893e39449f']`

### SELL `980eec326e664b5696fba7d3d4833b65` / 005930
- sell_ts: 2026-03-10T01:13:51+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **63** / estimated_realized_pnl: **-400.0**
- entry_vs_exit_price: entry_avg=189800.0, exit=189600.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.04503749032194598, status=(-, -)
- technical_context: signal_score=0.5, rsi14=51.42857142857142, ma20_gap=0.0015831134564643357, volatility20=0.0014184595449676634, composite=0.27482037172348744
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['74239b6113144caab3e863262560e90f']`

### SELL `ca7341fe10ca4581ad81f4d0b29e3e97` / 005930
- sell_ts: 2026-03-10T01:19:03+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **63** / estimated_realized_pnl: **600.0**
- entry_vs_exit_price: entry_avg=189450.0, exit=189750.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.044987071738952326, status=(-, -)
- technical_context: signal_score=0.5, rsi14=50.87719298245614, ma20_gap=0.0004884939862428439, volatility20=0.0013442144286388887, composite=0.2745964059711438
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['75d7227b1a5341f3b7337eff0d6ababa']`

### SELL `cdba216e794c4049aaa8c14292c8548c` / 005930
- sell_ts: 2026-03-10T01:22:09+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **62** / estimated_realized_pnl: **600.0**
- entry_vs_exit_price: entry_avg=189600.0, exit=189900.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.044987071738952326, status=(-, -)
- technical_context: signal_score=0.5, rsi14=58.92857142857143, ma20_gap=0.0012145535195648982, volatility20=0.0013739524855266349, composite=0.2747416178778082
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['24ecf022f4974ca7bfd5d287e1526c1d']`

### SELL `5104b9fbacd4437aa6188ca82141a583` / 005930
- sell_ts: 2026-03-10T01:25:18+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **63** / estimated_realized_pnl: **200.0**
- entry_vs_exit_price: entry_avg=189900.0, exit=190000.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.04499210976175107, status=(-, -)
- technical_context: signal_score=0.5, rsi14=67.24137931034483, ma20_gap=0.002719328352298156, volatility20=0.0012400499649148381, composite=0.27504307664663474
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['13c7c240229d4b92aebbd22fe283349e']`

### SELL `dcaada65326e4d00a6179201779dcbc5` / 005930
- sell_ts: 2026-03-10T01:30:30+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **63** / estimated_realized_pnl: **-300.0**
- entry_vs_exit_price: entry_avg=189650.0, exit=189500.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.0449669196248767, status=(-, -)
- technical_context: signal_score=0.5, rsi14=52.63157894736841, ma20_gap=0.000422007701640581, volatility20=0.0012305724023143811, composite=0.2745810935028158
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['f959954e58154d5d8661202779a9f895']`

### SELL `a3c2f7faf13a4aae87cc35ff64a76c80` / 005930
- sell_ts: 2026-03-10T01:33:39+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **65** / estimated_realized_pnl: **400.0**
- entry_vs_exit_price: entry_avg=189800.0, exit=190000.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.0449669196248767, status=(-, -)
- technical_context: signal_score=0.5, rsi14=55.932203389830505, ma20_gap=0.0008173165651612635, volatility20=0.0011268165945574368, composite=0.2746601552755199
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['79979b70bd4b4daabc2c2ca7d5fe4086']`

### SELL `3e1585dd1e104efe9c1f090ce330178f` / 005930
- sell_ts: 2026-03-10T01:36:47+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **63** / estimated_realized_pnl: **200.0**
- entry_vs_exit_price: entry_avg=189950.0, exit=190050.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.04477031922038777, status=(-, -)
- technical_context: signal_score=0.5, rsi14=56.86274509803922, ma20_gap=0.0013442631592819332, volatility20=0.0010919122333519708, composite=0.2747458845538952
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['eee4479dfd53430195788cd26dc5c4f0']`

### SELL `a9232aa5ade2466eb61c60892525517f` / 005930
- sell_ts: 2026-03-10T01:39:57+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **63** / estimated_realized_pnl: **-300.0**
- entry_vs_exit_price: entry_avg=189950.0, exit=189800.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.04464428853668908, status=(-, -)
- technical_context: signal_score=0.5, rsi14=51.21951219512195, ma20_gap=0.0008430370409400201, volatility20=0.0010693585203663371, composite=0.274633036261857
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['426c1db12c9341fc89e667de49891809']`

### SELL `68286db051604148b37de0494a593bf3` / 005930
- sell_ts: 2026-03-10T01:43:05+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **63** / estimated_realized_pnl: **-200.0**
- entry_vs_exit_price: entry_avg=190000.0, exit=189900.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.04464428853668908, status=(-, -)
- technical_context: signal_score=0.5, rsi14=62.16216216216216, ma20_gap=0.0008559952591031816, volatility20=0.001005206452101756, composite=0.27463562790548957
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['956d30790f794369ae7ab6d3cb9207b2']`

### SELL `2de3c5001bad47fda40c2b60d777492a` / 005930
- sell_ts: 2026-03-10T01:46:15+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **63** / estimated_realized_pnl: **800.0**
- entry_vs_exit_price: entry_avg=190000.0, exit=190400.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.04466951786282055, status=(-, -)
- technical_context: signal_score=0.5, rsi14=69.23076923076923, ma20_gap=0.0007505629221915555, volatility20=0.0009013519080805097, composite=0.27461706437072037
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['a5e788e27b8a440f9aa00a1887d4b8ec']`

### SELL `0673267227224f078584eeeb1ee11d2d` / 005930
- sell_ts: 2026-03-10T01:49:31+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **71** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=190400.0, exit=190400.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.04466951786282055, status=(-, -)
- technical_context: signal_score=0.5, rsi14=66.66666666666666, ma20_gap=0.0023954302561268737, volatility20=0.0008871072772548621, composite=0.27494603783750743
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['c4445f3691a0494faa71010e3f2169f4']`

### SELL `9f4bc92f08f14ebbb65cdcd98a8d226a` / 005930
- sell_ts: 2026-03-10T01:56:51+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **63** / estimated_realized_pnl: **-800.0**
- entry_vs_exit_price: entry_avg=190800.0, exit=190400.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.04459894483333483, status=(-, -)
- technical_context: signal_score=0.5, rsi14=66.66666666666666, ma20_gap=0.002074525353850998, volatility20=0.0011281802192000146, composite=0.2748747995541037
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['d5642538216140f8835155e269840aef']`

### SELL `8a948c5f4c1e402eb6c39bccdf14b355` / 005930
- sell_ts: 2026-03-10T02:00:00+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **64** / estimated_realized_pnl: **-200.0**
- entry_vs_exit_price: entry_avg=190800.0, exit=190700.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.04459894483333483, status=(-, -)
- technical_context: signal_score=0.5, rsi14=63.333333333333336, ma20_gap=0.00160109189217561, volatility20=0.0012676222744356766, composite=0.2747801128617686
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['7097871385694c0bbf114a76a1ebea02']`

### SELL `1866ccfd781b411cb8bcbbc0a3fd1768` / 005930
- sell_ts: 2026-03-10T02:03:08+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **63** / estimated_realized_pnl: **-600.0**
- entry_vs_exit_price: entry_avg=190600.0, exit=190300.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.044634212174056095, status=(-, -)
- technical_context: signal_score=0.5, rsi14=53.125, ma20_gap=3.935097131324561e-05, volatility20=0.0013087960881788669, composite=0.27447129141166826
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['d9fa1807412b4dcfbf4b9f6622028718']`

### SELL `cf5f56086de3492d96471ce79d0f3a03` / 005930
- sell_ts: 2026-03-10T02:16:43+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **63** / estimated_realized_pnl: **-600.0**
- entry_vs_exit_price: entry_avg=190400.0, exit=190100.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.3, global=0.04476528109709196, status=(-, -)
- technical_context: signal_score=0.5, rsi14=50.0, ma20_gap=0.0005649197945267748, volatility20=0.0011903614186877835, composite=0.3145895120686146
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['03a14a9be7be4f4e8ccc5c6d41a69c9c']`

### SELL `e4ba18041ea84ab9940df434c5e123ef` / 005930
- sell_ts: 2026-03-10T02:19:51+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **63** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=190500.0, exit=190500.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.3, global=0.04476528109709196, status=(-, -)
- technical_context: signal_score=0.5, rsi14=60.0, ma20_gap=0.0012877453943391792, volatility20=0.0011936146854285997, composite=0.31473407718857704
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['349500a29e5c48a49f64f682743c4385']`

### SELL `bf1c52dd0fbe4f2b99a44a20e873baf9` / 005930
- sell_ts: 2026-03-10T02:23:02+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **63** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=190400.0, exit=190400.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.3, global=0.044815700686329916, status=(-, -)
- technical_context: signal_score=0.5, rsi14=59.09090909090909, ma20_gap=0.000841042893187538, volatility20=0.0011985967132354361, composite=0.3146497786472705
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['cefda5d714c34240adfa6313ec858fdb']`

### SELL `683043d2950b493f9c422e3f92ee1754` / 005930
- sell_ts: 2026-03-10T02:26:12+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **65** / estimated_realized_pnl: **300.0**
- entry_vs_exit_price: entry_avg=190300.0, exit=190450.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.3, global=0.044815700686329916, status=(-, -)
- technical_context: signal_score=0.5, rsi14=54.76190476190476, ma20_gap=0.00024966820409710877, volatility20=0.0010777213927314255, composite=0.3145315037094524
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['9b0b6d56bb7741c28498dc1a0608095d']`

### SELL `0c33a7b903654fdc95f9373e31585173` / 005930
- sell_ts: 2026-03-10T02:29:20+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **165** / estimated_realized_pnl: **240800.0**
- entry_vs_exit_price: entry_avg=70000.0, exit=190400.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.3, global=0.04485600542642599, status=(-, -)
- technical_context: signal_score=0.5, rsi14=56.52173913043478, ma20_gap=0.00014452955629429276, volatility20=0.0009765348202178609, composite=0.31451450645390144
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['0551c1da46a44975ab1b1bdd533a2201', 'c0acebeb730b4d9c8ee11047e847bede']`

### SELL `01f8bee29b0642898102a7f1f5cf800a` / 005930
- sell_ts: 2026-03-10T02:51:16+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **1481** / estimated_realized_pnl: **235400.0**
- entry_vs_exit_price: entry_avg=70000.0, exit=187700.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.2, global=0.044780395460147046, status=(-, -)
- technical_context: signal_score=0.2, rsi14=16.666666666666657, ma20_gap=-0.006089747823674774, volatility20=0.0012601912744090165, composite=0.14326008998127976
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['b8701760c29b4bca896ff00ad6512e54', 'f4d93f72251a4eb4b648d38abc9857a2']`

### SELL `57d876df7a30470ea96d9b7a872c7cb0` / 005930
- sell_ts: 2026-03-10T02:54:26+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **1620** / estimated_realized_pnl: **114300.0**
- entry_vs_exit_price: entry_avg=130150.0, exit=187300.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.2, global=0.04470982313145013, status=(-, -)
- technical_context: signal_score=0.2, rsi14=9.259259259259252, ma20_gap=-0.007651777913103341, volatility20=0.0014134358257961938, composite=0.14294062673052438
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['f75cd81c49c54eec81efb96a118b4681', '3783fd8f382947f698abd80c81f79f01']`

### SELL `9dac04aed14b47589536706e12f24bdc` / 005930
- sell_ts: 2026-03-10T02:57:36+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **1581** / estimated_realized_pnl: **113700.0**
- entry_vs_exit_price: entry_avg=130150.0, exit=187000.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.2, global=0.04470982313145013, status=(-, -)
- technical_context: signal_score=0.2, rsi14=9.677419354838719, ma20_gap=-0.007931244860606368, volatility20=0.0011857199233190252, composite=0.14288473334102375
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['3783fd8f382947f698abd80c81f79f01', '98befb135de44610a089bb7f7d416201']`

### SELL `3e220a94805741289991784ad0752cd3` / 005930
- sell_ts: 2026-03-10T03:00:45+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **1592** / estimated_realized_pnl: **234400.0**
- entry_vs_exit_price: entry_avg=70000.0, exit=187200.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.2, global=0.044684632355605436, status=(-, -)
- technical_context: signal_score=0.2, rsi14=11.538461538461533, ma20_gap=-0.007029993754069874, volatility20=0.0009539492197565186, composite=0.14306246448474658
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['4c71c6b404234a8fb4c6a5b21f1efcfa', 'fdce5642f85d4867b23097f70f6c6980']`

### SELL `1ce01bcb65b94788b1f8d389f0a2961a` / 005930
- sell_ts: 2026-03-10T03:07:08+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **1975** / estimated_realized_pnl: **235200.0**
- entry_vs_exit_price: entry_avg=70000.0, exit=187600.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.044548524265492925, status=(-, -)
- technical_context: signal_score=0.5, rsi14=51.807228915662655, ma20_gap=0.0014260392094145313, volatility20=0.0017846291655131512, composite=0.27474006026843223
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['db8120959002426a820abe25d687feda', '487b56dbb1864531bfeaa3d8b2256e2f']`

### SELL `8b1338218bb54f0cbac07d233264861d` / 005930
- sell_ts: 2026-03-10T03:10:18+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **1860** / estimated_realized_pnl: **235200.0**
- entry_vs_exit_price: entry_avg=70000.0, exit=187600.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.044457797439635925, status=(-, -)
- technical_context: signal_score=0.5, rsi14=53.409090909090914, ma20_gap=0.0006800997479630144, volatility20=0.001897741960621199, composite=0.2745817996935562
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['518f4cdd204f475aa5fd0d88f5694293', '919a374534644907b7ce23b657b3c90d']`

### SELL `7f9eaf89255d49a59c6c718413fb5399` / 005930
- sell_ts: 2026-03-10T03:13:28+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **2050** / estimated_realized_pnl: **234400.0**
- entry_vs_exit_price: entry_avg=70000.0, exit=187200.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.044457797439635925, status=(-, -)
- technical_context: signal_score=0.5, rsi14=55.95238095238095, ma20_gap=0.0004401936852214128, volatility20=0.0018496565397697797, composite=0.2745338184810079
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['b25690979fa54a7e96b9a4fd9274d685', 'c17058f6e1f645ce95222e6a6b9d2567']`

### SELL `9fbb4316446f4cbe90071c63c58878d0` / 005930
- sell_ts: 2026-03-10T03:19:45+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **2420** / estimated_realized_pnl: **234400.0**
- entry_vs_exit_price: entry_avg=70000.0, exit=187200.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.044513218194999274, status=(-, -)
- technical_context: signal_score=0.5, rsi14=50.0, ma20_gap=0.00012007845125472372, volatility20=0.001785058141740202, composite=0.2744753375097509
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['aa1200da5cf14055a03b414be73c7b39', '92e8cb9677b54fb89cd215f35b944865']`

### SELL `ca2a605ff17f444ca5da8ddb727f398d` / 005930
- sell_ts: 2026-03-10T03:22:53+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **2551** / estimated_realized_pnl: **236200.0**
- entry_vs_exit_price: entry_avg=70000.0, exit=188100.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.044513218194999274, status=(-, -)
- technical_context: signal_score=0.5, rsi14=57.57575757575758, ma20_gap=0.00336053768602973, volatility20=0.0018748571479707164, composite=0.27512342935670586
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['ec34524f405743e59172e55dff30006d', 'b6e0f3e359ea4c5aaca2c66ab10df7b1']`

### SELL `7c89f988d5824464bbe83474a2fbed41` / 005930
- sell_ts: 2026-03-10T03:26:05+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **2189** / estimated_realized_pnl: **235600.0**
- entry_vs_exit_price: entry_avg=70000.0, exit=187800.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.04448802697650577, status=(-, -)
- technical_context: signal_score=0.5, rsi14=55.357142857142854, ma20_gap=0.002066528898073461, volatility20=0.0015655430549823795, composite=0.2748621084772653
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['59340100b91247fdaed20c391dccbeeb', 'a19bdde3bc304374b867080a1d77a2ce']`

### SELL `be84c5552c5d40c1809f4568f07dc442` / 005930
- sell_ts: 2026-03-10T03:45:54+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **3378** / estimated_realized_pnl: **230200.0**
- entry_vs_exit_price: entry_avg=70000.0, exit=185100.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.04442249108358293, status=(-, -)
- technical_context: signal_score=0.2, rsi14=23.88059701492537, ma20_gap=-0.0059066982762084885, volatility20=0.0013860103105424978, composite=0.1232609094531166
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['842866b8746c40219ae1d046d27d7255', 'ed4240bfc6c2408a82520a51ceba0968']`

### SELL `5c1094a946b14cbe8d504e1595b083fb` / 005930
- sell_ts: 2026-03-10T03:49:02+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **3548** / estimated_realized_pnl: **111200.0**
- entry_vs_exit_price: entry_avg=129050.0, exit=184650.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.04442249108358293, status=(-, -)
- technical_context: signal_score=0.2, rsi14=20.588235294117652, ma20_gap=-0.006724741949772461, volatility20=0.0013833797247811033, composite=0.1230973007184038
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['2eeaf48f79c74835a8dd2cabedbcde9d', 'd41ec995d712434fa2bad4c550b39aa0']`

### SELL `b016fc30fae2492cb2e281902e615715` / 005930
- sell_ts: 2026-03-10T03:52:12+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **3720** / estimated_realized_pnl: **111900.0**
- entry_vs_exit_price: entry_avg=129050.0, exit=185000.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.04437206972259739, status=(-, -)
- technical_context: signal_score=0.2, rsi14=15.0, ma20_gap=-0.0073707429924140255, volatility20=0.0012298682575910711, composite=0.12296305837377695
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['d41ec995d712434fa2bad4c550b39aa0', '170176d90eb04704b7c652f2240e2026']`

### SELL `1159283f2f834a2194ed38d2b4ee800d` / 005930
- sell_ts: 2026-03-10T03:57:28+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **4036** / estimated_realized_pnl: **231400.0**
- entry_vs_exit_price: entry_avg=70000.0, exit=185700.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.04434687818751652, status=(-, -)
- technical_context: signal_score=0.5, rsi14=53.94736842105263, ma20_gap=0.002856065096729088, volatility20=0.0015436599587019574, composite=0.2750059008380975
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['de63649b77ff4734908f9d758b3a9266', 'c78d956f83a14475b069b786edf7d3be']`

### SELL `135f3072a8824e52aabe43d5a3d07852` / 005930
- sell_ts: 2026-03-10T04:00:38+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **4226** / estimated_realized_pnl: **230800.0**
- entry_vs_exit_price: entry_avg=70000.0, exit=185400.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.04434687818751652, status=(-, -)
- technical_context: signal_score=0.5, rsi14=50.724637681159415, ma20_gap=0.0008628127696290733, volatility20=0.0015486502778528854, composite=0.2746072503726775
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['42f7b91763fe4eb2a0694f8c7538ae3a', '92928ff1de3f47bf8eb36e7c70d48d39']`

### SELL `6a90d4ecea5f4aee919af57cb2ec0a42` / 005930
- sell_ts: 2026-03-10T04:08:59+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **4696** / estimated_realized_pnl: **232000.0**
- entry_vs_exit_price: entry_avg=70000.0, exit=186000.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.04431195822271639, status=(-, -)
- technical_context: signal_score=0.5, rsi14=53.125, ma20_gap=0.0028216170971095966, volatility20=0.0018173599767611663, composite=0.2749955192416936
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['81704de8eb2c4079abb3f536a0140c46', 'e003a8daaa4b4f1e9c71d1d0eb913cba']`

### SELL `f2bae0791b8540ec92ac8e02647ed6ea` / 005930
- sell_ts: 2026-03-10T04:13:11+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **4853** / estimated_realized_pnl: **115400.0**
- entry_vs_exit_price: entry_avg=128700.0, exit=186400.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.045191784276121104, status=(-, -)
- technical_context: signal_score=0.5, rsi14=57.57575757575758, ma20_gap=0.00423374592131176, volatility20=0.0018722373503453921, composite=0.2753659276118745
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['819b1b495f8346da9aceb567269ebb61', 'b45394901fe34cacba4b1fb6d8817a4e']`

### SELL `2b76bbad49044f99847e777fdefd59e6` / 005930
- sell_ts: 2026-03-10T04:16:23+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **4886** / estimated_realized_pnl: **-1400.0**
- entry_vs_exit_price: entry_avg=187200.0, exit=186500.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.1, global=0.045191784276121104, status=(-, -)
- technical_context: signal_score=0.5, rsi14=61.76470588235294, ma20_gap=0.0034355001684067688, volatility20=0.0017442700778376734, composite=0.2752062784612935
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['b45394901fe34cacba4b1fb6d8817a4e', 'f90e125a26d04afd9d1e79cfe1718045']`

### SELL `ea0b9ef630894292b45b41ffaaf92ddd` / 005930
- sell_ts: 2026-03-10T04:23:41+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **5134** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=186900.0, exit=186900.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.0, global=0.04523703869809651, status=(-, -)
- technical_context: signal_score=0.5, rsi14=66.66666666666666, ma20_gap=0.004719708480684259, volatility20=0.0016000779920797728, composite=0.25546764556594653
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['f90e125a26d04afd9d1e79cfe1718045', 'e8519584a575455798fe69f0a1b8eb39']`

### SELL `8797859e93574010bbef3d1fa456ce3e` / 005930
- sell_ts: 2026-03-10T04:46:17+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **6395** / estimated_realized_pnl: **0.0**
- entry_vs_exit_price: entry_avg=186800.0, exit=186800.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.0, global=0.04538796219564045, status=(ok, ok)
- technical_context: signal_score=-0.5, rsi14=48.68525896414342, ma20_gap=-0.00978027511993429, volatility20=0.055407596792361444, composite=None
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['e8519584a575455798fe69f0a1b8eb39']`

### SELL `e2c59445d5524c2bb941de31d1f46bb4` / 005930
- sell_ts: 2026-03-10T05:10:10+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **7445** / estimated_realized_pnl: **-50.0**
- entry_vs_exit_price: entry_avg=187850.0, exit=187800.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.0, global=0.0455036867195699, status=(-, -)
- technical_context: signal_score=0.5, rsi14=56.666666666666664, ma20_gap=0.005019729954634622, volatility20=0.03510955178589533, composite=0.2555543146628839
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['644fc8489a0f4c69a0233dcf42759d61']`

### SELL `f6da291d03c54a4499964f7dd3be38d7` / 005930
- sell_ts: 2026-03-10T05:22:50+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **8110** / estimated_realized_pnl: **-650.0**
- entry_vs_exit_price: entry_avg=187725.0, exit=187400.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.0, global=0.045644550412061544, status=(ok, ok)
- technical_context: signal_score=-0.5, rsi14=47.71986970684039, ma20_gap=-0.012540836758351825, volatility20=0.055433505063291616, composite=None
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['644fc8489a0f4c69a0233dcf42759d61', '042ac78d298243ecb0f50d1a06d64c21']`

### SELL `bb8eec2195cd4fe2a7a06ea30b876f75` / 005930
- sell_ts: 2026-03-10T05:44:41+00:00
- qty: sell=1, matched=1, unmatched=0
- hold_duration_sec_avg: **9326** / estimated_realized_pnl: **-800.0**
- entry_vs_exit_price: entry_avg=187600.0, exit=186800.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.0, global=0.04573509371851833, status=(-, -)
- technical_context: signal_score=0.5, rsi14=50.0, ma20_gap=0.007987521179033452, volatility20=0.04417725511246429, composite=0.25617101360765854
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['042ac78d298243ecb0f50d1a06d64c21']`

### SELL `2819c10beab442ce832da8c81cefa767` / 005930
- sell_ts: 2026-03-10T05:57:11+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **9888** / estimated_realized_pnl: **400.0**
- entry_vs_exit_price: entry_avg=187500.0, exit=187700.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.0, global=0.045664662682324816, status=(-, -)
- technical_context: signal_score=0.5, rsi14=50.0, ma20_gap=0.00048151516772776404, volatility20=0.0009553413833804787, composite=0.25466276930177806
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['75d908ead2314b2cb5e2eb0cf815286c']`

### SELL `4bf3991effc044d59e67899225f55c29` / 005930
- sell_ts: 2026-03-10T06:09:36+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **10254** / estimated_realized_pnl: **1600.0**
- entry_vs_exit_price: entry_avg=187400.0, exit=188200.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=0.0, global=0.04556909068664554, status=(-, -)
- technical_context: signal_score=0.5, rsi14=69.23076923076923, ma20_gap=0.003191730879662291, volatility20=0.001070807900514514, composite=0.255195255244597
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['2cca93aafe604561afd533bd4c73001c']`

### SELL `9712d370b5c84009a3dbe24c47c5eee0` / 005930
- sell_ts: 2026-03-10T06:22:04+00:00
- qty: sell=2, matched=2, unmatched=0
- hold_duration_sec_avg: **10814** / estimated_realized_pnl: **-400.0**
- entry_vs_exit_price: entry_avg=188100.0, exit=187900.0
- strategy: ExitPolicyStrategist
- sell_reason: exit_policy:max_hold
- scanner_context: source=-, top_stock=-, top_score=None
- sentiment_context: symbol=-0.1, global=0.045906160558506735, status=(-, -)
- technical_context: signal_score=0.5, rsi14=61.904761904761905, ma20_gap=0.0004252604720391684, volatility20=0.0011467777853441641, composite=0.2346756681502585
- monitor_context: exit_reason=-, monitor_reason=-
- matched_buy_runs: `['07dd60bc7a0a4f549deaae07896b3f2c']`

## Data Gaps

- scanner_score_breakdown_missing_total: 272
- news_items_missing_total: 290
- note: news headline text and scanner score_breakdown are limited by current event-log payload policy.
