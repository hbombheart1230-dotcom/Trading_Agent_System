# Off-Hours Full Trace Bundle (7a6b4ecc50d54bd48ad79ff82dbe3175)

- ts: `2026-03-13T11:10:02.594861+00:00`
- day: **2026-03-13**
- symbol_hint: ``
- decision: **approve** reason=`within_policy`

## Strategist
- news_source: **naver**
- news_query_targets: `["코스피", "미국 증시", "국제유가", "환율", "중동", "달러", "방산", "금"]`
- news_query_reasoning: global_score=-0.18 macro_risk=0.00 index_trend=0.00 vix=26.30 vix_pressure=0.315; elevated fear index added defensive macro and hedge queries
- news_sample_titles: `["[증권가] NH투자증권 하나증권 한화투자증권 SK증권 토스증권", "<b>코스피</b>, 외인 기관 순매도세에 하락마감", "국민의힘, “사법파괴·공소취소 거래, 이재명 정권 탄핵 사유” 파상공...", "[주식마감] 오픈AI와 전략적 파트너십 체결 소식에 폴라리스오피스 상한...", "삼중고 거시 악재에도 7만 1,000달러 버틴 비트코인, 진정한 안전 자산 ..."]`
- global_sentiment: score=-0.17943917530804798 status=ok source=yfinance
- global_index_moves: `{"sp500_pct": -1.5227676506708532, "nasdaq_pct": -1.7791339252573701, "dow_pct": -1.559385380178191}`
- fear_index: `{"provider": "yfinance", "ticker": "^VIX", "level": 26.299999237060547, "change_pct": -3.6277084838920226, "neutral_level": 20.0, "level_pressure": 0.31499996185302737}`
- llm_model: `minimax/minimax-m2.5` ok=True
- themes: `["broad_market_leaders", "defensive_sectors", "large_cap_quality", "defensive_assets"]`
- playbook: **defensive**
- scanner_source_policy: `{"preferred_sources": ["top_value", "sector_theme", "top_volume", "operator_watchlist"], "include_top_value": true, "include_top_volume": true, "include_change_rate": false, "include_condition_search": false, "include_sector_candidates": true, "include_watchlist": true, "top_candidate_pool": 18, "condition_limit": 0, "source_weights": {"top_value": 2.3, "top_volume": 1.9, "condition_search": 0.0, "sector_theme": 1.9, "operator_watchlist": 1.1, "top_change_rate": 0.0}, "reason": "defensive frame prioritizes liquid leaders and suppresses fast-mover sources; elevated fear index (vix=26.30, pressure=0.315) shifted source policy toward liquid defensive candidates"}`

## Scanner
- candidate_source: **kiwoom_market_data**
- kiwoom_source_mix: `{"top_value": 18, "top_volume": 18, "top_change_rate": 0, "condition_search": 0, "sector_theme": 5, "operator_watchlist": 0}`
- scanner_source_policy: `{"include_top_value": true, "include_top_volume": true, "include_change_rate": false, "include_condition_search": false, "include_sector_candidates": true, "include_watchlist": true, "top_candidate_pool": 18, "condition_limit": 0, "preferred_sources": ["top_value", "sector_theme", "top_volume", "operator_watchlist"], "source_weights": {"top_value": 2.3, "top_volume": 1.9, "condition_search": 0.0, "sector_theme": 1.9, "operator_watchlist": 1.1, "top_change_rate": 0.0}, "reason": "defensive frame prioritizes liquid leaders and suppresses fast-mover sources; elevated fear index (vix=26.30, pressure=0.315) shifted source policy toward liquid defensive candidates"}`
- top_stock: **032820** top_score=1.2298781773136505
- selected_candidate: `{"symbol": "032820", "why": "top_value+top_volume+sector_theme", "sources": ["top_value", "top_volume", "sector_theme"], "source_scores": {"top_value": 2.2399999999999998, "top_volume": 1.74, "sector_theme": 1.9}, "rank_score": 1.0, "universe_score": 5.879999999999999, "score_total": 1.2298781773136505, "risk_score": 0.17418783506160962, "confidence": 0.9030983142266683, "score_breakdown": {"trading_value": 0.21600000000000003, "momentum": 0.0, "trend": 0.0, "ma_alignment": 0.0, "adx_trend": 0.0, "volume_surge": 0.0, "intraday_strength": 0.0, "vwap_alignment": 0.0, "theme_boost": 0.067392, "sentiment": 0.000970094844455136, "cross_section_rank": 0.0, "avoid_theme_penalty": -0.0, "risk_penalty": -0.0, "rank_bonus": 0.01}, "feature_snapshot": {"quote_trading_value": 0.0, "quote_volume": 0.0, "intraday_change_pct": 0.0, "skill_quote_price": null, "engine_ma20_gap": null, "engine_ma60": null, "engine_ma120": null, "engine_adx14": null, "engine_trend_strength": null, "engine_volume_spike20": null, "engine_volatility20": null, "engine_vwap_distance": null, "engine_sector_relative_strength": null, "engine_cross_section_rank": null, "engine_regime": null, "engine_signal_score": 0.0}, "component_snapshot": {"news_sentiment": 0.1, "global_sentiment": -0.17943917530804798, "trading_value_component": 1.0, "momentum_component": 0.0, "trend_component": 0.0, "volume_surge_component": 0.0, "intraday_strength_component": 0.0, "theme_boost_component": 1.0, "sentiment_component": 0.0161682474075856, "volatility_penalty_component": 0.0, "gap_penalty_component": 0.0, "avoid_theme_penalty_component": 0.0}}`

## Monitor
- entry_reason=`no_position` exit_reason=`no_position` monitor_reason=`no_position`
- thresholds: `{"stop_loss_pct": 0.005210438400000001, "take_profit_pct": 0.005939899776, "max_hold_sec": 0, "time_stop_sec": 0, "trailing_stop_pct": 0.005200000000000001, "vol_expansion_ratio": 1.6, "news_shock_threshold": 0.0, "eod_flat_cutoff_min": 10}` min_hold=600 cooldown=300 confirm=3

## Execution
- action=BUY symbol=032820 qty=1 mode=mock ok=True
- execution_mode=mock kiwoom_mode=mock broker_env=mock effective_mode=mock_executor

## Reporter
- improvement_suggestions: `["No critical gaps detected; keep current baseline and continue daily report-driven calibration."]`
- next_learning_focus: `["exit_quality", "overtrading", "theme_accuracy"]`

## Artifacts
- event_log_path: `C:\Trading_Agent_System\data\logs\dev\analysis\offhours\offhours_vix_source_policy_check.jsonl`
- evidence_log_path: `C:\Trading_Agent_System\data\evidence_ledger\offhours_vix_source_policy_check.jsonl`
- state_path: `C:\Trading_Agent_System\data\state\offhours_vix_source_policy_check.json`
- agent_pipeline_trace_json: `C:\Trading_Agent_System\reports\dev\analysis\offhours_vix_source_policy_check\agent_pipeline_trace\agent_pipeline_trace_7a6b4ecc50d54bd48ad7.json`
- agent_pipeline_trace_md: `C:\Trading_Agent_System\reports\dev\analysis\offhours_vix_source_policy_check\agent_pipeline_trace\agent_pipeline_trace_7a6b4ecc50d54bd48ad7.md`
- trade_explain_json: `C:\Trading_Agent_System\reports\dev\analysis\offhours_vix_source_policy_check\trade_explain\trade_explain_2026-03-13.json`
- trade_explain_md: `C:\Trading_Agent_System\reports\dev\analysis\offhours_vix_source_policy_check\trade_explain\trade_explain_2026-03-13.md`
- reporter_analysis_json: `C:\Trading_Agent_System\reports\dev\analysis\offhours_vix_source_policy_check\reporter_analysis\reporter_analysis_2026-03-13.json`
- reporter_analysis_md: `C:\Trading_Agent_System\reports\dev\analysis\offhours_vix_source_policy_check\reporter_analysis\reporter_analysis_2026-03-13.md`
