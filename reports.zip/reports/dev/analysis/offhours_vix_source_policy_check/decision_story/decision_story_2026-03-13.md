# Decision Story Report (2026-03-13)

- story_total: **1**
- rendered_story_total: **1**

## Run 7a6b4ecc50d54bd48ad79ff82dbe3175

- run_id: `7a6b4ecc50d54bd48ad79ff82dbe3175`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.005210438400000001, take_profit_pct=0.005939899776, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.005200000000000001, vol_expansion_ratio=1.6
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed
