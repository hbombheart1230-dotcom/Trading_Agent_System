# Live Execution Bundle (5d4d2cd0542046f6a8ec76240e225e98)

- day: **2026-03-16**
- execution: **BUY 032820 x1** status=`모의투자 매수주문완료` ord_no=`0130409`
- execution_ts: `2026-03-16T03:41:51+00:00`

## Strategist
- playbook: **pullback** themes=`["broad_market_leaders"]`
- market context: sentiment=-0.17140001694449794 vix=`{"provider": "yfinance", "ticker": "^VIX", "level": 27.190000534057617, "change_pct": -0.36643597696923713, "neutral_level": 20.0, "level_pressure": 0.35950002670288084}`
- news_query_reasoning: global_score=-0.17 macro_risk=0.00 index_trend=0.00 vix=27.19 vix_pressure=0.360; elevated fear index added defensive macro and hedge queries

## Scanner
- top_stock: **032820** top_score=1.5421810206751765 pool_after=5
- selected_candidate: `{"symbol": "032820", "why": "top_value+top_volume+sector_theme", "sources": ["top_value", "top_volume", "sector_theme"], "source_scores": {"top_value": 2.2199999999999998, "top_volume": 1.7, "sector_theme": 1.8199999999999998}, "rank_score": 1.0, "universe_score": 5.74, "score_total": 1.5421810206751765, "risk_score": 0.6225800033888995, "confidence": 0.8786231533554439, "score_breakdown": {"trading_value": 0.22000000000000003, "momentum": 0.209, "trend": 0.12673028267462688, "ma_alignment": 0.04284070560000001, "adx_trend": 0.04519260322388059, "volume_surge": 0.0, "intraday_strength": 0.05987394, "vwap_alignment": 0.03591, "theme_boost": 0.067392, "sentiment": 0.010144799694999035, "cross_section_rank": 0.05, "avoid_theme_penalty": -0.0, "repeat_symbol_penalty": -0.0, "risk_penalty": -0.16, "rank_bonus": 0.01}, "feature_snapshot": {"quote_trading_value": 723023507375.0, "quote_volume": 28268190.0, "intraday_change_pct": 1.43, "skill_quote_price": 24800.0, "engine_ma20_gap": 0.43125090174577974, "engine_ma60": null, "engine_ma120": null, "engine_adx14": 31.6146540027137, "engine_trend_strength": 0.316146540027137, "engine_volume_spike20": 2.5629423463889422e-08, "engine_volatility20": 0.12420912558660366, "engine_vwap_distance": 0.9452617773855378, "engine_sector_relative_strength": 1.5452080230006364, "engine_cross_section_rank": 1.0, "engine_regime": "high_volatility", "engine_signal_score": 0.0}, "component_snapshot": {"news_sentiment": 0.315, "global_sentiment": -0.17140001694449794, "trading_value_component": 1.0, "momentum_component": 1.0, "trend_component": 0.4659124830393487, "volume_surge_component": 0.0, "intraday_strength_component": 0.5002, "theme_boost_component": 1.0, "sentiment_component": 0.1690799949166506, "volatility_penalty_component": 1.0, "gap_penalty_component": 0.0, "avoid_theme_penalty_component": 0.0}}`

## Monitor
- selected_symbol=032820 entry_reason=no_position exit_reason=no_position monitor_reason=no_position
- thresholds: `{"stop_loss_pct": 0.08, "take_profit_pct": 0.008791595366400002, "max_hold_sec": 0, "time_stop_sec": 0, "trailing_stop_pct": 0.04, "vol_expansion_ratio": 2.0, "news_shock_threshold": 0.0, "eod_flat_cutoff_min": 10}`

## Reporter
- reporter_analysis_found=True day_file_found=True
- reporter_analysis_path: `reports\dev\analysis\reporter_analysis\reporter_analysis_2026-03-16.json`

## Artifacts
- agent_pipeline_trace_json: `reports\dev\analysis\live_execution_bundles\agent_pipeline_trace\agent_pipeline_trace_5d4d2cd0542046f6a8ec.json`
- agent_pipeline_trace_md: `reports\dev\analysis\live_execution_bundles\agent_pipeline_trace\agent_pipeline_trace_5d4d2cd0542046f6a8ec.md`
- trade_explain_json: `reports\dev\analysis\trade_explain\trade_explain_2026-03-16.json`
- trade_explain_md: `reports\dev\analysis\trade_explain\trade_explain_2026-03-16.md`
- reporter_analysis_json: `reports\dev\analysis\reporter_analysis\reporter_analysis_2026-03-16.json`
- reporter_analysis_md: `reports\dev\analysis\reporter_analysis\reporter_analysis_2026-03-16.md`
- operator_summary_json: `reports\operator_summary\operator_summary_2026-03-16.json`
- operator_summary_md: `reports\operator_summary\operator_summary_2026-03-16.md`
