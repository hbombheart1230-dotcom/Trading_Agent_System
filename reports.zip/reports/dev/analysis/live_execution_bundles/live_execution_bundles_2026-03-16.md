# Live Execution Bundles (2026-03-16)

- bundle_count: **12**
- event_log_path: `data\logs\events.jsonl`
- evidence_log_path: `data\evidence_ledger\events.jsonl`

## Bundles

- `ebcda2b4ece048869d706d6a429f5119` SELL 032820 x1 status=`모의투자 매도주문완료` json=`reports\dev\analysis\live_execution_bundles\live_execution_bundle_ebcda2b4ece048869d706d6a429f5119.json`
- `686da792538349b09be06cb0b29df0bf` BUY 032820 x1 status=`모의투자 매수주문완료` json=`reports\dev\analysis\live_execution_bundles\live_execution_bundle_686da792538349b09be06cb0b29df0bf.json`
- `0b219084146245f2bcc84851cd256060` SELL 032820 x1 status=`모의투자 매도주문완료` json=`reports\dev\analysis\live_execution_bundles\live_execution_bundle_0b219084146245f2bcc84851cd256060.json`
- `c5721c16e34543128d1f02c37d232c61` BUY 032820 x1 status=`모의투자 매수주문완료` json=`reports\dev\analysis\live_execution_bundles\live_execution_bundle_c5721c16e34543128d1f02c37d232c61.json`
- `ef9ff875f1d4481f9da0d8c2095773c4` SELL 032820 x1 status=`모의투자 매도주문완료` json=`reports\dev\analysis\live_execution_bundles\live_execution_bundle_ef9ff875f1d4481f9da0d8c2095773c4.json`
- `7071ddcc326c4ec0b811e5f415f27d22` BUY 032820 x1 status=`모의투자 매수주문완료` json=`reports\dev\analysis\live_execution_bundles\live_execution_bundle_7071ddcc326c4ec0b811e5f415f27d22.json`
- `629f47f568ac4be48f7c7fb5050be3b2` SELL 032820 x1 status=`모의투자 매도주문완료` json=`reports\dev\analysis\live_execution_bundles\live_execution_bundle_629f47f568ac4be48f7c7fb5050be3b2.json`
- `11d29b9d669740f0bf195523fc064ed0` BUY 032820 x1 status=`모의투자 매수주문완료` json=`reports\dev\analysis\live_execution_bundles\live_execution_bundle_11d29b9d669740f0bf195523fc064ed0.json`
- `ad5f06c28a664e79ae6a8640ed4b49a2` SELL 032820 x1 status=`모의투자 매도주문완료` json=`reports\dev\analysis\live_execution_bundles\live_execution_bundle_ad5f06c28a664e79ae6a8640ed4b49a2.json`
- `13d6b1fc402f490d8c79d12d1f2203c4` BUY 032820 x1 status=`모의투자 매수주문완료` json=`reports\dev\analysis\live_execution_bundles\live_execution_bundle_13d6b1fc402f490d8c79d12d1f2203c4.json`
- `85e8b128f35541aa84d7b8b9ece0d8f0` SELL 032820 x1 status=`모의투자 매도주문완료` json=`reports\dev\analysis\live_execution_bundles\live_execution_bundle_85e8b128f35541aa84d7b8b9ece0d8f0.json`
- `5d4d2cd0542046f6a8ec76240e225e98` BUY 032820 x1 status=`모의투자 매수주문완료` json=`reports\dev\analysis\live_execution_bundles\live_execution_bundle_5d4d2cd0542046f6a8ec76240e225e98.json`
