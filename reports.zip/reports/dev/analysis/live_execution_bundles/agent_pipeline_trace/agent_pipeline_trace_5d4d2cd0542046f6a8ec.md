# Agent Pipeline Trace (5d4d2cd0542046f6a8ec76240e225e98)

- day: **2026-03-16**
- event_log_path: `data\logs\events.jsonl`
- evidence_log_path: `data\evidence_ledger\events.jsonl`

## Commander
- mode: **integrated_chain**
- agents: `["commander_router", "strategist", "scanner", "monitor", "decision", "supervisor", "executor", "reporter"]`
- route_ts: `2026-03-16T03:40:47+00:00`
- end_status: **ok**

## Strategist
- news_source: **naver** headlines=60 symbols=12
- news_query_targets: `["코스피", "미국 증시", "국제유가", "환율", "중동", "달러", "방산", "금"]`
- news_query_reasoning: global_score=-0.17 macro_risk=0.00 index_trend=0.00 vix=27.19 vix_pressure=0.360; elevated fear index added defensive macro and hedge queries
- global_sentiment: score=-0.1714 status=ok source=yfinance
- global_index_moves: `{"sp500_pct": -0.6059115470564369, "nasdaq_pct": -0.9260544757082045, "dow_pct": -0.255759013115997}`
- fear_index: `{"provider": "yfinance", "ticker": "^VIX", "level": 27.190000534057617, "change_pct": -0.36643597696923713, "neutral_level": 20.0, "level_pressure": 0.35950002670288084}`
- macro_stress: active=True flags=`["elevated_vix", "dollar_strength"]` reason=`vix=27.19 pressure=0.360 dxy_pct=0.76 tnx_delta=0.0012`
- llm: provider=openrouter model=minimax/minimax-m2.5 ok=True latency_ms=6335
- llm_prompt_captured: **True**
- llm_response_captured: **False**
- themes: `["broad_market_leaders"]`
- playbook: **pullback**
- scanner_source_policy: `{"preferred_sources": ["top_value", "sector_theme", "top_volume", "operator_watchlist"], "include_top_value": true, "include_top_volume": true, "include_change_rate": false, "include_condition_search": false, "include_sector_candidates": true, "include_watchlist": true, "top_candidate_pool": 18, "condition_limit": 0, "source_weights": {"top_value": 2.3, "top_volume": 1.9, "condition_search": 0.0, "sector_theme": 1.9, "operator_watchlist": 1.1, "top_change_rate": 0.0}, "reason": "defensive frame prioritizes liquid leaders and suppresses fast-mover sources; elevated fear index (vix=27.19, pressure=0.360) shifted source policy toward liquid defensive candidates"}`
- news_sample_titles: `["트럼프가 휘젓는 유가·환율…<b>코스피</b> 약보합 전환", "NewsItem(title=\"연금경제ㅣ수익률 경쟁은 그만, '목표'로 투자하라\", url='http://www.globalepic.co.kr/view.php?ud=202603160950369817d55156af31_", "신한투자증권, 중개형ISA 3조 돌파 기념 이벤트", "日 <b>증시</b>, 100달러대 유가에 하락 출발", "<b>미국</b>의 이란 하그르섬 공격에도 국제유가 하락 반전한 이유"]`

## Scanner
- candidate_source: **kiwoom_market_data**
- pool: before=5 after=5
- kiwoom_source_mix: `{"top_value": 17, "top_volume": 18, "top_change_rate": 0, "condition_search": 0, "sector_theme": 5, "operator_watchlist": 0}`
- condition_search: status=disabled source=disabled reason=condition_search_baseline_disabled
- scanner_source_policy: `{"include_top_value": true, "include_top_volume": true, "include_change_rate": false, "include_condition_search": false, "include_sector_candidates": true, "include_watchlist": true, "top_candidate_pool": 18, "condition_limit": 0, "preferred_sources": ["top_value", "sector_theme", "top_volume", "operator_watchlist"], "source_weights": {"top_value": 2.3, "top_volume": 1.9, "condition_search": 0.0, "sector_theme": 1.9, "operator_watchlist": 1.1, "top_change_rate": 0.0}, "reason": "defensive frame prioritizes liquid leaders and suppresses fast-mover sources; elevated fear index (vix=27.19, pressure=0.360) shifted source policy toward liquid defensive candidates"}`
- top_stock: **032820** top_score=1.5421810206751765
- top_ranked_symbols: `["032820", "005930", "000660", "069500", "122630"]`
- score_breakdown_summary: `{"trading_value": 0.22000000000000003, "momentum": 0.209, "trend": 0.12673028267462688, "ma_alignment": 0.04284070560000001, "adx_trend": 0.04519260322388059, "volume_surge": 0.0, "intraday_strength": 0.05987394, "vwap_alignment": 0.03591, "theme_boost": 0.067392, "sentiment": 0.010144799694999035, "cross_section_rank": 0.05, "avoid_theme_penalty": -0.0, "repeat_symbol_penalty": -0.0, "risk_penalty": -0.16, "rank_bonus": 0.01}`
- selected_candidate: `{"symbol": "032820", "why": "top_value+top_volume+sector_theme", "sources": ["top_value", "top_volume", "sector_theme"], "source_scores": {"top_value": 2.2199999999999998, "top_volume": 1.7, "sector_theme": 1.8199999999999998}, "rank_score": 1.0, "universe_score": 5.74, "score_total": 1.5421810206751765, "risk_score": 0.6225800033888995, "confidence": 0.8786231533554439, "score_breakdown": {"trading_value": 0.22000000000000003, "momentum": 0.209, "trend": 0.12673028267462688, "ma_alignment": 0.04284070560000001, "adx_trend": 0.04519260322388059, "volume_surge": 0.0, "intraday_strength": 0.05987394, "vwap_alignment": 0.03591, "theme_boost": 0.067392, "sentiment": 0.010144799694999035, "cross_section_rank": 0.05, "avoid_theme_penalty": -0.0, "repeat_symbol_penalty": -0.0, "risk_penalty": -0.16, "rank_bonus": 0.01}, "feature_snapshot": {"quote_trading_value": 723023507375.0, "quote_volume": 28268190.0, "intraday_change_pct": 1.43, "skill_quote_price": 24800.0, "engine_ma20_gap": 0.43125090174577974, "engine_ma60": null, "engine_ma120": null, "engine_adx14": 31.6146540027137, "engine_trend_strength": 0.316146540027137, "engine_volume_spike20": 2.5629423463889422e-08, "engine_volatility20": 0.12420912558660366, "engine_vwap_distance": 0.9452617773855378, "engine_sector_relative_strength": 1.5452080230006364, "engine_cross_section_rank": 1.0, "engine_regime": "high_volatility", "engine_signal_score": 0.0}, "component_snapshot": {"news_sentiment": 0.315, "global_sentiment": -0.17140001694449794, "trading_value_component": 1.0, "momentum_component": 1.0, "trend_component": 0.4659124830393487, "volume_surge_component": 0.0, "intraday_strength_component": 0.5002, "theme_boost_component": 1.0, "sentiment_component": 0.1690799949166506, "volatility_penalty_component": 1.0, "gap_penalty_component": 0.0, "avoid_theme_penalty_component": 0.0}}`

## Monitor
- selected_symbol: **032820**
- entry_reason=no_position exit_reason=no_position monitor_reason=no_position
- position_age_seconds=1697 min_hold_blocked=False sell_cooldown_blocked=False
- thresholds: `{"stop_loss_pct": 0.08, "take_profit_pct": 0.008791595366400002, "max_hold_sec": 0, "time_stop_sec": 0, "trailing_stop_pct": 0.04, "vol_expansion_ratio": 2.0, "news_shock_threshold": 0.0, "eod_flat_cutoff_min": 10}` min_hold=600 sell_cooldown=300 confirm_ticks=2
- strategy_frame_adjustments: `["monitor_guidance:defensive_exit", "risk_tone:conservative"]`

## Supervisor
- verdict=approve allow=True reason=Allowed

## Executor
- execution_attempted=True ok=True broker_code=0
- execution_mode=real kiwoom_mode=mock broker_env=mock effective_mode=mock_broker_http
- api_id=ORDER_SUBMIT url=https://mockapi.kiwoom.com/api/dostk/ordr action=BUY symbol=032820 qty=1

## Reporter
- in_run_trace_available: **False**
- reporter_analysis_day_file_found: **True**
- reporter_analysis_found: **True**
- reporter_analysis_path: `reports\dev\analysis\reporter_analysis\reporter_analysis_2026-03-16.json`

## Next Command
- `python scripts/run_agent_pipeline_trace_report.py --run-id 5d4d2cd0542046f6a8ec76240e225e98 --json`
- `python scripts/query_trade_reason_chain.py --run-id 5d4d2cd0542046f6a8ec76240e225e98 --only-broker-success`