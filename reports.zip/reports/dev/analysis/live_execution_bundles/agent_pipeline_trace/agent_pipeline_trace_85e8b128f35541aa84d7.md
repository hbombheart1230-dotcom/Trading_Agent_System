# Agent Pipeline Trace (85e8b128f35541aa84d7b8b9ece0d8f0)

- day: **2026-03-16**
- event_log_path: `data\logs\events.jsonl`
- evidence_log_path: `data\evidence_ledger\events.jsonl`

## Commander
- mode: **integrated_chain**
- agents: `["commander_router", "strategist", "scanner", "monitor", "decision", "supervisor", "executor", "reporter"]`
- route_ts: `2026-03-16T02:55:27+00:00`
- end_status: **ok**

## Strategist
- news_source: **naver** headlines=60 symbols=12
- news_query_targets: `["코스피", "미국 증시", "국제유가", "환율", "중동", "달러", "방산", "금"]`
- news_query_reasoning: global_score=-0.17 macro_risk=0.00 index_trend=0.00 vix=27.19 vix_pressure=0.360; explicit_targets_first=코스피, 미국 증시, 국제유가, 환율; elevated fear index added defensive macro and hedge queries
- global_sentiment: score=-0.1696 status=ok source=yfinance
- global_index_moves: `{"sp500_pct": -0.6059115470564369, "nasdaq_pct": -0.9260544757082045, "dow_pct": -0.255759013115997}`
- fear_index: `{"provider": "yfinance", "ticker": "^VIX", "level": 27.190000534057617, "change_pct": -0.36643597696923713, "neutral_level": 20.0, "level_pressure": 0.35950002670288084}`
- macro_stress: active=True flags=`["elevated_vix", "dollar_strength"]` reason=`vix=27.19 pressure=0.360 dxy_pct=0.27 tnx_delta=0.0012`
- llm: provider=openrouter model=minimax/minimax-m2.5 ok=True latency_ms=6407
- llm_prompt_captured: **True**
- llm_response_captured: **True**
- themes: `["broad_market_leaders", "defensive_assets", "defensive_etfs"]`
- playbook: **pullback**
- scanner_source_policy: `{"preferred_sources": ["top_value", "sector_theme", "top_volume", "operator_watchlist"], "include_top_value": true, "include_top_volume": true, "include_change_rate": false, "include_condition_search": false, "include_sector_candidates": true, "include_watchlist": true, "top_candidate_pool": 18, "condition_limit": 0, "source_weights": {"top_value": 2.3, "top_volume": 1.9, "condition_search": 0.0, "sector_theme": 1.9, "operator_watchlist": 1.1, "top_change_rate": 0.0}, "reason": "defensive frame prioritizes liquid leaders and suppresses fast-mover sources; elevated fear index (vix=27.19, pressure=0.360) shifted source policy toward liquid defensive candidates"}`
- news_sample_titles: `["<b>코스피</b>, 고유가·환율 부담에 하락 전환… 코스닥도 2%대 약세", "반도체 기대감 vs 국채금리 부담… <b>코스피</b> 힘겨루기", "NewsItem(title=\"'고유가 충격'에 환율 1,500원 돌파...금융위기 이후 처음\", url='https://n.news.naver.com/mnews/article/052/0002327766?sid=101", "日 <b>증시</b>, 100달러대 유가에 하락 출발", "<b>미국</b>의 이란 하그르섬 공격에도 국제유가 하락 반전한 이유"]`

## Scanner
- candidate_source: **kiwoom_market_data**
- pool: before=5 after=5
- kiwoom_source_mix: `{"top_value": 18, "top_volume": 18, "top_change_rate": 0, "condition_search": 0, "sector_theme": 5, "operator_watchlist": 0}`
- condition_search: status=disabled source=disabled reason=condition_search_baseline_disabled
- scanner_source_policy: `{"include_top_value": true, "include_top_volume": true, "include_change_rate": false, "include_condition_search": false, "include_sector_candidates": true, "include_watchlist": true, "top_candidate_pool": 18, "condition_limit": 0, "preferred_sources": ["top_value", "sector_theme", "top_volume", "operator_watchlist"], "source_weights": {"top_value": 2.3, "top_volume": 1.9, "condition_search": 0.0, "sector_theme": 1.9, "operator_watchlist": 1.1, "top_change_rate": 0.0}, "reason": "defensive frame prioritizes liquid leaders and suppresses fast-mover sources; elevated fear index (vix=27.19, pressure=0.360) shifted source policy toward liquid defensive candidates"}`
- top_stock: **000660** top_score=1.139632717199362
- top_ranked_symbols: `["000660", "032820", "005930", "069500", "122630"]`
- score_breakdown_summary: `{"trading_value": 0.22000000000000003, "momentum": 0.09353213234793346, "trend": 0.002910464670939996, "ma_alignment": 0.0, "adx_trend": 0.002910464670939996, "volume_surge": 0.0, "intraday_strength": 0.07646436000000001, "vwap_alignment": 0.03591, "theme_boost": 0.0624, "sentiment": 0.005766733924564938, "cross_section_rank": 0.025, "avoid_theme_penalty": -0.0, "repeat_symbol_penalty": -0.18, "risk_penalty": -0.08516114305679326, "rank_bonus": 0.007068965517241379}`
- selected_candidate: `{"symbol": "000660", "why": "top_value+sector_theme", "sources": ["top_value", "sector_theme"], "source_scores": {"top_value": 2.28, "sector_theme": 1.8199999999999998}, "rank_score": 0.7068965517241379, "universe_score": 4.1, "score_total": 1.139632717199362, "risk_score": 0.4646989886596775, "confidence": 0.840628951148514, "score_breakdown": {"trading_value": 0.22000000000000003, "momentum": 0.09353213234793346, "trend": 0.002910464670939996, "ma_alignment": 0.0, "adx_trend": 0.002910464670939996, "volume_surge": 0.0, "intraday_strength": 0.07646436000000001, "vwap_alignment": 0.03591, "theme_boost": 0.0624, "sentiment": 0.005766733924564938, "cross_section_rank": 0.025, "avoid_theme_penalty": -0.0, "repeat_symbol_penalty": -0.18, "risk_penalty": -0.08516114305679326, "rank_bonus": 0.007068965517241379}, "feature_snapshot": {"quote_trading_value": 1696488436000.0, "quote_volume": 1813688.0, "intraday_change_pct": 2.42, "skill_quote_price": 932000.0, "engine_ma20_gap": -0.009399619808610371, "engine_ma60": null, "engine_ma120": null, "engine_adx14": 16.155606644646145, "engine_trend_strength": -0.16155606644646145, "engine_volume_spike20": 2.2144175322345008e-07, "engine_volatility20": 0.06168197286339035, "engine_vwap_distance": 0.13733380317323585, "engine_sector_relative_strength": 0.0, "engine_cross_section_rank": 0.5, "engine_regime": "high_volatility", "engine_signal_score": -0.5}, "component_snapshot": {"news_sentiment": 0.21, "global_sentiment": -0.16962589307972564, "trading_value_component": 1.0, "momentum_component": 0.4475221643441793, "trend_component": 0.011556066446461451, "volume_surge_component": 0.0, "intraday_strength_component": 0.6388, "theme_boost_component": 1.0, "sentiment_component": 0.0961122320760823, "volatility_penalty_component": 0.6336394572678069, "gap_penalty_component": 0.0, "avoid_theme_penalty_component": 0.0}}`

## Monitor
- selected_symbol: **000660**
- entry_reason=take_profit exit_reason=take_profit monitor_reason=confirmed_exit_signal
- position_age_seconds=4834 min_hold_blocked=False sell_cooldown_blocked=False
- thresholds: `{"stop_loss_pct": 0.08, "take_profit_pct": 0.011079991296000003, "max_hold_sec": 0, "time_stop_sec": 0, "trailing_stop_pct": 0.04, "vol_expansion_ratio": 2.0, "news_shock_threshold": 0.0, "eod_flat_cutoff_min": 10}` min_hold=600 sell_cooldown=300 confirm_ticks=2
- strategy_frame_adjustments: `["monitor_guidance:defensive_exit", "risk_tone:conservative"]`

## Supervisor
- verdict=approve allow=True reason=Allowed

## Executor
- execution_attempted=True ok=True broker_code=0
- execution_mode=real kiwoom_mode=mock broker_env=mock effective_mode=mock_broker_http
- api_id=ORDER_SUBMIT url=https://mockapi.kiwoom.com/api/dostk/ordr action=SELL symbol=032820 qty=1

## Reporter
- in_run_trace_available: **False**
- reporter_analysis_day_file_found: **True**
- reporter_analysis_found: **True**
- reporter_analysis_path: `reports\dev\analysis\reporter_analysis\reporter_analysis_2026-03-16.json`

## Next Command
- `python scripts/run_agent_pipeline_trace_report.py --run-id 85e8b128f35541aa84d7b8b9ece0d8f0 --json`
- `python scripts/query_trade_reason_chain.py --run-id 85e8b128f35541aa84d7b8b9ece0d8f0 --only-broker-success`