# Agent Pipeline Trace (13d6b1fc402f490d8c79d12d1f2203c4)

- day: **2026-03-16**
- event_log_path: `data\logs\events.jsonl`
- evidence_log_path: `data\evidence_ledger\events.jsonl`

## Commander
- mode: **integrated_chain**
- agents: `["commander_router", "strategist", "scanner", "monitor", "decision", "supervisor", "executor", "reporter"]`
- route_ts: `2026-03-16T01:34:20+00:00`
- end_status: **ok**

## Strategist
- news_source: **naver** headlines=60 symbols=12
- news_query_targets: `["코스피", "미국 증시", "국제유가", "환율", "중동", "달러", "방산", "금"]`
- news_query_reasoning: global_score=-0.17 macro_risk=0.00 index_trend=0.00 vix=27.19 vix_pressure=0.360; explicit_targets_first=코스피, 미국 증시, 국제유가, 환율; elevated fear index added defensive macro and hedge queries
- global_sentiment: score=-0.1714 status=ok source=yfinance
- global_index_moves: `{"sp500_pct": -0.6059115470564369, "nasdaq_pct": -0.9260544757082045, "dow_pct": -0.255759013115997}`
- fear_index: `{"provider": "yfinance", "ticker": "^VIX", "level": 27.190000534057617, "change_pct": -0.36643597696923713, "neutral_level": 20.0, "level_pressure": 0.35950002670288084}`
- macro_stress: active=True flags=`["elevated_vix", "dollar_strength"]` reason=`vix=27.19 pressure=0.360 dxy_pct=0.76 tnx_delta=0.0012`
- llm: provider=openrouter model=minimax/minimax-m2.5 ok=False latency_ms=8716
- llm_prompt_captured: **True**
- llm_response_captured: **True**
- themes: `["broad_market_leaders"]`
- playbook: **pullback**
- scanner_source_policy: `{"preferred_sources": ["top_value", "sector_theme", "top_volume", "operator_watchlist"], "include_top_value": true, "include_top_volume": true, "include_change_rate": false, "include_condition_search": false, "include_sector_candidates": true, "include_watchlist": true, "top_candidate_pool": 18, "condition_limit": 0, "source_weights": {"top_value": 2.3, "top_volume": 1.9, "condition_search": 0.0, "sector_theme": 1.9, "operator_watchlist": 1.1, "top_change_rate": 0.0}, "reason": "defensive frame prioritizes liquid leaders and suppresses fast-mover sources; elevated fear index (vix=27.19, pressure=0.360) shifted source policy toward liquid defensive candidates"}`
- news_sample_titles: `["대한전선 주가, 3월 16일 장중 29,350원 2.00% 하락", "미래에셋생명 주가, 3월 16일 장중 15,000원 13.63% 상승", "NewsItem(title=\"중동發 '15조~20조' 벚꽃 추경 급물살···경기부양 효과 '글쎄'\", url='https://www.seoulfn.com/news/articleView.html?idxno=623641", "유가, 환율 치솟았지만 코스피 장 초반 오름폭 확대", "1500원대 뚫린 환율…환노출형 美 ETF 수익률 방어"]`

## Scanner
- candidate_source: **kiwoom_market_data**
- pool: before=5 after=5
- kiwoom_source_mix: `{"top_value": 18, "top_volume": 18, "top_change_rate": 0, "condition_search": 0, "sector_theme": 0, "operator_watchlist": 0}`
- condition_search: status=disabled source=disabled reason=condition_search_baseline_disabled
- scanner_source_policy: `{"include_top_value": true, "include_top_volume": true, "include_change_rate": false, "include_condition_search": false, "include_sector_candidates": true, "include_watchlist": true, "top_candidate_pool": 18, "condition_limit": 0, "preferred_sources": ["top_value", "sector_theme", "top_volume", "operator_watchlist"], "source_weights": {"top_value": 2.3, "top_volume": 1.9, "condition_search": 0.0, "sector_theme": 1.9, "operator_watchlist": 1.1, "top_change_rate": 0.0}, "reason": "defensive frame prioritizes liquid leaders and suppresses fast-mover sources; elevated fear index (vix=27.19, pressure=0.360) shifted source policy toward liquid defensive candidates"}`
- top_stock: **032820** top_score=1.6735726362900802
- top_ranked_symbols: `["032820", "006910", "005880", "003280", "252670"]`
- score_breakdown_summary: `{"trading_value": 0.22000000000000003, "momentum": 0.209, "trend": 0.1433410621714286, "ma_alignment": 0.04284070560000001, "adx_trend": 0.05440089600000001, "volume_surge": 0.0384506250990579, "intraday_strength": 0.03591, "vwap_alignment": 0.03591, "theme_boost": 0.0, "sentiment": 0.034714799694999035, "cross_section_rank": 0.025, "avoid_theme_penalty": -0.0, "risk_penalty": -0.13331506849315075, "rank_bonus": 0.009707317073170732}`
- selected_candidate: `{"symbol": "032820", "why": "top_value+top_volume", "sources": ["top_value", "top_volume"], "source_scores": {"top_value": 2.2199999999999998, "top_volume": 1.7599999999999998}, "rank_score": 0.9707317073170731, "universe_score": 3.9799999999999995, "score_total": 1.6735726362900802, "risk_score": 0.5622081834280387, "confidence": 0.9855757981367039, "score_breakdown": {"trading_value": 0.22000000000000003, "momentum": 0.209, "trend": 0.1433410621714286, "ma_alignment": 0.04284070560000001, "adx_trend": 0.05440089600000001, "volume_surge": 0.0384506250990579, "intraday_strength": 0.03591, "vwap_alignment": 0.03591, "theme_boost": 0.0, "sentiment": 0.034714799694999035, "cross_section_rank": 0.025, "avoid_theme_penalty": -0.0, "risk_penalty": -0.13331506849315075, "rank_bonus": 0.009707317073170732}, "feature_snapshot": {"quote_trading_value": 0.0, "quote_volume": 0.0, "intraday_change_pct": 0.0, "skill_quote_price": null, "engine_ma20_gap": 0.4762264150943396, "engine_ma60": null, "engine_ma120": null, "engine_adx14": 37.66233766233767, "engine_trend_strength": 0.3766233766233767, "engine_volume_spike20": 1.5492946442722557, "engine_volatility20": 0.12453999660050089, "engine_vwap_distance": 0.9178084874144397, "engine_sector_relative_strength": 1.1631987135845876, "engine_cross_section_rank": 0.5, "engine_regime": "high_volatility", "engine_signal_score": 0.0}, "component_snapshot": {"news_sentiment": 0.9, "global_sentiment": -0.17140001694449794, "trading_value_component": 1.0, "momentum_component": 1.0, "trend_component": 0.5269805194805195, "volume_surge_component": 0.27464732213612786, "intraday_strength_component": 0.3, "theme_boost_component": 0.0, "sentiment_component": 0.5785799949166506, "volatility_penalty_component": 1.0, "gap_penalty_component": 0.15851272015655654, "avoid_theme_penalty_component": 0.0}}`

## Monitor
- selected_symbol: **032820**
- entry_reason=no_position exit_reason=no_position monitor_reason=no_position
- position_age_seconds=None min_hold_blocked=False sell_cooldown_blocked=False
- thresholds: `{"stop_loss_pct": 0.08, "take_profit_pct": 0.008791595366400002, "max_hold_sec": 0, "time_stop_sec": 0, "trailing_stop_pct": 0.04, "vol_expansion_ratio": 2.0, "news_shock_threshold": 0.0, "eod_flat_cutoff_min": 10}` min_hold=600 sell_cooldown=300 confirm_ticks=2
- strategy_frame_adjustments: `["monitor_guidance:defensive_exit", "risk_tone:conservative"]`

## Supervisor
- verdict=approve allow=True reason=Allowed

## Executor
- execution_attempted=True ok=True broker_code=0
- execution_mode=real kiwoom_mode=mock broker_env=mock effective_mode=mock_broker_http
- api_id=ORDER_SUBMIT url=https://mockapi.kiwoom.com/api/dostk/ordr action=BUY symbol=032820 qty=1

## Reporter
- in_run_trace_available: **False**
- reporter_analysis_day_file_found: **True**
- reporter_analysis_found: **True**
- reporter_analysis_path: `reports\dev\analysis\reporter_analysis\reporter_analysis_2026-03-16.json`

## Next Command
- `python scripts/run_agent_pipeline_trace_report.py --run-id 13d6b1fc402f490d8c79d12d1f2203c4 --json`
- `python scripts/query_trade_reason_chain.py --run-id 13d6b1fc402f490d8c79d12d1f2203c4 --only-broker-success`