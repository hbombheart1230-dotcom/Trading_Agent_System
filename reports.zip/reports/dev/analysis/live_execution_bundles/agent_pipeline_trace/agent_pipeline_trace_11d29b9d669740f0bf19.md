# Agent Pipeline Trace (11d29b9d669740f0bf195523fc064ed0)

- day: **2026-03-16**
- event_log_path: `data\logs\events.jsonl`
- evidence_log_path: `data\evidence_ledger\events.jsonl`

## Commander
- mode: **integrated_chain**
- agents: `["commander_router", "strategist", "scanner", "monitor", "decision", "supervisor", "executor", "reporter"]`
- route_ts: `2026-03-16T01:11:20+00:00`
- end_status: **ok**

## Strategist
- news_source: **naver** headlines=60 symbols=12
- news_query_targets: `["코스피", "미국 증시", "국제유가", "환율", "중동", "달러", "방산", "금"]`
- news_query_reasoning: global_score=-0.17 macro_risk=0.00 index_trend=0.00 vix=27.19 vix_pressure=0.360; explicit_targets_first=코스피, 미국 증시, 국제유가, 환율; elevated fear index added defensive macro and hedge queries
- global_sentiment: score=-0.1685 status=ok source=yfinance
- global_index_moves: `{"sp500_pct": -0.6059115470564369, "nasdaq_pct": -0.9260544757082045, "dow_pct": -0.255759013115997}`
- fear_index: `{"provider": "yfinance", "ticker": "^VIX", "level": 27.190000534057617, "change_pct": -0.36643597696923713, "neutral_level": 20.0, "level_pressure": 0.35950002670288084}`
- macro_stress: active=False flags=`["elevated_vix"]` reason=`None`
- llm: provider=openrouter model=minimax/minimax-m2.5 ok=False latency_ms=4016
- llm_prompt_captured: **True**
- llm_response_captured: **True**
- themes: `["broad_market_leaders"]`
- playbook: **pullback**
- scanner_source_policy: `{"preferred_sources": ["top_value", "sector_theme", "top_volume", "operator_watchlist"], "include_top_value": true, "include_top_volume": true, "include_change_rate": false, "include_condition_search": false, "include_sector_candidates": true, "include_watchlist": true, "top_candidate_pool": 20, "condition_limit": 0, "source_weights": {"top_value": 2.3, "top_volume": 1.8, "condition_search": 0.0, "sector_theme": 1.9, "operator_watchlist": 1.1, "top_change_rate": 0.0}, "reason": "pullback baseline prioritizes liquid leaders and theme/watchlist support; condition search remains optional; elevated fear index (vix=27.19, pressure=0.360) shifted source policy toward liquid defensive candidates"}`
- news_sample_titles: `["<b>코스피</b>, 유가 100달러·환율 1500원에도 반등", "NewsItem(title=\"신한운용, 'SOL 200타겟위클리커버드콜' ETF 신규 상장\", url='https://www.newsinside.kr/news/articleView.html?idxno=4512287'", "한화비전 주가, 3월 16일 장중 78,800원 2.74% 상승", "코스피, 유가 100달러·환율 1500원에도 반등", "[주간 뉴욕<b>증시</b>] 연준 경제 전망과 엔비디아GTC 주목…마이크론 실적도"]`

## Scanner
- candidate_source: **kiwoom_market_data**
- pool: before=3 after=3
- kiwoom_source_mix: `{"top_value": 20, "top_volume": 20, "top_change_rate": 0, "condition_search": 0, "sector_theme": 5, "operator_watchlist": 0}`
- condition_search: status=disabled source=disabled reason=condition_search_baseline_disabled
- scanner_source_policy: `{"include_top_value": true, "include_top_volume": true, "include_change_rate": false, "include_condition_search": false, "include_sector_candidates": true, "include_watchlist": true, "top_candidate_pool": 20, "condition_limit": 0, "preferred_sources": ["top_value", "sector_theme", "top_volume", "operator_watchlist"], "source_weights": {"top_value": 2.3, "top_volume": 1.8, "condition_search": 0.0, "sector_theme": 1.9, "operator_watchlist": 1.1, "top_change_rate": 0.0}, "reason": "pullback baseline prioritizes liquid leaders and theme/watchlist support; condition search remains optional; elevated fear index (vix=27.19, pressure=0.360) shifted source policy toward liquid defensive candidates"}`
- top_stock: **032820** top_score=1.42729100925596
- top_ranked_symbols: `["032820", "006800", "003280"]`
- score_breakdown_summary: `{"trading_value": 0.22000000000000003, "momentum": 0.0, "trend": 0.0, "ma_alignment": 0.0, "adx_trend": 0.0, "volume_surge": 0.0, "intraday_strength": 0.0, "vwap_alignment": 0.0, "theme_boost": 0.067392, "sentiment": 0.03476709753451721, "cross_section_rank": 0.0, "avoid_theme_penalty": -0.0, "risk_penalty": -0.0, "rank_bonus": 0.009828767123287672}`
- selected_candidate: `{"symbol": "032820", "why": "top_value+top_volume+sector_theme", "sources": ["top_value", "top_volume", "sector_theme"], "source_scores": {"top_value": 2.2199999999999998, "top_volume": 1.6600000000000001, "sector_theme": 1.8599999999999999}, "rank_score": 0.9828767123287672, "universe_score": 5.74, "score_total": 1.42729100925596, "risk_score": 0.17199891628314212, "confidence": 0.9485717550411366, "score_breakdown": {"trading_value": 0.22000000000000003, "momentum": 0.0, "trend": 0.0, "ma_alignment": 0.0, "adx_trend": 0.0, "volume_surge": 0.0, "intraday_strength": 0.0, "vwap_alignment": 0.0, "theme_boost": 0.067392, "sentiment": 0.03476709753451721, "cross_section_rank": 0.0, "avoid_theme_penalty": -0.0, "risk_penalty": -0.0, "rank_bonus": 0.009828767123287672}, "feature_snapshot": {"quote_trading_value": 0.0, "quote_volume": 0.0, "intraday_change_pct": 0.0, "skill_quote_price": null, "engine_ma20_gap": null, "engine_ma60": null, "engine_ma120": null, "engine_adx14": null, "engine_trend_strength": null, "engine_volume_spike20": null, "engine_volatility20": null, "engine_vwap_distance": null, "engine_sector_relative_strength": null, "engine_cross_section_rank": null, "engine_regime": null, "engine_signal_score": 0.0}, "component_snapshot": {"news_sentiment": 0.9, "global_sentiment": -0.16849458141571055, "trading_value_component": 1.0, "momentum_component": 0.0, "trend_component": 0.0, "volume_surge_component": 0.0, "intraday_strength_component": 0.0, "theme_boost_component": 1.0, "sentiment_component": 0.5794516255752868, "volatility_penalty_component": 0.0, "gap_penalty_component": 0.0, "avoid_theme_penalty_component": 0.0}}`

## Monitor
- selected_symbol: **032820**
- entry_reason=no_position exit_reason=no_position monitor_reason=no_position
- position_age_seconds=None min_hold_blocked=False sell_cooldown_blocked=False
- thresholds: `{"stop_loss_pct": 0.01047375, "take_profit_pct": 0.010180485000000001, "max_hold_sec": 0, "time_stop_sec": 0, "trailing_stop_pct": 0.008379000000000001, "vol_expansion_ratio": 2.0, "news_shock_threshold": 0.0, "eod_flat_cutoff_min": 10}` min_hold=300 sell_cooldown=180 confirm_ticks=1
- strategy_frame_adjustments: `["monitor_guidance:quick_take_profit"]`

## Supervisor
- verdict=approve allow=True reason=Allowed

## Executor
- execution_attempted=True ok=True broker_code=0
- execution_mode=real kiwoom_mode=mock broker_env=mock effective_mode=mock_broker_http
- api_id=ORDER_SUBMIT url=https://mockapi.kiwoom.com/api/dostk/ordr action=BUY symbol=032820 qty=1

## Reporter
- in_run_trace_available: **False**
- reporter_analysis_day_file_found: **True**
- reporter_analysis_found: **True**
- reporter_analysis_path: `reports\dev\analysis\reporter_analysis\reporter_analysis_2026-03-16.json`

## Next Command
- `python scripts/run_agent_pipeline_trace_report.py --run-id 11d29b9d669740f0bf195523fc064ed0 --json`
- `python scripts/query_trade_reason_chain.py --run-id 11d29b9d669740f0bf195523fc064ed0 --only-broker-success`