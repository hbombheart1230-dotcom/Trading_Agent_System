# Live Execution Bundle (13d6b1fc402f490d8c79d12d1f2203c4)

- day: **2026-03-16**
- execution: **BUY 032820 x1** status=`모의투자 매수주문완료` ord_no=`0086923`
- execution_ts: `2026-03-16T01:34:53+00:00`

## Strategist
- playbook: **pullback** themes=`["broad_market_leaders"]`
- market context: sentiment=-0.17140001694449794 vix=`{"provider": "yfinance", "ticker": "^VIX", "level": 27.190000534057617, "change_pct": -0.36643597696923713, "neutral_level": 20.0, "level_pressure": 0.35950002670288084}`
- news_query_reasoning: global_score=-0.17 macro_risk=0.00 index_trend=0.00 vix=27.19 vix_pressure=0.360; explicit_targets_first=코스피, 미국 증시, 국제유가, 환율; elevated fear index added defensive macro and hedge queries

## Scanner
- top_stock: **032820** top_score=1.6735726362900802 pool_after=5
- selected_candidate: `{"symbol": "032820", "why": "top_value+top_volume", "sources": ["top_value", "top_volume"], "source_scores": {"top_value": 2.2199999999999998, "top_volume": 1.7599999999999998}, "rank_score": 0.9707317073170731, "universe_score": 3.9799999999999995, "score_total": 1.6735726362900802, "risk_score": 0.5622081834280387, "confidence": 0.9855757981367039, "score_breakdown": {"trading_value": 0.22000000000000003, "momentum": 0.209, "trend": 0.1433410621714286, "ma_alignment": 0.04284070560000001, "adx_trend": 0.05440089600000001, "volume_surge": 0.0384506250990579, "intraday_strength": 0.03591, "vwap_alignment": 0.03591, "theme_boost": 0.0, "sentiment": 0.034714799694999035, "cross_section_rank": 0.025, "avoid_theme_penalty": -0.0, "risk_penalty": -0.13331506849315075, "rank_bonus": 0.009707317073170732}, "feature_snapshot": {"quote_trading_value": 0.0, "quote_volume": 0.0, "intraday_change_pct": 0.0, "skill_quote_price": null, "engine_ma20_gap": 0.4762264150943396, "engine_ma60": null, "engine_ma120": null, "engine_adx14": 37.66233766233767, "engine_trend_strength": 0.3766233766233767, "engine_volume_spike20": 1.5492946442722557, "engine_volatility20": 0.12453999660050089, "engine_vwap_distance": 0.9178084874144397, "engine_sector_relative_strength": 1.1631987135845876, "engine_cross_section_rank": 0.5, "engine_regime": "high_volatility", "engine_signal_score": 0.0}, "component_snapshot": {"news_sentiment": 0.9, "global_sentiment": -0.17140001694449794, "trading_value_component": 1.0, "momentum_component": 1.0, "trend_component": 0.5269805194805195, "volume_surge_component": 0.27464732213612786, "intraday_strength_component": 0.3, "theme_boost_component": 0.0, "sentiment_component": 0.5785799949166506, "volatility_penalty_component": 1.0, "gap_penalty_component": 0.15851272015655654, "avoid_theme_penalty_component": 0.0}}`

## Monitor
- selected_symbol=032820 entry_reason=no_position exit_reason=no_position monitor_reason=no_position
- thresholds: `{"stop_loss_pct": 0.08, "take_profit_pct": 0.008791595366400002, "max_hold_sec": 0, "time_stop_sec": 0, "trailing_stop_pct": 0.04, "vol_expansion_ratio": 2.0, "news_shock_threshold": 0.0, "eod_flat_cutoff_min": 10}`

## Reporter
- reporter_analysis_found=True day_file_found=True
- reporter_analysis_path: `reports\dev\analysis\reporter_analysis\reporter_analysis_2026-03-16.json`

## Artifacts
- agent_pipeline_trace_json: `reports\dev\analysis\live_execution_bundles\agent_pipeline_trace\agent_pipeline_trace_13d6b1fc402f490d8c79.json`
- agent_pipeline_trace_md: `reports\dev\analysis\live_execution_bundles\agent_pipeline_trace\agent_pipeline_trace_13d6b1fc402f490d8c79.md`
- trade_explain_json: `reports\dev\analysis\trade_explain\trade_explain_2026-03-16.json`
- trade_explain_md: `reports\dev\analysis\trade_explain\trade_explain_2026-03-16.md`
- reporter_analysis_json: `reports\dev\analysis\reporter_analysis\reporter_analysis_2026-03-16.json`
- reporter_analysis_md: `reports\dev\analysis\reporter_analysis\reporter_analysis_2026-03-16.md`
- operator_summary_json: `reports\operator_summary\operator_summary_2026-03-16.json`
- operator_summary_md: `reports\operator_summary\operator_summary_2026-03-16.md`
