# Live Execution Bundle (ebcda2b4ece048869d706d6a429f5119)

- day: **2026-03-16**
- execution: **SELL 032820 x1** status=`모의투자 매도주문완료` ord_no=`0013099`
- execution_ts: `2026-03-16T00:03:42+00:00`

## Strategist
- playbook: **pullback** themes=`["broad_market_leaders"]`
- market context: sentiment=-0.17140001694449794 vix=`{"provider": "yfinance", "ticker": "^VIX", "level": 27.190000534057617, "change_pct": -0.36643597696923713, "neutral_level": 20.0, "level_pressure": 0.35950002670288084}`
- news_query_reasoning: global_score=-0.17 macro_risk=0.00 index_trend=0.00 vix=27.19 vix_pressure=0.360; explicit_targets_first=코스피, 미국 증시, 국제유가, 환율; elevated fear index added defensive macro and hedge queries

## Scanner
- top_stock: **032820** top_score=1.2354203052469261 pool_after=5
- selected_candidate: `{"symbol": "032820", "why": "top_value+top_volume", "sources": ["top_value", "top_volume"], "source_scores": {"top_value": 2.26, "top_volume": 1.8199999999999998}, "rank_score": 0.9855072463768116, "universe_score": 4.08, "score_total": 1.2354203052469261, "risk_score": 0.1725800033888996, "confidence": 0.9098307851716412, "score_breakdown": {"trading_value": 0.22000000000000003, "momentum": 0.0, "trend": 0.0, "ma_alignment": 0.0, "adx_trend": 0.0, "volume_surge": 0.0, "intraday_strength": 0.0, "vwap_alignment": 0.0, "theme_boost": 0.0, "sentiment": 0.013714799694999035, "cross_section_rank": 0.0, "avoid_theme_penalty": -0.0, "risk_penalty": -0.0, "rank_bonus": 0.009855072463768117}, "feature_snapshot": {"quote_trading_value": 0.0, "quote_volume": 0.0, "intraday_change_pct": 0.0, "skill_quote_price": null, "engine_ma20_gap": null, "engine_ma60": null, "engine_ma120": null, "engine_adx14": null, "engine_trend_strength": null, "engine_volume_spike20": null, "engine_volatility20": null, "engine_vwap_distance": null, "engine_sector_relative_strength": null, "engine_cross_section_rank": null, "engine_regime": null, "engine_signal_score": 0.0}, "component_snapshot": {"news_sentiment": 0.4, "global_sentiment": -0.17140001694449794, "trading_value_component": 1.0, "momentum_component": 0.0, "trend_component": 0.0, "volume_surge_component": 0.0, "intraday_strength_component": 0.0, "theme_boost_component": 0.0, "sentiment_component": 0.2285799949166506, "volatility_penalty_component": 0.0, "gap_penalty_component": 0.0, "avoid_theme_penalty_component": 0.0}}`

## Monitor
- selected_symbol=032820 entry_reason=take_profit exit_reason=take_profit monitor_reason=confirmed_exit_signal
- thresholds: `{"stop_loss_pct": 0.00823865175, "take_profit_pct": 0.008791595366400002, "max_hold_sec": 0, "time_stop_sec": 0, "trailing_stop_pct": 0.00798, "vol_expansion_ratio": 2.0, "news_shock_threshold": 0.0, "eod_flat_cutoff_min": 10}`

## Reporter
- reporter_analysis_found=True day_file_found=True
- reporter_analysis_path: `reports\dev\analysis\reporter_analysis\reporter_analysis_2026-03-16.json`

## Artifacts
- agent_pipeline_trace_json: `reports\dev\analysis\live_execution_bundles\agent_pipeline_trace\agent_pipeline_trace_ebcda2b4ece048869d70.json`
- agent_pipeline_trace_md: `reports\dev\analysis\live_execution_bundles\agent_pipeline_trace\agent_pipeline_trace_ebcda2b4ece048869d70.md`
- trade_explain_json: `reports\dev\analysis\trade_explain\trade_explain_2026-03-16.json`
- trade_explain_md: `reports\dev\analysis\trade_explain\trade_explain_2026-03-16.md`
- reporter_analysis_json: `reports\dev\analysis\reporter_analysis\reporter_analysis_2026-03-16.json`
- reporter_analysis_md: `reports\dev\analysis\reporter_analysis\reporter_analysis_2026-03-16.md`
- operator_summary_json: `reports\operator_summary\operator_summary_2026-03-16.json`
- operator_summary_md: `reports\operator_summary\operator_summary_2026-03-16.md`
