# Live Execution Bundle (85e8b128f35541aa84d7b8b9ece0d8f0)

- day: **2026-03-16**
- execution: **SELL 032820 x1** status=`모의투자 매도주문완료` ord_no=`0119172`
- execution_ts: `2026-03-16T02:55:50+00:00`

## Strategist
- playbook: **pullback** themes=`["broad_market_leaders", "defensive_assets", "defensive_etfs"]`
- market context: sentiment=-0.16962589307972564 vix=`{"provider": "yfinance", "ticker": "^VIX", "level": 27.190000534057617, "change_pct": -0.36643597696923713, "neutral_level": 20.0, "level_pressure": 0.35950002670288084}`
- news_query_reasoning: global_score=-0.17 macro_risk=0.00 index_trend=0.00 vix=27.19 vix_pressure=0.360; explicit_targets_first=코스피, 미국 증시, 국제유가, 환율; elevated fear index added defensive macro and hedge queries

## Scanner
- top_stock: **000660** top_score=1.139632717199362 pool_after=5
- selected_candidate: `{"symbol": "000660", "why": "top_value+sector_theme", "sources": ["top_value", "sector_theme"], "source_scores": {"top_value": 2.28, "sector_theme": 1.8199999999999998}, "rank_score": 0.7068965517241379, "universe_score": 4.1, "score_total": 1.139632717199362, "risk_score": 0.4646989886596775, "confidence": 0.840628951148514, "score_breakdown": {"trading_value": 0.22000000000000003, "momentum": 0.09353213234793346, "trend": 0.002910464670939996, "ma_alignment": 0.0, "adx_trend": 0.002910464670939996, "volume_surge": 0.0, "intraday_strength": 0.07646436000000001, "vwap_alignment": 0.03591, "theme_boost": 0.0624, "sentiment": 0.005766733924564938, "cross_section_rank": 0.025, "avoid_theme_penalty": -0.0, "repeat_symbol_penalty": -0.18, "risk_penalty": -0.08516114305679326, "rank_bonus": 0.007068965517241379}, "feature_snapshot": {"quote_trading_value": 1696488436000.0, "quote_volume": 1813688.0, "intraday_change_pct": 2.42, "skill_quote_price": 932000.0, "engine_ma20_gap": -0.009399619808610371, "engine_ma60": null, "engine_ma120": null, "engine_adx14": 16.155606644646145, "engine_trend_strength": -0.16155606644646145, "engine_volume_spike20": 2.2144175322345008e-07, "engine_volatility20": 0.06168197286339035, "engine_vwap_distance": 0.13733380317323585, "engine_sector_relative_strength": 0.0, "engine_cross_section_rank": 0.5, "engine_regime": "high_volatility", "engine_signal_score": -0.5}, "component_snapshot": {"news_sentiment": 0.21, "global_sentiment": -0.16962589307972564, "trading_value_component": 1.0, "momentum_component": 0.4475221643441793, "trend_component": 0.011556066446461451, "volume_surge_component": 0.0, "intraday_strength_component": 0.6388, "theme_boost_component": 1.0, "sentiment_component": 0.0961122320760823, "volatility_penalty_component": 0.6336394572678069, "gap_penalty_component": 0.0, "avoid_theme_penalty_component": 0.0}}`

## Monitor
- selected_symbol=000660 entry_reason=take_profit exit_reason=take_profit monitor_reason=confirmed_exit_signal
- thresholds: `{"stop_loss_pct": 0.08, "take_profit_pct": 0.011079991296000003, "max_hold_sec": 0, "time_stop_sec": 0, "trailing_stop_pct": 0.04, "vol_expansion_ratio": 2.0, "news_shock_threshold": 0.0, "eod_flat_cutoff_min": 10}`

## Reporter
- reporter_analysis_found=True day_file_found=True
- reporter_analysis_path: `reports\dev\analysis\reporter_analysis\reporter_analysis_2026-03-16.json`

## Artifacts
- agent_pipeline_trace_json: `reports\dev\analysis\live_execution_bundles\agent_pipeline_trace\agent_pipeline_trace_85e8b128f35541aa84d7.json`
- agent_pipeline_trace_md: `reports\dev\analysis\live_execution_bundles\agent_pipeline_trace\agent_pipeline_trace_85e8b128f35541aa84d7.md`
- trade_explain_json: `reports\dev\analysis\trade_explain\trade_explain_2026-03-16.json`
- trade_explain_md: `reports\dev\analysis\trade_explain\trade_explain_2026-03-16.md`
- reporter_analysis_json: `reports\dev\analysis\reporter_analysis\reporter_analysis_2026-03-16.json`
- reporter_analysis_md: `reports\dev\analysis\reporter_analysis\reporter_analysis_2026-03-16.md`
- operator_summary_json: `reports\operator_summary\operator_summary_2026-03-16.json`
- operator_summary_md: `reports\operator_summary\operator_summary_2026-03-16.md`
