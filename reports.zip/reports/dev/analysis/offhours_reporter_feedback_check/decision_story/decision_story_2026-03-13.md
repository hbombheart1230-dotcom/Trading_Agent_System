# Decision Story Report (2026-03-13)

- story_total: **1**
- rendered_story_total: **1**

## Run d021a9ee8feb4319bff46a8629eee5d5

- run_id: `d021a9ee8feb4319bff46a8629eee5d5`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.006885648, take_profit_pct=0.008105605200000003, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.00836, vol_expansion_ratio=1.6
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed
