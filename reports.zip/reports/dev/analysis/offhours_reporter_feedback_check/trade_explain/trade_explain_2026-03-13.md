# Trade Explain Report (2026-03-13)

- event_log_path: `C:\Trading_Agent_System\data\logs\dev\analysis\offhours\offhours_reporter_feedback_check.jsonl`
- executions_total: **1**
- sell_pairs_total: **0**

## Executive Summary

- symbols_executed: `['032820']`
- action_counts: `{'BUY': 1}`
- symbol_side_counts: `{'032820:BUY': 1}`
- short_holds_lt_120s: **0**

## Agent Activity Snapshot

- `strategist_llm`: 1
- `strategist`: 1
- `decision_trace`: 5
- `scanner`: 1
- `monitor`: 1
- `execute_from_packet`: 4

## Report Inventory

- none

## Execution Timeline (Latest)

| ts | run_id | symbol | action | qty | price | strategy | reason |
| --- | --- | --- | --- | ---: | ---: | --- | --- |
| 2026-03-13T10:44:49+00:00 | `d021a9ee8feb4319bff46a8629eee5d5` | 032820 | BUY | 1 | 70000.0 | - | - |

## Sell Pair Analysis (FIFO, Latest)

No SELL pairs found.
## Data Gaps

- scanner_score_breakdown_missing_total: 0
- news_items_missing_total: 1
- note: news headline text and scanner score_breakdown are limited by current event-log payload policy.
