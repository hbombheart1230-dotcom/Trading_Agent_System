# Decision Story Report (2026-03-16)

- story_total: **1**
- rendered_story_total: **1**

## Run cb18d2f1c44642698505afaf76551740

- run_id: `cb18d2f1c44642698505afaf76551740`
- symbol: **000660**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.08, take_profit_pct=0.0095038396416, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.04, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed
