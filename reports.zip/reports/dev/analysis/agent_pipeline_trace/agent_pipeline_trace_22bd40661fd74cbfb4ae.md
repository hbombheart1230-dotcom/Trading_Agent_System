# Agent Pipeline Trace (22bd40661fd74cbfb4aefa561bdbe2c6)

- day: **2026-03-12**
- event_log_path: `data\logs\events.jsonl`
- evidence_log_path: `data\evidence_ledger\events.jsonl`

## Commander
- mode: **integrated_chain**
- agents: `["commander_router", "strategist", "scanner", "monitor", "decision", "supervisor", "executor", "reporter"]`
- route_ts: `2026-03-12T06:05:04+00:00`
- end_status: **ok**

## Strategist
- news_source: **naver** headlines=5 symbols=1
- global_sentiment: score=-0.0049 status=ok source=yfinance
- llm: provider=openrouter model=minimax/minimax-m2.5 ok=True latency_ms=37404
- llm_prompt_captured: **True**
- llm_response_captured: **True**
- themes: `["broad_market_leaders", "quality_factor", "dividend_payers"]`
- playbook: **defensive**
- news_sample_titles: `["우리기술 주가 약세로 전환…5% 털썩", "[공시속보] 우리기술, 투자경고종목 지정 예고→주가 급등 따른 투자유...", "우리기술 주가 9% 도약 마감 후 흐름은?…진격 vs 숨고르기"]`

## Scanner
- candidate_source: **kiwoom_market_data**
- pool: before=10 after=10
- kiwoom_source_mix: `{"top_volume": 10, "top_change_rate": 5}`
- top_stock: **357880** top_score=0.9262250508137609
- top_ranked_symbols: `["357880", "095910", "380540", "039980", "010170"]`
- score_breakdown_summary: `{"trading_value": 0.0, "momentum": 0.0, "trend": 0.0, "volume_surge": 0.0, "intraday_strength": 0.0, "theme_boost": 0.0, "sentiment": 0.0, "avoid_theme_penalty": -0.0, "risk_penalty": -0.0, "rank_bonus": 0.0091044776119403}`

## Monitor
- selected_symbol: **357880**
- entry_reason=no_position exit_reason=no_position monitor_reason=no_position
- position_age_seconds=None min_hold_blocked=False sell_cooldown_blocked=False

## Supervisor
- verdict=approve allow=True reason=Allowed

## Executor
- execution_attempted=True ok=True broker_code=0
- api_id=ORDER_SUBMIT url=https://mockapi.kiwoom.com/api/dostk/ordr action=BUY symbol=357880 qty=1

## Reporter
- in_run_trace_available: **False**
- reporter_analysis_day_file_found: **True**
- reporter_analysis_found: **False**
- reporter_analysis_path: `reports\reporter_analysis\reporter_analysis_2026-03-12.json`

## Next Command
- `python scripts/run_agent_pipeline_trace_report.py --run-id 22bd40661fd74cbfb4aefa561bdbe2c6 --json`
- `python scripts/query_trade_reason_chain.py --run-id 22bd40661fd74cbfb4aefa561bdbe2c6 --only-broker-success`