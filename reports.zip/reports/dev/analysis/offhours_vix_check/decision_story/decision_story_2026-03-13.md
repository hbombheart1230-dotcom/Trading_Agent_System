# Decision Story Report (2026-03-13)

- story_total: **1**
- rendered_story_total: **1**

## Run 6f151bbef8c349239d725e9628378a17

- run_id: `6f151bbef8c349239d725e9628378a17`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.0079784838, take_profit_pct=0.0095038396416, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.007875, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed
