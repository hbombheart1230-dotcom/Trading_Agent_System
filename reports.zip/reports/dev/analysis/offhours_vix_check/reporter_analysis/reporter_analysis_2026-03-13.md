# Reporter Analysis (2026-03-13)

## Daily Operator Report

- system_health: **GREEN**
- 2026-03-13: health=GREEN
- trade_count=0 symbols=0
- monitor_status=stable scanner_status=appropriate supervisor_blocked_rate=0.00%
- next_action=No critical gaps detected; keep current baseline and continue daily report-driven calibration.
- recommended_actions: `["No critical gaps detected; keep current baseline and continue daily report-driven calibration."]`

- market_context: `{"global_sentiment_avg": null, "symbol_sentiment_avg": null, "llm_provider_top": {"openrouter": 1}, "llm_model_top": {"minimax/minimax-m2.5": 1}}`
- trades_executed: **1**
- trades_blocked: **0**
- major_decisions: `["pullback"]`
- anomalies: `[]`

## Trade Decision Summaries

- trade_summary_total: **0**
| symbol | buy_reason | sell_reason | holding_duration_sec | exit_trigger |
| --- | --- | --- | ---: | --- |

## Trade Summary

- trade_count: **0**
- symbols_traded: `[]`

## Decision Chains

- run_total: **1**
- rendered_run_total: **1**
- run_id=6f151bbef8c349239d725e9628378a17 symbol=032820 action=BUY supervisor=APPROVED execution=EXECUTED buy_reason=unspecified sell_reason=-

## Decision Trace Chain Summary

- run_total: **1**
- complete_chain_total: **1**
- run_id=6f151bbef8c349239d725e9628378a17 selected=032820 monitor=no_position supervisor=approve executor=accepted_or_filled complete=True

## Strategist Evaluation

- themes_proposed: `["broad_market_leaders", "large_cap_quality", "defensive_sectors", "large_cap_stability"]`
- actual_market_leaders_by_scanner: `["032820"]`
- theme_alignment_status: **aligned**
- assessment: Strategist themes were reflected in scanner filtering.

## Scanner Evaluation

- scanner_summary_total: **1**
- selected_symbol_top: `{"032820": 1}`
- no_candidate_total: **0**
- avg_top_score: **1.2278**
- selection_status: **appropriate**
- assessment: Scanner selected symbols consistently with sufficient candidate pool.

## Monitor Evaluation

- monitor_summary_total: **1**
- monitor_reason_top: `{"no_position": 1}`
- rapid_buy_sell_cycles: **0**
- monitor_status: **stable**
- assessment: Monitor flow is stable under current guards.

## Supervisor Activity

- verdict_total: **2**
- approved_total: **2**
- blocked_total: **0**
- blocked_rate: **0.00%**
- blocked_reason_top: `{}`
- assessment: Supervisor activity within normal range.

## Intent Flow Analysis

- intents_created: **0**
- intents_blocked: **0**
- intents_approved: **1**
- intents_executed: **1**
- reason_top: `{"monitor:no_position": 1}`

## Strategy Effectiveness

- Strategist favored broad_market_leaders theme.
- Scanner selected 032820 most frequently.
- Monitor exited mostly due to no_position.
- Reporter focus priority: exit_quality

## Overtrading Diagnostics

- rapid_buy_sell_cycles(<120s): **0**
- noise_exit_related_count: **0**
- frequent_guard_block_count: **0**
- guard_block_rate: **0.00%**

## Incident / Post-Mortem Support

- incident_total: **0**

## Improvement Suggestions

- report_focus_targets: `["exit_quality", "overtrading", "theme_accuracy"]`
- No critical gaps detected; keep current baseline and continue daily report-driven calibration.

## AI Review (Passive Optional Layer)

- ai_review_status: **disabled**
- ai_review_reason: REPORTER_AI_REVIEW_ENABLED is false
- ai_run_grade: **N/A**
- ai_findings: `[]`
- ai_root_causes: `[]`
- ai_improvement_suggestions: `[]`
- ai_agent_evaluations: `{}`

## Developer Summary

- decision_chain_run_total=1
- blocked_total=0 approved_total=2
- monitor_confirmed_exit_total=0
- scanner_no_candidate_total=0
- blocked_reason_top: `{}`
- monitor_reason_top: `{"no_position": 1}`

## Source Artifacts

- trade_explain_json: `C:\Trading_Agent_System\reports\dev\analysis\offhours_vix_check\trade_explain\trade_explain_2026-03-13.json`
- trade_explain_md: `C:\Trading_Agent_System\reports\dev\analysis\offhours_vix_check\trade_explain\trade_explain_2026-03-13.md`
- operator_summary_json: `C:\Trading_Agent_System\reports\dev\analysis\offhours_vix_check\operator_summary\operator_summary_2026-03-13.json`
- operator_summary_md: `C:\Trading_Agent_System\reports\dev\analysis\offhours_vix_check\operator_summary\operator_summary_2026-03-13.md`
- decision_story_md: `C:\Trading_Agent_System\reports\dev\analysis\offhours_vix_check\decision_story\decision_story_2026-03-13.md`
- run_cards_md: `C:\Trading_Agent_System\reports\dev\analysis\offhours_vix_check\run_cards\run_cards_2026-03-13.md`
- decision_story_total: `1`
- run_card_total: `1`
