# Agent Pipeline Trace (6f151bbef8c349239d725e9628378a17)

- day: **2026-03-13**
- event_log_path: `C:\Trading_Agent_System\data\logs\dev\analysis\offhours\offhours_vix_check.jsonl`
- evidence_log_path: `C:\Trading_Agent_System\data\evidence_ledger\offhours_vix_check.jsonl`

## Commander
- mode: ****
- agents: `[]`
- route_ts: ``
- end_status: ****

## Strategist
- news_source: **naver** headlines=49 symbols=10
- news_query_targets: `["코스피", "코스닥", "미국 증시", "증시 전망", "거시경제"]`
- news_query_reasoning: global_score=-0.18 macro_risk=0.00 index_trend=0.00; neutral context kept broad market and macro queries
- global_sentiment: score=-0.1844 status=ok source=yfinance
- global_index_moves: `{"sp500_pct": -1.5227676506708532, "nasdaq_pct": -1.7791339252573701, "dow_pct": -1.559385380178191}`
- fear_index: `{"provider": "yfinance", "ticker": "^VIX", "level": 26.43000030517578, "change_pct": -3.1513396170765318, "neutral_level": 20.0, "level_pressure": 0.3215000152587891}`
- llm: provider=openrouter model=minimax/minimax-m2.5 ok=True latency_ms=20873
- llm_prompt_captured: **True**
- llm_response_captured: **True**
- themes: `["broad_market_leaders", "large_cap_quality", "defensive_sectors", "large_cap_stability"]`
- playbook: **pullback**
- scanner_source_policy: `{"preferred_sources": ["top_value", "top_volume", "sector_theme", "operator_watchlist"], "include_top_value": true, "include_top_volume": true, "include_change_rate": false, "include_condition_search": false, "include_sector_candidates": true, "include_watchlist": true, "top_candidate_pool": 18, "condition_limit": 0, "source_weights": {"top_value": 2.2, "top_volume": 1.9, "condition_search": 0.0, "sector_theme": 1.8, "operator_watchlist": 1.1, "top_change_rate": 0.0}, "reason": "defensive frame prioritizes liquid leaders and suppresses fast-mover sources"}`
- news_sample_titles: `["<b>코스피</b>, 외인 기관 순매도세에 하락마감", "국민의힘, “사법파괴·공소취소 거래, 이재명 정권 탄핵 사유” 파상공...", "블루산업개발, 1주당 액면가액 500원에서 100원으로 주식분할 결정", "인피니트헬스케어, 보통주 1주당 100원 현금배당 결정", "아톤, 보통주 1주당 50원 현금 결산배당 결정"]`

## Scanner
- candidate_source: **kiwoom_market_data**
- pool: before=5 after=5
- kiwoom_source_mix: `{"top_value": 18, "top_volume": 18, "top_change_rate": 0, "condition_search": 0, "sector_theme": 5, "operator_watchlist": 0}`
- condition_search: status=disabled source=disabled reason=condition_search_baseline_disabled
- scanner_source_policy: `{"include_top_value": true, "include_top_volume": true, "include_change_rate": false, "include_condition_search": false, "include_sector_candidates": true, "include_watchlist": true, "top_candidate_pool": 18, "condition_limit": 0, "preferred_sources": ["top_value", "top_volume", "sector_theme", "operator_watchlist"], "source_weights": {"top_value": 2.2, "top_volume": 1.9, "condition_search": 0.0, "sector_theme": 1.8, "operator_watchlist": 1.1, "top_change_rate": 0.0}, "reason": "defensive frame prioritizes liquid leaders and suppresses fast-mover sources"}`
- top_stock: **032820** top_score=1.2277819028637902
- top_ranked_symbols: `["032820", "000660", "005930", "069500", "122630"]`
- score_breakdown_summary: `{"trading_value": 0.22000000000000003, "momentum": 0.0, "trend": 0.0, "ma_alignment": 0.0, "adx_trend": 0.0, "volume_surge": 0.0, "intraday_strength": 0.0, "vwap_alignment": 0.0, "theme_boost": 0.0624, "sentiment": 0.0008809682334595269, "cross_section_rank": 0.0, "avoid_theme_penalty": -0.0, "risk_penalty": -0.0, "rank_bonus": 0.01}`
- selected_candidate: `{"symbol": "032820", "why": "top_value+top_volume+sector_theme", "sources": ["top_value", "top_volume", "sector_theme"], "source_scores": {"top_value": 2.14, "top_volume": 1.74, "sector_theme": 1.74}, "rank_score": 1.0, "universe_score": 5.62, "score_total": 1.2277819028637902, "risk_score": 0.1751781307393386, "confidence": 0.902858145235019, "score_breakdown": {"trading_value": 0.22000000000000003, "momentum": 0.0, "trend": 0.0, "ma_alignment": 0.0, "adx_trend": 0.0, "volume_surge": 0.0, "intraday_strength": 0.0, "vwap_alignment": 0.0, "theme_boost": 0.0624, "sentiment": 0.0008809682334595269, "cross_section_rank": 0.0, "avoid_theme_penalty": -0.0, "risk_penalty": -0.0, "rank_bonus": 0.01}, "feature_snapshot": {"quote_trading_value": 0.0, "quote_volume": 0.0, "intraday_change_pct": 0.0, "skill_quote_price": null, "engine_ma20_gap": null, "engine_ma60": null, "engine_ma120": null, "engine_adx14": null, "engine_trend_strength": null, "engine_volume_spike20": null, "engine_volatility20": null, "engine_vwap_distance": null, "engine_sector_relative_strength": null, "engine_cross_section_rank": null, "engine_regime": null, "engine_signal_score": 0.0}, "component_snapshot": {"news_sentiment": 0.1, "global_sentiment": -0.18439065369669294, "trading_value_component": 1.0, "momentum_component": 0.0, "trend_component": 0.0, "volume_surge_component": 0.0, "intraday_strength_component": 0.0, "theme_boost_component": 1.0, "sentiment_component": 0.014682803890992115, "volatility_penalty_component": 0.0, "gap_penalty_component": 0.0, "avoid_theme_penalty_component": 0.0}}`

## Monitor
- selected_symbol: **032820**
- entry_reason=no_position exit_reason=no_position monitor_reason=no_position
- position_age_seconds=None min_hold_blocked=False sell_cooldown_blocked=False
- thresholds: `{"stop_loss_pct": 0.0079784838, "take_profit_pct": 0.0095038396416, "max_hold_sec": 0, "time_stop_sec": 0, "trailing_stop_pct": 0.007875, "vol_expansion_ratio": 2.0, "news_shock_threshold": 0.0, "eod_flat_cutoff_min": 10}` min_hold=600 sell_cooldown=300 confirm_ticks=3
- strategy_frame_adjustments: `["monitor_guidance:defensive_exit", "risk_tone:conservative", "trade_aggressiveness:low"]`

## Supervisor
- verdict=approve allow=True reason=Allowed

## Executor
- execution_attempted=True ok=True broker_code=
- execution_mode=mock kiwoom_mode=mock broker_env=mock effective_mode=mock_executor
- api_id=ORDER_SUBMIT url= action=BUY symbol=032820 qty=1

## Reporter
- in_run_trace_available: **False**
- reporter_analysis_day_file_found: **False**
- reporter_analysis_found: **False**
- reporter_analysis_path: ``

## Next Command
- `python scripts/run_agent_pipeline_trace_report.py --run-id 6f151bbef8c349239d725e9628378a17 --json`
- `python scripts/query_trade_reason_chain.py --run-id 6f151bbef8c349239d725e9628378a17 --only-broker-success`