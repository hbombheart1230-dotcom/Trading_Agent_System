# Decision Story Report (2026-03-13)

- story_total: **4**
- rendered_story_total: **4**

## Run 99678b7e20bf451ba9533f450f5fd3a6

- run_id: `99678b7e20bf451ba9533f450f5fd3a6`
- symbol: **032820**
- final_action: **BUY 1**
- execution_status: **EXECUTED**
- decision_reason_summary: no_position
- technical_evidence: stop_loss_pct=0.0048423096, take_profit_pct=0.005023768780800001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.00608, vol_expansion_ratio=1.6
- sentiment_evidence: -
- guard_intervention: none
- operator_intervention: none
- final_outcome: executed

## Run e0301c71c7b2448994339aa53a44fa83

- run_id: `e0301c71c7b2448994339aa53a44fa83`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.007180635420000002, take_profit_pct=0.008363378884608001, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.007875, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run 93971142c32c4134a9253d7998cf050c

- run_id: `93971142c32c4134a9253d7998cf050c`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.004689394560000001, take_profit_pct=0.00522711180288, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.005200000000000001, vol_expansion_ratio=1.6
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped

## Run c3a41810c74e44abb6482a3c29c50172

- run_id: `c3a41810c74e44abb6482a3c29c50172`
- symbol: **032820**
- final_action: **UNKNOWN**
- execution_status: **BLOCKED**
- decision_reason_summary: GUARD_BLOCK (blocked by safety guard)
- technical_evidence: stop_loss_pct=0.00823865175, take_profit_pct=0.008791595366400002, max_hold_sec=0, time_stop_sec=0, trailing_stop_pct=0.00798, vol_expansion_ratio=2.0
- sentiment_evidence: -
- guard_intervention: NOOP intent skipped (no order sent)
- operator_intervention: none
- final_outcome: blocked:noop_intent_skipped
