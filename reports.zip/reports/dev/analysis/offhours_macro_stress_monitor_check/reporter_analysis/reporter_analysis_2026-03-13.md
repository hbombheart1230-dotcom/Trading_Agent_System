# Reporter Analysis (2026-03-13)

## Daily Operator Report

- system_health: **RED**
- 2026-03-13: health=RED
- trade_count=0 symbols=0
- monitor_status=stable scanner_status=appropriate supervisor_blocked_rate=75.00%
- next_action=High supervisor block rate: recalibrate strategy aggressiveness and guard limits for better intent quality.
- recommended_actions: `["High supervisor block rate: recalibrate strategy aggressiveness and guard limits for better intent quality."]`

- market_context: `{"global_sentiment_avg": null, "symbol_sentiment_avg": null, "llm_provider_top": {"openrouter": 4}, "llm_model_top": {"minimax/minimax-m2.5": 4}}`
- trades_executed: **1**
- trades_blocked: **3**
- major_decisions: `["defensive", "pullback"]`
- anomalies: `[]`

## Trade Decision Summaries

- trade_summary_total: **0**
| symbol | buy_reason | sell_reason | holding_duration_sec | exit_trigger |
| --- | --- | --- | ---: | --- |

## Trade Summary

- trade_count: **0**
- symbols_traded: `[]`

## Decision Chains

- run_total: **4**
- rendered_run_total: **4**
- run_id=99678b7e20bf451ba9533f450f5fd3a6 symbol=032820 action=BUY supervisor=APPROVED execution=EXECUTED buy_reason=unspecified sell_reason=-
- run_id=e0301c71c7b2448994339aa53a44fa83 symbol=032820 action=- supervisor=BLOCKED execution=BLOCKED buy_reason=- sell_reason=-
- run_id=93971142c32c4134a9253d7998cf050c symbol=032820 action=- supervisor=BLOCKED execution=BLOCKED buy_reason=- sell_reason=-
- run_id=c3a41810c74e44abb6482a3c29c50172 symbol=032820 action=- supervisor=BLOCKED execution=BLOCKED buy_reason=- sell_reason=-

## Decision Trace Chain Summary

- run_total: **4**
- complete_chain_total: **4**
- run_id=99678b7e20bf451ba9533f450f5fd3a6 selected=032820 monitor=no_position supervisor=approve executor=accepted_or_filled complete=True
- run_id=e0301c71c7b2448994339aa53a44fa83 selected=032820 monitor=hold supervisor=reject executor=not_attempted complete=True
- run_id=93971142c32c4134a9253d7998cf050c selected=032820 monitor=hold supervisor=reject executor=not_attempted complete=True
- run_id=c3a41810c74e44abb6482a3c29c50172 selected=032820 monitor=hold supervisor=reject executor=not_attempted complete=True

## Strategist Evaluation

- themes_proposed: `["large_cap_quality", "defensive_assets", "broad_market_leaders", "defensive_sectors", "large_cap_stability", "defensive_positioning"]`
- actual_market_leaders_by_scanner: `["032820"]`
- theme_alignment_status: **aligned**
- assessment: Strategist themes were reflected in scanner filtering.

## Scanner Evaluation

- scanner_summary_total: **4**
- selected_symbol_top: `{"032820": 4}`
- no_candidate_total: **0**
- avg_top_score: **1.1022**
- selection_status: **appropriate**
- assessment: Scanner selected symbols consistently with sufficient candidate pool.

## Monitor Evaluation

- monitor_summary_total: **4**
- monitor_reason_top: `{"hold": 3, "no_position": 1}`
- rapid_buy_sell_cycles: **0**
- monitor_status: **stable**
- assessment: Monitor flow is stable under current guards.

## Supervisor Activity

- verdict_total: **8**
- approved_total: **2**
- blocked_total: **6**
- blocked_rate: **75.00%**
- blocked_reason_top: `{"noop_intent_skipped": 6}`
- assessment: Supervisor blocks are elevated; review guard thresholds.

## Intent Flow Analysis

- intents_created: **0**
- intents_blocked: **3**
- intents_approved: **1**
- intents_executed: **1**
- reason_top: `{"monitor:hold": 3, "noop_intent_skipped": 3, "monitor:no_position": 1}`

## Strategy Effectiveness

- Strategist favored large_cap_quality theme.
- Scanner selected 032820 most frequently.
- Monitor exited mostly due to hold.
- Reporter focus priority: exit_quality

## Overtrading Diagnostics

- rapid_buy_sell_cycles(<120s): **0**
- noise_exit_related_count: **0**
- frequent_guard_block_count: **0**
- guard_block_rate: **0.00%**

## Incident / Post-Mortem Support

- incident_total: **0**

## Improvement Suggestions

- report_focus_targets: `["theme_accuracy", "exit_quality", "overtrading", "scanner_fit", "guard_blocks"]`
- High supervisor block rate: recalibrate strategy aggressiveness and guard limits for better intent quality.

## AI Review (Passive Optional Layer)

- ai_review_status: **disabled**
- ai_review_reason: REPORTER_AI_REVIEW_ENABLED is false
- ai_run_grade: **N/A**
- ai_findings: `[]`
- ai_root_causes: `[]`
- ai_improvement_suggestions: `[]`
- ai_agent_evaluations: `{}`

## Developer Summary

- decision_chain_run_total=4
- blocked_total=6 approved_total=2
- monitor_confirmed_exit_total=0
- scanner_no_candidate_total=0
- blocked_reason_top: `{"noop_intent_skipped": 6}`
- monitor_reason_top: `{"hold": 3, "no_position": 1}`

## Source Artifacts

- trade_explain_json: `C:\Trading_Agent_System\reports\dev\analysis\offhours_macro_stress_monitor_check\trade_explain\trade_explain_2026-03-13.json`
- trade_explain_md: `C:\Trading_Agent_System\reports\dev\analysis\offhours_macro_stress_monitor_check\trade_explain\trade_explain_2026-03-13.md`
- operator_summary_json: `C:\Trading_Agent_System\reports\dev\analysis\offhours_macro_stress_monitor_check\operator_summary\operator_summary_2026-03-13.json`
- operator_summary_md: `C:\Trading_Agent_System\reports\dev\analysis\offhours_macro_stress_monitor_check\operator_summary\operator_summary_2026-03-13.md`
- decision_story_md: `C:\Trading_Agent_System\reports\dev\analysis\offhours_macro_stress_monitor_check\decision_story\decision_story_2026-03-13.md`
- run_cards_md: `C:\Trading_Agent_System\reports\dev\analysis\offhours_macro_stress_monitor_check\run_cards\run_cards_2026-03-13.md`
- decision_story_total: `4`
- run_card_total: `4`
