# Agent Pipeline Trace (99678b7e20bf451ba9533f450f5fd3a6)

- day: **2026-03-13**
- event_log_path: `C:\Trading_Agent_System\data\logs\dev\analysis\offhours\offhours_macro_stress_monitor_check.jsonl`
- evidence_log_path: `C:\Trading_Agent_System\data\evidence_ledger\offhours_macro_stress_monitor_check.jsonl`

## Commander
- mode: ****
- agents: `[]`
- route_ts: ``
- end_status: ****

## Strategist
- news_source: **naver** headlines=60 symbols=12
- news_query_targets: `["코스피", "미국 증시", "국제유가", "환율", "중동", "달러", "방산", "금"]`
- news_query_reasoning: global_score=-0.17 macro_risk=0.00 index_trend=0.00 vix=26.02 vix_pressure=0.301; elevated fear index added defensive macro and hedge queries
- global_sentiment: score=-0.1691 status=ok source=yfinance
- global_index_moves: `{"sp500_pct": -1.5227676506708532, "nasdaq_pct": -1.7791339252573701, "dow_pct": -1.559385380178191}`
- fear_index: `{"provider": "yfinance", "ticker": "^VIX", "level": 26.020000457763672, "change_pct": -4.653720832383968, "neutral_level": 20.0, "level_pressure": 0.3010000228881836}`
- llm: provider=openrouter model=minimax/minimax-m2.5 ok=True latency_ms=15672
- llm_prompt_captured: **True**
- llm_response_captured: **True**
- themes: `["broad_market_leaders", "large_cap_quality", "defensive_assets", "defensive_sectors", "large_cap_stability"]`
- playbook: **defensive**
- scanner_source_policy: `{"preferred_sources": ["top_value", "sector_theme", "top_volume", "operator_watchlist"], "include_top_value": true, "include_top_volume": true, "include_change_rate": false, "include_condition_search": false, "include_sector_candidates": true, "include_watchlist": true, "top_candidate_pool": 18, "condition_limit": 0, "source_weights": {"top_value": 2.3, "top_volume": 1.9, "condition_search": 0.0, "sector_theme": 1.9, "operator_watchlist": 1.1, "top_change_rate": 0.0}, "reason": "defensive frame prioritizes liquid leaders and suppresses fast-mover sources; elevated fear index (vix=26.02, pressure=0.301) shifted source policy toward liquid defensive candidates"}`
- news_sample_titles: `["[업앤다운]게임주 상승…펄어비스↑·조이시티↓", "[증권가] NH투자증권 하나증권 한화투자증권 SK증권 토스증권", "<b>코스피</b>, 외인 기관 순매도세에 하락마감", "[주식마감] 오픈AI와 전략적 파트너십 체결 소식에 폴라리스오피스 상한...", "삼중고 거시 악재에도 7만 1,000달러 버틴 비트코인, 진정한 안전 자산 ..."]`

## Scanner
- candidate_source: **kiwoom_market_data**
- pool: before=5 after=5
- kiwoom_source_mix: `{"top_value": 18, "top_volume": 18, "top_change_rate": 0, "condition_search": 0, "sector_theme": 5, "operator_watchlist": 0}`
- condition_search: status=disabled source=disabled reason=condition_search_baseline_disabled
- scanner_source_policy: `{"include_top_value": true, "include_top_volume": true, "include_change_rate": false, "include_condition_search": false, "include_sector_candidates": true, "include_watchlist": true, "top_candidate_pool": 18, "condition_limit": 0, "preferred_sources": ["top_value", "sector_theme", "top_volume", "operator_watchlist"], "source_weights": {"top_value": 2.3, "top_volume": 1.9, "condition_search": 0.0, "sector_theme": 1.9, "operator_watchlist": 1.1, "top_change_rate": 0.0}, "reason": "defensive frame prioritizes liquid leaders and suppresses fast-mover sources; elevated fear index (vix=26.02, pressure=0.301) shifted source policy toward liquid defensive candidates"}`
- top_stock: **032820** top_score=1.2309363911004305
- top_ranked_symbols: `["032820", "000660", "005930", "069500", "122630"]`
- score_breakdown_summary: `{"trading_value": 0.21600000000000003, "momentum": 0.0, "trend": 0.0, "ma_alignment": 0.0, "adx_trend": 0.0, "volume_surge": 0.0, "intraday_strength": 0.0, "vwap_alignment": 0.0, "theme_boost": 0.067392, "sentiment": 0.001155924066167345, "cross_section_rank": 0.0, "avoid_theme_penalty": -0.0, "risk_penalty": -0.0, "rank_bonus": 0.01}`
- selected_candidate: `{"symbol": "032820", "why": "top_value+top_volume+sector_theme", "sources": ["top_value", "top_volume", "sector_theme"], "source_scores": {"top_value": 2.2399999999999998, "top_volume": 1.74, "sector_theme": 1.8199999999999998}, "rank_score": 1.0, "universe_score": 5.799999999999999, "score_total": 1.2309363911004305, "risk_score": 0.17212306593147395, "confidence": 0.9031021886099251, "score_breakdown": {"trading_value": 0.21600000000000003, "momentum": 0.0, "trend": 0.0, "ma_alignment": 0.0, "adx_trend": 0.0, "volume_surge": 0.0, "intraday_strength": 0.0, "vwap_alignment": 0.0, "theme_boost": 0.067392, "sentiment": 0.001155924066167345, "cross_section_rank": 0.0, "avoid_theme_penalty": -0.0, "risk_penalty": -0.0, "rank_bonus": 0.01}, "feature_snapshot": {"quote_trading_value": 0.0, "quote_volume": 0.0, "intraday_change_pct": 0.0, "skill_quote_price": null, "engine_ma20_gap": null, "engine_ma60": null, "engine_ma120": null, "engine_adx14": null, "engine_trend_strength": null, "engine_volume_spike20": null, "engine_volatility20": null, "engine_vwap_distance": null, "engine_sector_relative_strength": null, "engine_cross_section_rank": null, "engine_regime": null, "engine_signal_score": 0.0}, "component_snapshot": {"news_sentiment": 0.1, "global_sentiment": -0.1691153296573697, "trading_value_component": 1.0, "momentum_component": 0.0, "trend_component": 0.0, "volume_surge_component": 0.0, "intraday_strength_component": 0.0, "theme_boost_component": 1.0, "sentiment_component": 0.019265401102789084, "volatility_penalty_component": 0.0, "gap_penalty_component": 0.0, "avoid_theme_penalty_component": 0.0}}`

## Monitor
- selected_symbol: **032820**
- entry_reason=no_position exit_reason=no_position monitor_reason=no_position
- position_age_seconds=None min_hold_blocked=False sell_cooldown_blocked=False
- thresholds: `{"stop_loss_pct": 0.0048423096, "take_profit_pct": 0.005023768780800001, "max_hold_sec": 0, "time_stop_sec": 0, "trailing_stop_pct": 0.00608, "vol_expansion_ratio": 1.6, "news_shock_threshold": 0.0, "eod_flat_cutoff_min": 10}` min_hold=600 sell_cooldown=300 confirm_ticks=3
- strategy_frame_adjustments: `["monitor_guidance:defensive_exit", "risk_tone:conservative", "trade_aggressiveness:low"]`

## Supervisor
- verdict=approve allow=True reason=Allowed

## Executor
- execution_attempted=True ok=True broker_code=
- execution_mode=mock kiwoom_mode=mock broker_env=mock effective_mode=mock_executor
- api_id=ORDER_SUBMIT url= action=BUY symbol=032820 qty=1

## Reporter
- in_run_trace_available: **False**
- reporter_analysis_day_file_found: **False**
- reporter_analysis_found: **False**
- reporter_analysis_path: ``

## Next Command
- `python scripts/run_agent_pipeline_trace_report.py --run-id 99678b7e20bf451ba9533f450f5fd3a6 --json`
- `python scripts/query_trade_reason_chain.py --run-id 99678b7e20bf451ba9533f450f5fd3a6 --only-broker-success`