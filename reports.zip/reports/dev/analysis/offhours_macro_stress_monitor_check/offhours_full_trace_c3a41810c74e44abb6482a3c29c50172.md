# Off-Hours Full Trace Bundle (c3a41810c74e44abb6482a3c29c50172)

- ts: `2026-03-13T11:37:42.284114+00:00`
- day: **2026-03-13**
- symbol_hint: ``
- decision: **approve** reason=`within_policy`

## Strategist
- news_source: **naver**
- news_query_targets: `["코스피", "미국 증시", "국제유가", "환율", "중동", "달러", "방산", "금"]`
- news_query_reasoning: global_score=-0.17 macro_risk=0.00 index_trend=0.00 vix=26.06 vix_pressure=0.303; elevated fear index added defensive macro and hedge queries
- news_sample_titles: `["[이시각헤드라인] 3월 13일 뉴스리뷰", "국제유가 100달러 다시 넘자 달러환율도 장중 한때 1500원선 넘어", "[업앤다운]게임주 상승…펄어비스↑·조이시티↓", "[주식마감] 오픈AI와 전략적 파트너십 체결 소식에 폴라리스오피스 상한...", "삼중고 거시 악재에도 7만 1,000달러 버틴 비트코인, 진정한 안전 자산 ..."]`
- global_sentiment: score=-0.1703228595378205 status=ok source=yfinance
- global_index_moves: `{"sp500_pct": -1.5227676506708532, "nasdaq_pct": -1.7791339252573701, "dow_pct": -1.559385380178191}`
- fear_index: `{"provider": "yfinance", "ticker": "^VIX", "level": 26.059999465942383, "change_pct": -4.507150635107237, "neutral_level": 20.0, "level_pressure": 0.30299997329711914}`
- macro_stress: active=True flags=`["elevated_vix", "dollar_strength", "yield_rise"]` reason=`vix=26.06 pressure=0.303 dxy_pct=0.35 tnx_delta=0.0065`
- llm_model: `minimax/minimax-m2.5` ok=False
- themes: `["broad_market_leaders"]`
- playbook: **pullback**
- scanner_source_policy: `{"preferred_sources": ["top_value", "sector_theme", "top_volume", "operator_watchlist"], "include_top_value": true, "include_top_volume": true, "include_change_rate": false, "include_condition_search": false, "include_sector_candidates": true, "include_watchlist": true, "top_candidate_pool": 18, "condition_limit": 0, "source_weights": {"top_value": 2.3, "top_volume": 1.9, "condition_search": 0.0, "sector_theme": 1.9, "operator_watchlist": 1.1, "top_change_rate": 0.0}, "reason": "defensive frame prioritizes liquid leaders and suppresses fast-mover sources; elevated fear index (vix=26.06, pressure=0.303) shifted source policy toward liquid defensive candidates"}`

## Scanner
- candidate_source: **kiwoom_market_data**
- kiwoom_source_mix: `{"top_value": 18, "top_volume": 18, "top_change_rate": 0, "condition_search": 0, "sector_theme": 0, "operator_watchlist": 0}`
- scanner_source_policy: `{"include_top_value": true, "include_top_volume": true, "include_change_rate": false, "include_condition_search": false, "include_sector_candidates": true, "include_watchlist": true, "top_candidate_pool": 18, "condition_limit": 0, "preferred_sources": ["top_value", "sector_theme", "top_volume", "operator_watchlist"], "source_weights": {"top_value": 2.3, "top_volume": 1.9, "condition_search": 0.0, "sector_theme": 1.9, "operator_watchlist": 1.1, "top_change_rate": 0.0}, "reason": "defensive frame prioritizes liquid leaders and suppresses fast-mover sources; elevated fear index (vix=26.06, pressure=0.303) shifted source policy toward liquid defensive candidates"}`
- top_stock: **032820** top_score=1.1617131220867323
- selected_candidate: `{"symbol": "032820", "why": "top_value+top_volume", "sources": ["top_value", "top_volume"], "source_scores": {"top_value": 2.2399999999999998, "top_volume": 1.74}, "rank_score": 0.9707317073170731, "universe_score": 3.9799999999999995, "score_total": 1.1617131220867323, "risk_score": 0.1723645719075641, "confidence": 0.8927807136451016, "score_breakdown": {"trading_value": 0.22000000000000003, "momentum": 0.0, "trend": 0.0, "ma_alignment": 0.0, "adx_trend": 0.0, "volume_surge": 0.0, "intraday_strength": 0.0, "vwap_alignment": 0.0, "theme_boost": 0.0, "sentiment": 0.0011341885283192305, "cross_section_rank": 0.0, "avoid_theme_penalty": -0.0, "risk_penalty": -0.0, "rank_bonus": 0.009707317073170732}, "feature_snapshot": {"quote_trading_value": 0.0, "quote_volume": 0.0, "intraday_change_pct": 0.0, "skill_quote_price": null, "engine_ma20_gap": null, "engine_ma60": null, "engine_ma120": null, "engine_adx14": null, "engine_trend_strength": null, "engine_volume_spike20": null, "engine_volatility20": null, "engine_vwap_distance": null, "engine_sector_relative_strength": null, "engine_cross_section_rank": null, "engine_regime": null, "engine_signal_score": 0.0}, "component_snapshot": {"news_sentiment": 0.1, "global_sentiment": -0.1703228595378205, "trading_value_component": 1.0, "momentum_component": 0.0, "trend_component": 0.0, "volume_surge_component": 0.0, "intraday_strength_component": 0.0, "theme_boost_component": 0.0, "sentiment_component": 0.018903142138653843, "volatility_penalty_component": 0.0, "gap_penalty_component": 0.0, "avoid_theme_penalty_component": 0.0}}`

## Monitor
- entry_reason=`hold` exit_reason=`hold` monitor_reason=`hold`
- thresholds: `{"stop_loss_pct": 0.00823865175, "take_profit_pct": 0.008791595366400002, "max_hold_sec": 0, "time_stop_sec": 0, "trailing_stop_pct": 0.00798, "vol_expansion_ratio": 2.0, "news_shock_threshold": 0.0, "eod_flat_cutoff_min": 10}` min_hold=600 cooldown=300 confirm=3

## Execution
- action= symbol= qty=None mode= ok=False
- execution_mode= kiwoom_mode= broker_env= effective_mode=

## Reporter
- improvement_suggestions: `["High supervisor block rate: recalibrate strategy aggressiveness and guard limits for better intent quality."]`
- next_learning_focus: `["theme_accuracy", "exit_quality", "overtrading", "scanner_fit", "guard_blocks"]`

## Artifacts
- event_log_path: `C:\Trading_Agent_System\data\logs\dev\analysis\offhours\offhours_macro_stress_monitor_check.jsonl`
- evidence_log_path: `C:\Trading_Agent_System\data\evidence_ledger\offhours_macro_stress_monitor_check.jsonl`
- state_path: `C:\Trading_Agent_System\data\state\offhours_macro_stress_monitor_check.json`
- agent_pipeline_trace_json: `C:\Trading_Agent_System\reports\dev\analysis\offhours_macro_stress_monitor_check\agent_pipeline_trace\agent_pipeline_trace_c3a41810c74e44abb648.json`
- agent_pipeline_trace_md: `C:\Trading_Agent_System\reports\dev\analysis\offhours_macro_stress_monitor_check\agent_pipeline_trace\agent_pipeline_trace_c3a41810c74e44abb648.md`
- trade_explain_json: `C:\Trading_Agent_System\reports\dev\analysis\offhours_macro_stress_monitor_check\trade_explain\trade_explain_2026-03-13.json`
- trade_explain_md: `C:\Trading_Agent_System\reports\dev\analysis\offhours_macro_stress_monitor_check\trade_explain\trade_explain_2026-03-13.md`
- reporter_analysis_json: `C:\Trading_Agent_System\reports\dev\analysis\offhours_macro_stress_monitor_check\reporter_analysis\reporter_analysis_2026-03-13.json`
- reporter_analysis_md: `C:\Trading_Agent_System\reports\dev\analysis\offhours_macro_stress_monitor_check\reporter_analysis\reporter_analysis_2026-03-13.md`
