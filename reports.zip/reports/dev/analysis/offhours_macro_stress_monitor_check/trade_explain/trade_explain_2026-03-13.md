# Trade Explain Report (2026-03-13)

- event_log_path: `C:\Trading_Agent_System\data\logs\dev\analysis\offhours\offhours_macro_stress_monitor_check.jsonl`
- executions_total: **1**
- sell_pairs_total: **0**

## Executive Summary

- symbols_executed: `['032820']`
- action_counts: `{'BUY': 1}`
- symbol_side_counts: `{'032820:BUY': 1}`
- short_holds_lt_120s: **0**

## Agent Activity Snapshot

- `strategist_llm`: 4
- `strategist`: 4
- `decision_trace`: 20
- `scanner`: 4
- `monitor`: 4
- `execute_from_packet`: 13

## Report Inventory

- `C:\Trading_Agent_System\reports\dev\analysis\offhours_macro_stress_monitor_check\operator_summary\operator_summary_2026-03-13.md`
- `C:\Trading_Agent_System\reports\dev\analysis\offhours_macro_stress_monitor_check\decision_story\decision_story_2026-03-13.md`
- `C:\Trading_Agent_System\reports\dev\analysis\offhours_macro_stress_monitor_check\run_cards\run_cards_2026-03-13.md`
- `C:\Trading_Agent_System\reports\dev\analysis\offhours_macro_stress_monitor_check\metrics\metrics_2026-03-13.md`

## Execution Timeline (Latest)

| ts | run_id | symbol | action | qty | price | strategy | reason |
| --- | --- | --- | --- | ---: | ---: | --- | --- |
| 2026-03-13T11:25:52+00:00 | `99678b7e20bf451ba9533f450f5fd3a6` | 032820 | BUY | 1 | 70000.0 | - | - |

## Sell Pair Analysis (FIFO, Latest)

No SELL pairs found.
## Data Gaps

- scanner_score_breakdown_missing_total: 0
- news_items_missing_total: 1
- note: news headline text and scanner score_breakdown are limited by current event-log payload policy.
