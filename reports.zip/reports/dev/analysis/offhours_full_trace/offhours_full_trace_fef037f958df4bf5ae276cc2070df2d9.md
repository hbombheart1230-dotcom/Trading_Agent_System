# Off-Hours Full Trace Bundle (fef037f958df4bf5ae276cc2070df2d9)

- ts: `2026-03-16T11:13:38.128240+00:00`
- day: **2026-03-16**
- symbol_hint: ``
- decision: **approve** reason=`within_policy`

## Strategist
- news_source: **naver**
- news_query_targets: `["코스피", "미국 증시", "국제유가", "환율", "중동", "하락 종목 수", "약세 업종", "달러", "방산", "금"]`
- news_query_reasoning: global_score=-0.11 macro_risk=0.00 index_trend=0.00 vix=25.49 vix_pressure=0.274; elevated fear index added defensive macro and hedge queries; weak breadth added 하락 종목 수/약세 업종 queries
- news_sample_titles: `["엠앤씨솔루션, 현대로템과 단일판매ㆍ공급계약 체결", "NewsItem(title=\"연 15% 수익 목표 'SOL 200타겟 위클리 커버드콜 ETF' 상장\", url='http://www.newsbrite.net/news/articleView.html?idxno=1969", "고유가·고환율에도 <b>코스피</b> 1%대 상승…반도체 강세", "NewsItem(title=\"'K공포지수' 전쟁 직전 수준으로 복귀\", url='https://n.news.naver.com/mnews/article/088/0001001274?sid=101', source='nav", "[AI의 종목 이야기] 印 <b>증시</b> 시총, 중동 전쟁 이후 669조원 증발"]`
- global_sentiment: score=-0.10924166526495792 status=ok source=yfinance
- global_index_moves: `{"sp500_pct": -0.6059115470564369, "nasdaq_pct": -0.9260544757082045, "dow_pct": -0.255759013115997}`
- fear_index: `{"provider": "yfinance", "ticker": "^VIX", "level": 25.489999771118164, "change_pct": -6.252301322355869, "neutral_level": 20.0, "level_pressure": 0.2744999885559082}`
- macro_stress: active=True flags=`["elevated_vix", "dollar_strength"]` reason=`vix=25.49 pressure=0.274 dxy_pct=0.76 tnx_delta=0.0012`
- llm_model: `openrouter/auto` ok=True
- themes: `["broad_market_leaders", "semiconductor_cycle", "defensive_large_cap"]`
- playbook: **pullback**
- scanner_source_policy: `{"preferred_sources": ["top_value", "sector_theme", "top_volume", "operator_watchlist"], "include_top_value": true, "include_top_volume": true, "include_change_rate": false, "include_condition_search": false, "include_sector_candidates": true, "include_watchlist": true, "top_candidate_pool": 18, "condition_limit": 0, "source_weights": {"top_value": 2.3, "top_volume": 1.9, "condition_search": 0.0, "sector_theme": 1.9, "operator_watchlist": 1.1, "top_change_rate": 0.0}, "reason": "defensive frame prioritizes liquid leaders and suppresses fast-mover sources; elevated fear index (vix=25.49, pressure=0.274) shifted source policy toward liquid defensive candidates"}`

## Scanner
- candidate_source: **kiwoom_market_data**
- kiwoom_source_mix: `{"top_value": 17, "top_volume": 18, "top_change_rate": 0, "condition_search": 0, "sector_theme": 5, "operator_watchlist": 0}`
- scanner_source_policy: `{"include_top_value": true, "include_top_volume": true, "include_change_rate": false, "include_condition_search": false, "include_sector_candidates": true, "include_watchlist": true, "top_candidate_pool": 18, "condition_limit": 0, "preferred_sources": ["top_value", "sector_theme", "top_volume", "operator_watchlist"], "source_weights": {"top_value": 2.3, "top_volume": 1.9, "condition_search": 0.0, "sector_theme": 1.9, "operator_watchlist": 1.1, "top_change_rate": 0.0}, "reason": "defensive frame prioritizes liquid leaders and suppresses fast-mover sources; elevated fear index (vix=25.49, pressure=0.274) shifted source policy toward liquid defensive candidates"}`
- top_stock: **000660** top_score=1.4575172128630556
- selected_candidate: `{"symbol": "000660", "why": "top_value+sector_theme", "sources": ["top_value", "sector_theme"], "source_scores": {"top_value": 2.28, "sector_theme": 1.8599999999999999}, "rank_score": 0.6900000000000001, "universe_score": 4.14, "score_total": 1.4575172128630556, "risk_score": 0.4199750664567859, "confidence": 0.9317312069084328, "score_breakdown": {"trading_value": 0.22000000000000003, "momentum": 0.209, "trend": 0.04807239499137766, "ma_alignment": 0.03966732000000001, "adx_trend": 0.0, "volume_surge": 0.0, "intraday_strength": 0.03591, "vwap_alignment": 0.03591, "theme_boost": 0.0624, "sentiment": 0.005383650025230757, "cross_section_rank": 0.05, "avoid_theme_penalty": -0.0, "repeat_symbol_penalty": -0.0, "risk_penalty": -0.08990466562705704, "rank_bonus": 0.006900000000000001}, "feature_snapshot": {"quote_trading_value": 0.0, "quote_volume": 0.0, "intraday_change_pct": 0.0, "skill_quote_price": null, "engine_ma20_gap": 0.03687134530753622, "engine_ma60": null, "engine_ma120": null, "engine_adx14": 7.416120491583941, "engine_trend_strength": 0.07416120491583941, "engine_volume_spike20": 0.8564149553100795, "engine_volatility20": 0.06344667620054205, "engine_vwap_distance": 0.1861250685202176, "engine_sector_relative_strength": 0.05591398024478189, "engine_cross_section_rank": 1.0, "engine_regime": "high_volatility", "engine_signal_score": 0.5}, "component_snapshot": {"news_sentiment": 0.175, "global_sentiment": -0.10924166526495792, "trading_value_component": 1.0, "momentum_component": 1.0, "trend_component": 0.19087254221212774, "volume_surge_component": 0.0, "intraday_strength_component": 0.3, "theme_boost_component": 1.0, "sentiment_component": 0.08972750042051261, "volatility_penalty_component": 0.6689335240108409, "gap_penalty_component": 0.0, "avoid_theme_penalty_component": 0.0}}`

## Monitor
- entry_reason=`no_position` exit_reason=`no_position` monitor_reason=`no_position`
- thresholds: `{"stop_loss_pct": 0.08, "take_profit_pct": 0.008933609263103999, "max_hold_sec": 0, "time_stop_sec": 0, "trailing_stop_pct": 0.04, "vol_expansion_ratio": 2.0, "news_shock_threshold": 0.0, "eod_flat_cutoff_min": 10}` min_hold=600 cooldown=300 confirm=2

## Execution
- action=BUY symbol=000660 qty=1 mode=mock ok=True
- execution_mode=mock kiwoom_mode=mock broker_env=mock effective_mode=mock_executor

## Reporter
- improvement_suggestions: `["No critical gaps detected; keep current baseline and continue daily report-driven calibration."]`
- next_learning_focus: `["exit_quality", "overtrading", "scanner_fit"]`

## Artifacts
- event_log_path: `C:\Trading_Agent_System\data\logs\dev\analysis\offhours\offhours_full_trace.jsonl`
- evidence_log_path: `C:\Trading_Agent_System\data\evidence_ledger\offhours_full_trace.jsonl`
- state_path: `C:\Trading_Agent_System\data\state\offhours_full_trace.json`
- agent_pipeline_trace_json: `C:\Trading_Agent_System\reports\dev\analysis\offhours_full_trace\agent_pipeline_trace\agent_pipeline_trace_fef037f958df4bf5ae27.json`
- agent_pipeline_trace_md: `C:\Trading_Agent_System\reports\dev\analysis\offhours_full_trace\agent_pipeline_trace\agent_pipeline_trace_fef037f958df4bf5ae27.md`
- trade_explain_json: `C:\Trading_Agent_System\reports\dev\analysis\offhours_full_trace\trade_explain\trade_explain_2026-03-16.json`
- trade_explain_md: `C:\Trading_Agent_System\reports\dev\analysis\offhours_full_trace\trade_explain\trade_explain_2026-03-16.md`
- reporter_analysis_json: `C:\Trading_Agent_System\reports\dev\analysis\offhours_full_trace\reporter_analysis\reporter_analysis_2026-03-16.json`
- reporter_analysis_md: `C:\Trading_Agent_System\reports\dev\analysis\offhours_full_trace\reporter_analysis\reporter_analysis_2026-03-16.md`
