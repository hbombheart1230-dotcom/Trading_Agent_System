# Ops Diagnostic Report (2026-03-05)

- schema_version: **ops_diagnostic.v1**
- events: **674**
- runs: **152**

## Execution

- execution_total: **58**
- verdict_block_total: **78**
- broker_success_total: **54**
- broker_fail_total: **2**
- broker_unknown_total: **2**
- broker_success_rate: **93.10%**

### verdict_reason_topN

- noop_intent_skipped: 72
- denied_by_test: 2
- duplicate_buy_position_exists: 2
- insufficient_mock_cash: 2

### broker_failure_topN

- 20: 2

## NOOP

- total: **79**

### focus_reason_ratio

- model_no_signal: 58.23%
- missing_rationale: 5.06%
- post_exit_cooldown: 31.65%

## Strategist LLM

- total: **76**
- ok_total: **74**
- error_total: **2**
- latency_ms_p50: **12278.0**
- latency_ms_p95: **25863.0**

