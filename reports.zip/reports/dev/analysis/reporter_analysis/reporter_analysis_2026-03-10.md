# Reporter Analysis (2026-03-10)

## Daily Operator Report

- market_context: `{"global_sentiment_avg": 0.044843, "symbol_sentiment_avg": 0.078761, "llm_provider_top": {"openai": 212}, "llm_model_top": {"test-model": 172, "minimax/minimax-m2.5": 34, "gpt-4.1-mini": 6}}`
- trades_executed: **313**
- trades_blocked: **369**
- major_decisions: `["RegimeMomentumV1", "ExitPolicyStrategist", "CooldownStrategist", "OpenAIStrategist", "RuleStrategist"]`
- anomalies: `["unexpected_rapid_exit"]`

## Trade Decision Summaries

- trade_summary_total: **56**
| symbol | buy_reason | sell_reason | holding_duration_sec | exit_trigger |
| --- | --- | --- | ---: | --- |
| 005930 | unspecified | exit_policy:max_hold | 62 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 62 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 63 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 64 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 62 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 63 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 62 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 63 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 64 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 63 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 64 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 63 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 63 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 62 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 63 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 63 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 65 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 63 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 63 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 63 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 63 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 71 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 63 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 64 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 63 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 63 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 63 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 63 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 65 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 165 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 1481 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 1620 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 1581 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 1592 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 1975 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 1860 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 2050 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 2420 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 2551 | exit_policy:max_hold |
| 005930 | unspecified | exit_policy:max_hold | 2189 | exit_policy:max_hold |

## Intent Flow Analysis

- intents_created: **0**
- intents_blocked: **369**
- intents_approved: **0**
- intents_executed: **0**
- reason_top: `{"noop_intent_skipped": 297, "monitor:hold": 160, "monitor:confirmed_exit_signal": 56, "denied_by_test": 24, "duplicate_buy_position_exists": 24, "insufficient_mock_cash": 24, "monitor:pending_exit_lock": 16, "monitor:min_hold_active": 8, "monitor:exit_signal_pending_confirmation": 8, "monitor:no_position": 8, "monitor:cooldown_active": 8, "monitor:emergency_exit_signal": 8}`

## Strategy Effectiveness

- Strategist theme evidence was not captured in current event payload.
- Scanner selected AAA most frequently.
- Monitor exited mostly due to take_profit.

## Overtrading Diagnostics

- rapid_buy_sell_cycles(<120s): **29**
- noise_exit_related_count: **16**
- frequent_guard_block_count: **0**
- guard_block_rate: **0.00%**

## Incident / Post-Mortem Support

- incident_total: **1**
- [YELLOW] unexpected_rapid_exit: rapid_buy_sell_cycles=29

## Source Artifacts

- trade_explain_json: `reports\trade_explain\trade_explain_2026-03-10.json`
- trade_explain_md: `reports\trade_explain\trade_explain_2026-03-10.md`
- operator_summary_json: `reports\operator_summary\operator_summary_2026-03-10.json`
- operator_summary_md: `reports\operator_summary\operator_summary_2026-03-10.md`
- decision_story_md: `reports\decision_story\decision_story_2026-03-10.md`
- run_cards_md: `reports\run_cards\run_cards_2026-03-10.md`
- decision_story_total: `935`
- run_card_total: `935`
