# Reporter Analysis (2026-03-12)

## Daily Operator Report

- system_health: **YELLOW**
- 2026-03-12: health=YELLOW
- trade_count=80 symbols=9
- monitor_status=overtrading_risk scanner_status=appropriate supervisor_blocked_rate=22.50%
- incident_total=3
- recommended_actions: `["Reduce monitor flip risk by increasing confirmation strictness or widening non-emergency exit thresholds.", "Run incident postmortem and convert top anomaly into explicit preopen/checklist gate before next session."]`

- market_context: `{"global_sentiment_avg": null, "symbol_sentiment_avg": null, "llm_provider_top": {"openrouter": 226, "openai": 11}, "llm_model_top": {"minimax/minimax-m2.5": 228, "test-model": 9}}`
- trades_executed: **198**
- trades_blocked: **49**
- major_decisions: `["RegimeMomentumV1", "RuleStrategist", "OpenAIStrategist", "AlwaysBuyStrategist", "ExitPolicyStrategist"]`
- anomalies: `["unexpected_rapid_exit", "high_block_rate", "execution_anomaly"]`

## Trade Decision Summaries

- trade_summary_total: **80**
| symbol | buy_reason | sell_reason | holding_duration_sec | exit_trigger |
| --- | --- | --- | ---: | --- |
| 005930 | unspecified | unspecified | 0 | max_hold |
| 005930 | unspecified | unspecified | 0 | max_hold |
| 032820 | unspecified | unspecified | 5484 | max_hold |
| 032820 | unspecified | unspecified | 5565 | max_hold |
| 032820 | unspecified | unspecified | 5208 | max_hold |
| 005930 | unspecified | unspecified | 0 | unspecified |
| 032820 | unspecified | unspecified | 4639 | stop_loss |
| 006910 | unspecified | unspecified | 6766 | stop_loss |
| 024060 | unspecified | unspecified | 7259 | stop_loss |
| 051910 | unspecified | unspecified | 0 | stop_loss |
| 357880 | unspecified | unspecified | 5591 | stop_loss |
| 005930 | unspecified | unspecified | 490 | stop_loss |
| 380540 | unspecified | unspecified | 7034 | take_profit |
| 380540 | unspecified | unspecified | 83 | max_hold |
| 032820 | unspecified | unspecified | 113 | max_hold |
| 046120 | unspecified | unspecified | 88 | max_hold |
| 032820 | unspecified | unspecified | 84 | max_hold |
| 032820 | unspecified | unspecified | 108 | max_hold |
| 032820 | unspecified | unspecified | 83 | max_hold |
| 032820 | unspecified | unspecified | 85 | max_hold |
| 005930 | unspecified | unspecified | 1400 | unspecified |
| 032820 | unspecified | unspecified | 289 | stop_loss |
| 005930 | unspecified | unspecified | 459 | stop_loss |
| 032820 | unspecified | unspecified | 70 | max_hold |
| 032820 | unspecified | unspecified | 142 | max_hold |
| 032820 | unspecified | unspecified | 83 | max_hold |
| 032820 | unspecified | unspecified | 79 | max_hold |
| 032820 | unspecified | unspecified | 82 | max_hold |
| 380540 | unspecified | unspecified | 186 | max_hold |
| 032820 | unspecified | unspecified | 86 | max_hold |
| 032820 | unspecified | unspecified | 83 | max_hold |
| 032820 | unspecified | unspecified | 77 | max_hold |
| 032820 | unspecified | unspecified | 88 | max_hold |
| 032820 | unspecified | unspecified | 75 | max_hold |
| 380540 | unspecified | unspecified | 125 | max_hold |
| 032820 | unspecified | unspecified | 70 | max_hold |
| 032820 | unspecified | unspecified | 75 | max_hold |
| 032820 | unspecified | unspecified | 70 | max_hold |
| 380540 | unspecified | unspecified | 76 | max_hold |
| 380540 | unspecified | unspecified | 84 | max_hold |

## Trade Summary

- trade_count: **80**
- symbols_traded: `["005930", "006910", "024060", "032820", "046120", "051910", "095910", "357880", "380540"]`

## Decision Chains

- run_total: **340**
- rendered_run_total: **200**
- run_id=75c3739b0d1a4f7cb5cc97910e99209c symbol=024060 action=BUY supervisor=APPROVED execution=EXECUTED_OK buy_reason=unspecified sell_reason=-
- run_id=4ecc4f6b97254c69a58207d23fe430ab symbol=024060 action=BUY supervisor=APPROVED execution=EXECUTED_OK buy_reason=unspecified sell_reason=-
- run_id=cfedf8f1a65d49d4809249695154bc18 symbol=032820 action=BUY supervisor=APPROVED execution=EXECUTED_OK buy_reason=unspecified sell_reason=-
- run_id=40f6e2e3aab04942913632725de79ee8 symbol=032820 action=BUY supervisor=APPROVED execution=EXECUTED_OK buy_reason=unspecified sell_reason=-
- run_id=4b0e90a60eff42f88e2c6ca53e0ea264 symbol=006910 action=BUY supervisor=APPROVED execution=EXECUTED_OK buy_reason=unspecified sell_reason=-
- run_id=d00cca0f269643eb8c1a97f6ecb30b1e symbol=006910 action=BUY supervisor=APPROVED execution=EXECUTED_OK buy_reason=unspecified sell_reason=-
- run_id=b15496873e274707955dccf2c02f7bdc symbol=380540 action=BUY supervisor=APPROVED execution=EXECUTED_OK buy_reason=unspecified sell_reason=-
- run_id=daf656d3405c4cf0a59e230a8e1f4f25 symbol=380540 action=BUY supervisor=APPROVED execution=EXECUTED_OK buy_reason=unspecified sell_reason=-
- run_id=a9cb0ebaacd64e8d92b9312b68dd23e3 symbol=307870 action=BUY supervisor=APPROVED execution=EXECUTED_FAIL buy_reason=unspecified sell_reason=-
- run_id=685be82701b9464196eb0aa6f6a68efa symbol=032820 action=BUY supervisor=APPROVED execution=EXECUTED_OK buy_reason=unspecified sell_reason=-

## Decision Trace Chain Summary

- run_total: **271**
- complete_chain_total: **229**
- run_id=75c3739b0d1a4f7cb5cc97910e99209c selected=024060 monitor=no_position supervisor=approve executor=accepted_or_filled complete=True
- run_id=4ecc4f6b97254c69a58207d23fe430ab selected=024060 monitor=no_position supervisor=approve executor=accepted_or_filled complete=True
- run_id=cfedf8f1a65d49d4809249695154bc18 selected=032820 monitor=no_position supervisor=approve executor=accepted_or_filled complete=True
- run_id=40f6e2e3aab04942913632725de79ee8 selected=032820 monitor=no_position supervisor=approve executor=accepted_or_filled complete=True
- run_id=4b0e90a60eff42f88e2c6ca53e0ea264 selected=006910 monitor=no_position supervisor=approve executor=accepted_or_filled complete=True
- run_id=d00cca0f269643eb8c1a97f6ecb30b1e selected=006910 monitor=no_position supervisor=approve executor=accepted_or_filled complete=True
- run_id=b15496873e274707955dccf2c02f7bdc selected=380540 monitor=no_position supervisor=approve executor=accepted_or_filled complete=True
- run_id=daf656d3405c4cf0a59e230a8e1f4f25 selected=380540 monitor=no_position supervisor=approve executor=accepted_or_filled complete=True
- run_id=a9cb0ebaacd64e8d92b9312b68dd23e3 selected=307870 monitor=no_position supervisor=approve executor=rejected complete=True
- run_id=685be82701b9464196eb0aa6f6a68efa selected=032820 monitor=no_position supervisor=approve executor=accepted_or_filled complete=True

## Strategist Evaluation

- themes_proposed: `["broad_market_leaders", "low_volatility", "quality_defensive", "quality_factor", "quality_defense", "low_volatility_leaders", "large_cap_stability", "quality_defensives"]`
- actual_market_leaders_by_scanner: `["032820", "357880", "380540", "034020", "005930", "095910", "AAA", "024060"]`
- theme_alignment_status: **aligned**
- assessment: Strategist themes were reflected in scanner filtering.

## Scanner Evaluation

- scanner_summary_total: **268**
- selected_symbol_top: `{"032820": 164, "357880": 28, "380540": 23, "034020": 20, "005930": 7, "095910": 7, "AAA": 5, "024060": 2, "006910": 2, "01": 2}`
- no_candidate_total: **0**
- avg_top_score: **1.0762**
- selection_status: **appropriate**
- assessment: Scanner selected symbols consistently with sufficient candidate pool.

## Monitor Evaluation

- monitor_summary_total: **494**
- monitor_reason_top: `{"confirmed_exit_signal": 225, "no_position": 140, "hold": 62, "min_hold_active": 17, "pending_exit_lock": 15, "exit_signal_pending_confirmation": 14, "emergency_exit_signal": 11, "cooldown_active": 10}`
- rapid_buy_sell_cycles: **62**
- monitor_status: **overtrading_risk**
- assessment: Monitor shows overtrading risk; tighten exit confirmation or thresholds.

## Supervisor Activity

- verdict_total: **511**
- approved_total: **396**
- blocked_total: **115**
- blocked_rate: **22.50%**
- blocked_reason_top: `{"noop_intent_skipped": 84, "portfolio_snapshot_reader_error": 10, "denied_by_test": 4, "duplicate_buy_position_exists": 4, "insufficient_mock_cash": 4, "order_qty_limit_exceeded": 3, "Daily loss limit exceeded": 2, "symbol_not_allowlisted": 2, "order_notional_limit_exceeded": 2}`
- assessment: Supervisor activity within normal range.

## Intent Flow Analysis

- intents_created: **13**
- intents_blocked: **49**
- intents_approved: **198**
- intents_executed: **198**
- reason_top: `{"monitor:confirmed_exit_signal": 225, "monitor:no_position": 140, "monitor:hold": 62, "noop_intent_skipped": 42, "monitor:min_hold_active": 17, "monitor:pending_exit_lock": 15, "monitor:exit_signal_pending_confirmation": 14, "monitor:emergency_exit_signal": 11, "monitor:cooldown_active": 10, "denied_by_test": 2, "duplicate_buy_position_exists": 2, "insufficient_mock_cash": 2}`

## Strategy Effectiveness

- Strategist favored broad_market_leaders theme.
- Scanner selected 032820 most frequently.
- Monitor exited mostly due to no_position.
- Reporter focus priority: theme_accuracy

## Overtrading Diagnostics

- rapid_buy_sell_cycles(<120s): **62**
- noise_exit_related_count: **24**
- frequent_guard_block_count: **0**
- guard_block_rate: **376.92%**

## Incident / Post-Mortem Support

- incident_total: **3**
- [YELLOW] unexpected_rapid_exit: rapid_buy_sell_cycles=62
- [RED] high_block_rate: guard_block_rate=376.92%
- [RED] execution_anomaly: execution_anomaly_total=12

## Improvement Suggestions

- report_focus_targets: `["theme_accuracy", "exit_quality", "overtrading", "scanner_fit"]`
- Reduce monitor flip risk by increasing confirmation strictness or widening non-emergency exit thresholds.
- Run incident postmortem and convert top anomaly into explicit preopen/checklist gate before next session.

## AI Review (Passive Optional Layer)

- ai_review_status: **disabled**
- ai_review_reason: REPORTER_AI_REVIEW_ENABLED is false
- ai_run_grade: **N/A**
- ai_findings: `[]`
- ai_root_causes: `[]`
- ai_improvement_suggestions: `[]`
- ai_agent_evaluations: `{}`

## Developer Summary

- decision_chain_run_total=340
- blocked_total=115 approved_total=396
- monitor_confirmed_exit_total=236
- scanner_no_candidate_total=0
- blocked_reason_top: `{"noop_intent_skipped": 84, "portfolio_snapshot_reader_error": 10, "denied_by_test": 4, "duplicate_buy_position_exists": 4, "insufficient_mock_cash": 4, "order_qty_limit_exceeded": 3, "Daily loss limit exceeded": 2, "symbol_not_allowlisted": 2, "order_notional_limit_exceeded": 2}`
- monitor_reason_top: `{"confirmed_exit_signal": 225, "no_position": 140, "hold": 62, "min_hold_active": 17, "pending_exit_lock": 15, "exit_signal_pending_confirmation": 14, "emergency_exit_signal": 11, "cooldown_active": 10}`

## Source Artifacts

- trade_explain_json: `reports\trade_explain\trade_explain_2026-03-12.json`
- trade_explain_md: `reports\trade_explain\trade_explain_2026-03-12.md`
- operator_summary_json: `reports\operator_summary\operator_summary_2026-03-12.json`
- operator_summary_md: `reports\operator_summary\operator_summary_2026-03-12.md`
- decision_story_md: `reports\decision_story\decision_story_2026-03-12.md`
- run_cards_md: `reports\run_cards\run_cards_2026-03-12.md`
- decision_story_total: `258`
- run_card_total: `258`
