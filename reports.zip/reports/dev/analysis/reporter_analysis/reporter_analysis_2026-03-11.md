# Reporter Analysis (2026-03-11)

## Daily Operator Report

- system_health: **GREEN**
- 2026-03-11: health=GREEN
- trade_count=0 symbols=0
- monitor_status=stable scanner_status=appropriate supervisor_blocked_rate=0.00%
- next_action=Improve strategist-to-market alignment evidence: add stronger theme mapping and leader validation inputs.
- recommended_actions: `["Improve strategist-to-market alignment evidence: add stronger theme mapping and leader validation inputs."]`

- market_context: `{"global_sentiment_avg": null, "symbol_sentiment_avg": null, "llm_provider_top": {}, "llm_model_top": {}}`
- trades_executed: **96**
- trades_blocked: **0**
- major_decisions: `[]`
- anomalies: `[]`

## Trade Decision Summaries

- trade_summary_total: **0**
| symbol | buy_reason | sell_reason | holding_duration_sec | exit_trigger |
| --- | --- | --- | ---: | --- |

## Trade Summary

- trade_count: **0**
- symbols_traded: `[]`

## Decision Chains

- run_total: **96**
- rendered_run_total: **96**
- run_id=844e3637393746229455f6e76e94de62 symbol=051910 action=BUY supervisor=APPROVED execution=EXECUTED_OK buy_reason=unspecified sell_reason=-
- run_id=17a945cea025441db4c011818a8b65a5 symbol=051910 action=BUY supervisor=APPROVED execution=EXECUTED_OK buy_reason=unspecified sell_reason=-
- run_id=3ce0c024c3f8427087cb6c00180d6b57 symbol=051910 action=BUY supervisor=APPROVED execution=EXECUTED_OK buy_reason=unspecified sell_reason=-
- run_id=ff798fd7113e47bca202200cb552f7eb symbol=051910 action=BUY supervisor=APPROVED execution=EXECUTED_OK buy_reason=unspecified sell_reason=-
- run_id=b8021461bd5c404093a65c7904de247f symbol=051910 action=BUY supervisor=APPROVED execution=EXECUTED_OK buy_reason=unspecified sell_reason=-
- run_id=2512a634535e4d1bbc2872eb1975f28a symbol=051910 action=BUY supervisor=APPROVED execution=EXECUTED_OK buy_reason=unspecified sell_reason=-
- run_id=6aa2ecbb573041c6a0e797749a41c6db symbol=051910 action=BUY supervisor=APPROVED execution=EXECUTED_OK buy_reason=unspecified sell_reason=-
- run_id=2ba710f938eb430f8435426488d08180 symbol=051910 action=BUY supervisor=APPROVED execution=EXECUTED_OK buy_reason=unspecified sell_reason=-
- run_id=87199de38efd44c4a854e2f42327433c symbol=051910 action=BUY supervisor=APPROVED execution=EXECUTED_OK buy_reason=unspecified sell_reason=-
- run_id=32957d80fadf45cb8dec0d273a5071a8 symbol=051910 action=BUY supervisor=APPROVED execution=EXECUTED_OK buy_reason=unspecified sell_reason=-

## Decision Trace Chain Summary

- run_total: **96**
- complete_chain_total: **96**
- run_id=844e3637393746229455f6e76e94de62 selected=051910 monitor=hold supervisor=approve executor=accepted_or_filled complete=True
- run_id=17a945cea025441db4c011818a8b65a5 selected=051910 monitor=hold supervisor=approve executor=accepted_or_filled complete=True
- run_id=3ce0c024c3f8427087cb6c00180d6b57 selected=051910 monitor=hold supervisor=approve executor=accepted_or_filled complete=True
- run_id=ff798fd7113e47bca202200cb552f7eb selected=051910 monitor=hold supervisor=approve executor=accepted_or_filled complete=True
- run_id=b8021461bd5c404093a65c7904de247f selected=051910 monitor=hold supervisor=approve executor=accepted_or_filled complete=True
- run_id=2512a634535e4d1bbc2872eb1975f28a selected=051910 monitor=hold supervisor=approve executor=accepted_or_filled complete=True
- run_id=6aa2ecbb573041c6a0e797749a41c6db selected=051910 monitor=hold supervisor=approve executor=accepted_or_filled complete=True
- run_id=2ba710f938eb430f8435426488d08180 selected=051910 monitor=hold supervisor=approve executor=accepted_or_filled complete=True
- run_id=87199de38efd44c4a854e2f42327433c selected=051910 monitor=hold supervisor=approve executor=accepted_or_filled complete=True
- run_id=32957d80fadf45cb8dec0d273a5071a8 selected=051910 monitor=hold supervisor=approve executor=accepted_or_filled complete=True

## Strategist Evaluation

- themes_proposed: `["broad_market_leaders"]`
- actual_market_leaders_by_scanner: `["051910"]`
- theme_alignment_status: **partial**
- assessment: Theme guidance existed but scanner theme-filter evidence was limited.

## Scanner Evaluation

- scanner_summary_total: **96**
- selected_symbol_top: `{"051910": 96}`
- no_candidate_total: **0**
- avg_top_score: **0.9834**
- selection_status: **appropriate**
- assessment: Scanner selected symbols consistently with sufficient candidate pool.

## Monitor Evaluation

- monitor_summary_total: **96**
- monitor_reason_top: `{"hold": 96}`
- rapid_buy_sell_cycles: **0**
- monitor_status: **stable**
- assessment: Monitor flow is stable under current guards.

## Supervisor Activity

- verdict_total: **192**
- approved_total: **192**
- blocked_total: **0**
- blocked_rate: **0.00%**
- blocked_reason_top: `{}`
- assessment: Supervisor activity within normal range.

## Intent Flow Analysis

- intents_created: **0**
- intents_blocked: **0**
- intents_approved: **96**
- intents_executed: **96**
- reason_top: `{"monitor:hold": 96}`

## Strategy Effectiveness

- Strategist favored broad_market_leaders theme.
- Scanner selected 051910 most frequently.
- Monitor exit trigger evidence was limited for this day.
- Reporter focus priority: theme_accuracy

## Overtrading Diagnostics

- rapid_buy_sell_cycles(<120s): **0**
- noise_exit_related_count: **0**
- frequent_guard_block_count: **0**
- guard_block_rate: **0.00%**

## Incident / Post-Mortem Support

- incident_total: **0**

## Improvement Suggestions

- report_focus_targets: `["theme_accuracy", "exit_quality", "overtrading"]`
- Improve strategist-to-market alignment evidence: add stronger theme mapping and leader validation inputs.

## Developer Summary

- decision_chain_run_total=96
- blocked_total=0 approved_total=192
- monitor_confirmed_exit_total=0
- scanner_no_candidate_total=0
- blocked_reason_top: `{}`
- monitor_reason_top: `{"hold": 96}`

## Source Artifacts

- trade_explain_json: `reports\trade_explain\trade_explain_2026-03-11.json`
- trade_explain_md: `reports\trade_explain\trade_explain_2026-03-11.md`
- operator_summary_json: `reports\operator_summary\operator_summary_2026-03-11.json`
- operator_summary_md: `reports\operator_summary\operator_summary_2026-03-11.md`
- decision_story_md: `reports\decision_story\decision_story_2026-03-11.md`
- run_cards_md: `reports\run_cards\run_cards_2026-03-11.md`
- decision_story_total: `96`
- run_card_total: `96`
