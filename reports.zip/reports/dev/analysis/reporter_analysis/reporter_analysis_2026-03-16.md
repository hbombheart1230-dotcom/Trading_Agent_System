# Reporter Analysis (2026-03-16)

## Daily Operator Report

- system_health: **RED**
- 2026-03-16: health=RED
- trade_count=6 symbols=1
- monitor_status=overtrading_risk scanner_status=appropriate supervisor_blocked_rate=87.73%
- incident_total=2
- recommended_actions: `["Reduce monitor flip risk by increasing confirmation strictness or widening non-emergency exit thresholds.", "High supervisor block rate: recalibrate strategy aggressiveness and guard limits for better intent quality.", "Run incident postmortem and convert top anomaly into explicit preopen/checklist gate before next session."]`

- market_context: `{"global_sentiment_avg": null, "symbol_sentiment_avg": null, "llm_provider_top": {"openrouter": 264}, "llm_model_top": {"minimax/minimax-m2.5": 264}}`
- trades_executed: **20**
- trades_blocked: **143**
- major_decisions: `["pullback", "defensive"]`
- anomalies: `["unexpected_rapid_exit", "execution_anomaly"]`

## Trade Decision Summaries

- trade_summary_total: **6**
| symbol | buy_reason | sell_reason | holding_duration_sec | exit_trigger |
| --- | --- | --- | ---: | --- |
| 032820 | unspecified | unspecified | 0 | take_profit |
| 032820 | unspecified | unspecified | 84 | stop_loss |
| 032820 | unspecified | unspecified | 85 | stop_loss |
| 032820 | unspecified | unspecified | 87 | stop_loss |
| 032820 | unspecified | unspecified | 85 | stop_loss |
| 032820 | unspecified | unspecified | 4857 | take_profit |

## Trade Summary

- trade_count: **6**
- symbols_traded: `["032820"]`

## Decision Chains

- run_total: **295**
- rendered_run_total: **200**
- run_id=8687508da60d41f2a8d38f19ef60ab48 symbol=032820 action=- supervisor=BLOCKED execution=BLOCKED buy_reason=- sell_reason=-
- run_id=4430a575f6374f43b1b0ea9b812640c8 symbol=032820 action=- supervisor=BLOCKED execution=BLOCKED buy_reason=- sell_reason=-
- run_id=ebcda2b4ece048869d706d6a429f5119 symbol=032820 action=SELL supervisor=APPROVED execution=EXECUTED_OK buy_reason=- sell_reason=unspecified
- run_id=2f7fd3c050354f1bb961a65da45e3833 symbol=032820 action=- supervisor=BLOCKED execution=BLOCKED buy_reason=- sell_reason=-
- run_id=78e639c8ed9f46fd8f1172a73a62b7a6 symbol=032820 action=- supervisor=BLOCKED execution=BLOCKED buy_reason=- sell_reason=-
- run_id=c1cb8239469f4b3992ff808d7bbb64cd symbol=032820 action=- supervisor=BLOCKED execution=BLOCKED buy_reason=- sell_reason=-
- run_id=ea99c395bd924cb4bdaee1c0fc2b41a9 symbol=032820 action=- supervisor=BLOCKED execution=BLOCKED buy_reason=- sell_reason=-
- run_id=6baf0b80134445d5bcb7a15bc6cde37c symbol=032820 action=- supervisor=BLOCKED execution=BLOCKED buy_reason=- sell_reason=-
- run_id=a7adb028fd924de0a9a2d676a050a780 symbol=032820 action=- supervisor=BLOCKED execution=BLOCKED buy_reason=- sell_reason=-
- run_id=3c6c1eb4a41c4013aacfff3553334991 symbol=032820 action=- supervisor=BLOCKED execution=BLOCKED buy_reason=- sell_reason=-

## Decision Trace Chain Summary

- run_total: **265**
- complete_chain_total: **163**
- run_id=8687508da60d41f2a8d38f19ef60ab48 selected=032820 monitor=hold supervisor=reject executor=not_attempted complete=True
- run_id=4430a575f6374f43b1b0ea9b812640c8 selected=032820 monitor=exit_signal_pending_confirmation supervisor=reject executor=not_attempted complete=True
- run_id=ebcda2b4ece048869d706d6a429f5119 selected=032820 monitor=confirmed_exit_signal supervisor=approve executor=accepted_or_filled complete=True
- run_id=2f7fd3c050354f1bb961a65da45e3833 selected=032820 monitor=no_position supervisor=reject executor=not_attempted complete=True
- run_id=78e639c8ed9f46fd8f1172a73a62b7a6 selected=032820 monitor=no_position supervisor=reject executor=not_attempted complete=True
- run_id=c1cb8239469f4b3992ff808d7bbb64cd selected=032820 monitor=no_position supervisor=reject executor=not_attempted complete=True
- run_id=ea99c395bd924cb4bdaee1c0fc2b41a9 selected=032820 monitor=no_position supervisor=reject executor=not_attempted complete=True
- run_id=6baf0b80134445d5bcb7a15bc6cde37c selected=032820 monitor=no_position supervisor=reject executor=not_attempted complete=True
- run_id=a7adb028fd924de0a9a2d676a050a780 selected=032820 monitor=no_position supervisor=reject executor=not_attempted complete=True
- run_id=3c6c1eb4a41c4013aacfff3553334991 selected=032820 monitor=no_position supervisor=reject executor=not_attempted complete=True

## Strategist Evaluation

- themes_proposed: `["broad_market_leaders", "defensive_assets", "defensive_etfs", "broad_market_leaders (from hint)", "string", "from themes_hint - broad_market_leaders", "from themes_hint", "semiconductor_strength"]`
- actual_market_leaders_by_scanner: `["032820", "000660", "008350", "006910", "005930"]`
- theme_alignment_status: **aligned**
- assessment: Strategist themes were reflected in scanner filtering.

## Scanner Evaluation

- scanner_summary_total: **278**
- selected_symbol_top: `{"032820": 165, "000660": 68, "008350": 11, "006910": 6, "005930": 4}`
- no_candidate_total: **12**
- avg_top_score: **1.2154**
- selection_status: **appropriate**
- assessment: Scanner selected symbols consistently with sufficient candidate pool.

## Monitor Evaluation

- monitor_summary_total: **264**
- monitor_reason_top: `{"hold": 133, "no_position": 69, "pending_exit_lock": 41, "confirmed_exit_signal": 13, "exit_signal_pending_confirmation": 5, "min_hold_active": 3}`
- rapid_buy_sell_cycles: **5**
- monitor_status: **overtrading_risk**
- assessment: Monitor shows overtrading risk; tighten exit confirmation or thresholds.

## Supervisor Activity

- verdict_total: **326**
- approved_total: **40**
- blocked_total: **286**
- blocked_rate: **87.73%**
- blocked_reason_top: `{"noop_intent_skipped": 286}`
- assessment: Supervisor blocks are elevated; review guard thresholds.

## Intent Flow Analysis

- intents_created: **0**
- intents_blocked: **143**
- intents_approved: **20**
- intents_executed: **20**
- reason_top: `{"noop_intent_skipped": 143, "monitor:hold": 133, "monitor:no_position": 69, "monitor:pending_exit_lock": 41, "monitor:confirmed_exit_signal": 13, "monitor:exit_signal_pending_confirmation": 5, "min_hold_blocked": 3, "monitor:min_hold_active": 3}`

## Strategy Effectiveness

- Strategist favored broad_market_leaders theme.
- Scanner selected 032820 most frequently.
- Monitor exited mostly due to hold.
- Reporter focus priority: exit_quality

## Overtrading Diagnostics

- rapid_buy_sell_cycles(<120s): **5**
- noise_exit_related_count: **5**
- frequent_guard_block_count: **0**
- guard_block_rate: **0.00%**

## Incident / Post-Mortem Support

- incident_total: **2**
- [YELLOW] unexpected_rapid_exit: rapid_buy_sell_cycles=5
- [RED] execution_anomaly: execution_anomaly_total=14

## Improvement Suggestions

- report_focus_targets: `["exit_quality", "scanner_fit", "guard_blocks", "overtrading", "theme_accuracy", "overtrading (from feedback)"]`
- Reduce monitor flip risk by increasing confirmation strictness or widening non-emergency exit thresholds.
- High supervisor block rate: recalibrate strategy aggressiveness and guard limits for better intent quality.
- Run incident postmortem and convert top anomaly into explicit preopen/checklist gate before next session.

## AI Review (Passive Optional Layer)

- ai_review_status: **ok**
- ai_review_model: `openrouter/auto`
- ai_review_reason: empty_ai_lists_repaired_from_deterministic_evidence
- ai_review_fallback_enriched: true
- ai_run_grade: **N/A**
- ai_summary: Monitor behavior showed overtrading or rapid exit pressure in this run window.
- ai_findings: `["Monitor behavior showed overtrading or rapid exit pressure in this run window."]`
- ai_root_causes: `["Exit handling and monitor confirmation logic remained the dominant source of instability."]`
- ai_improvement_suggestions: `["Reduce monitor flip risk by increasing confirmation strictness or widening non-emergency exit thresholds."]`
- ai_agent_evaluations: `{"strategist": "good", "scanner": "good", "monitor": "needs_improvement", "supervisor": "needs_improvement", "executor": "good"}`
- ai_findings_detailed:
  - text: Monitor behavior showed overtrading or rapid exit pressure in this run window.
    evidence_keys: `["monitor_exit_quality", "overtrading_risk"]`
- ai_root_causes_detailed:
  - text: Exit handling and monitor confirmation logic remained the dominant source of instability.
    evidence_keys: `["monitor_exit_quality", "overtrading_risk"]`
- ai_improvement_suggestions_detailed:
  - text: Reduce monitor flip risk by increasing confirmation strictness or widening non-emergency exit thresholds.
    evidence_keys: `["monitor_exit_quality"]`

## Developer Summary

- decision_chain_run_total=295
- blocked_total=286 approved_total=40
- monitor_confirmed_exit_total=13
- scanner_no_candidate_total=12
- blocked_reason_top: `{"noop_intent_skipped": 286}`
- monitor_reason_top: `{"hold": 133, "no_position": 69, "pending_exit_lock": 41, "confirmed_exit_signal": 13, "exit_signal_pending_confirmation": 5, "min_hold_active": 3}`

## Source Artifacts

- trade_explain_json: `reports\trade_explain\trade_explain_2026-03-16.json`
- trade_explain_md: `reports\trade_explain\trade_explain_2026-03-16.md`
- operator_summary_json: `reports\operator_summary\operator_summary_2026-03-16.json`
- operator_summary_md: `reports\operator_summary\operator_summary_2026-03-16.md`
- decision_story_md: `reports\decision_story\decision_story_2026-03-16.md`
- run_cards_md: `reports\run_cards\run_cards_2026-03-16.md`
- decision_story_total: `163`
- run_card_total: `163`
